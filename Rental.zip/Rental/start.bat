@echo off
echo.
echo   DriveEase - Self-Drive Car Rental
echo   Starting full-stack server...
echo.

cd /d "%~dp0"

where node >nul 2>&1
if errorlevel 1 (
  echo Node.js is missing. Install it from https://nodejs.org then double-click start.bat again.
  pause
  exit /b 1
)

if not exist "backend\node_modules" (
  echo Installing backend packages...
  cd backend
  call npm install
  cd ..
)
if not exist "frontend\node_modules" (
  echo Installing frontend packages...
  cd frontend
  call npm install
  cd ..
)

if not exist "frontend\dist\index.html" (
  echo Building frontend...
  cd frontend
  call npm run build
  cd ..
)

start http://localhost:5001
cd backend
node server.js
pause

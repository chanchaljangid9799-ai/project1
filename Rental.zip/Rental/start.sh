#!/bin/bash
# DriveEase — 1-Click Startup Launcher (Mac & Linux)

echo ""
echo "  DriveEase — Self-Drive Car Rental"
echo "  Starting full-stack server..."
echo ""

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is missing. Install it from https://nodejs.org then double-click start.sh again."
  exit 1
fi

if [ ! -d "backend/node_modules" ] || [ ! -d "frontend/node_modules" ]; then
  echo "Installing packages (first run only)..."
  (cd backend && npm install)
  (cd frontend && npm install)
fi

if [ ! -f "frontend/dist/index.html" ]; then
  echo "Building frontend..."
  (cd frontend && npm run build)
fi

(sleep 2 && (open "http://localhost:5001" 2>/dev/null || xdg-open "http://localhost:5001" 2>/dev/null)) &

cd "$DIR/backend"
node server.js

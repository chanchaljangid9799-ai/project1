import { Link } from 'react-router-dom';
import { FiInstagram, FiTwitter, FiLinkedin, FiGithub, FiPhone, FiMail } from 'react-icons/fi';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-brand">
          <Link to="/" className="nav-brand">
            <img src="/logo-icon.png" alt="DriveEase" className="nav-brand-logo-img" />
            <h1>Drive<span>Ease</span></h1>
          </Link>
          <p>India's most trusted self-drive car rental platform. Over 500+ premium sanitized vehicles across 25+ cities with instant keyless telematics entry.</p>
          <div style={{ marginTop: 14, fontSize: 13, color: 'var(--text-secondary)' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}><FiPhone style={{ color: 'var(--accent)' }} /> 1800-DRIVE-EASE (24/7 Helpline)</div>
            <div style={{ marginTop: 6, display: 'flex', alignItems: 'center', gap: 6 }}><FiMail style={{ color: 'var(--accent)' }} /> support@driveease.com</div>
          </div>
        </div>
        <div className="footer-column">
          <h4>Explore Fleet</h4>
          <Link to="/cars">All Vehicles</Link>
          <Link to="/cars?category=suv">SUVs & 4x4s</Link>
          <Link to="/cars?category=luxury">Luxury Sedans</Link>
          <Link to="/cars?category=electric">Electric EVs</Link>
          <Link to="/cars?category=sedan">Sedans</Link>
          <Link to="/cars?category=hatchback">Hatchbacks</Link>
        </div>
        <div className="footer-column">
          <h4>Platform</h4>
          <Link to="/how-it-works">How It Works</Link>
          <Link to="/about">About Us</Link>
          <Link to="/contact">Contact & Hubs</Link>
          <Link to="/dashboard">Driver Dashboard</Link>
          <Link to="/profile">Driver Credentials</Link>
        </div>
        <div className="footer-column">
          <h4>Trust & Safety</h4>
          <Link to="/how-it-works">BLE Keyless Telematics</Link>
          <Link to="/about">Zero-Dep Insurance</Link>
          <Link to="/how-it-works">Sanitization Protocol</Link>
          <Link to="/contact">24/7 Roadside Assistance</Link>
          <Link to="/about">Corporate Fleet Leasing</Link>
        </div>
      </div>
      <div className="footer-bottom">
        <span>© 2026 DriveEase Mobility Technologies Pvt. Ltd. All rights reserved. Hackathon 2026 Edition.</span>
        <div className="footer-socials">
          <a href="#" aria-label="Instagram"><FiInstagram /></a>
          <a href="#" aria-label="Twitter"><FiTwitter /></a>
          <a href="#" aria-label="LinkedIn"><FiLinkedin /></a>
          <a href="#" aria-label="GitHub"><FiGithub /></a>
        </div>
      </div>
    </footer>
  );
}

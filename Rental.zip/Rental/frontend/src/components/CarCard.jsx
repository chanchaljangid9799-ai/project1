import { Link } from 'react-router-dom';
import { FiHeart, FiUsers, FiZap } from 'react-icons/fi';
import { TbManualGearbox, TbAutomaticGearbox } from 'react-icons/tb';
import { BsFuelPump, BsStarFill, BsLightningChargeFill, BsCarFront, BsStars, BsShieldCheck } from 'react-icons/bs';

export const getCategoryIcon = (cat) => {
  switch ((cat || '').toLowerCase()) {
    case 'suv': return <BsShieldCheck size={18} />;
    case 'sedan': return <BsCarFront size={18} />;
    case 'luxury': return <BsStars size={18} />;
    case 'electric': return <BsLightningChargeFill size={18} />;
    default: return <BsCarFront size={18} />;
  }
};

export default function CarCard({ car }) {
  const fallbackImg = `https://placehold.co/400x250/1a1a28/c8ff00?text=${encodeURIComponent(car.name)}`;

  return (
    <Link to={`/cars/${car._id}`} className="car-card">
      <div className="car-card-image">
        <img
          src={car.images?.[0] || fallbackImg}
          alt={car.name}
          onError={(e) => { e.target.src = fallbackImg; }}
          loading="lazy"
        />
        <div className="car-card-badges">
          {car.fuelType === 'electric' && (
            <span className="car-card-badge electric" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <BsLightningChargeFill size={11} /> EV
            </span>
          )}
          <span className={`car-card-badge ${car.transmission === 'automatic' ? 'auto' : ''}`}>
            {car.transmission === 'automatic' ? 'AUTOMATIC' : 'MANUAL'}
          </span>
        </div>
        <div className="car-card-favorite" onClick={(e) => e.preventDefault()}>
          <FiHeart />
        </div>
      </div>
      <div className="car-card-body">
        <div className="car-card-header">
          <div>
            <div className="car-card-title">{car.name}</div>
            <div className="car-card-brand">{car.brand} · {car.category?.toUpperCase()}</div>
          </div>
          <div className="car-card-rating">
            <BsStarFill size={12} style={{ color: 'var(--warning)' }} />
            {car.rating}
            <span>({car.totalTrips})</span>
          </div>
        </div>

        <div className="car-card-specs">
          <div className="car-card-spec">
            <BsFuelPump size={13} />
            {car.fuelType}
          </div>
          <div className="car-card-spec">
            <FiUsers size={13} />
            {car.seats} seats
          </div>
          <div className="car-card-spec">
            {car.transmission === 'automatic' ? <TbAutomaticGearbox size={14} /> : <TbManualGearbox size={14} />}
            {car.transmission}
          </div>
        </div>

        <div className="car-card-footer">
          <div className="car-card-price">
            <span className="amount">₹{car.pricePerDay?.toLocaleString('en-IN')}</span>
            <span className="period">/day</span>
          </div>
          <button className="btn btn-primary btn-sm">Book</button>
        </div>
      </div>
    </Link>
  );
}

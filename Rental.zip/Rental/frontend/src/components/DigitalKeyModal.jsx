import { useState } from 'react';
import { FiLock, FiUnlock, FiVolume2, FiX, FiCheckCircle, FiCompass, FiBatteryCharging, FiShield } from 'react-icons/fi';
import { BsKey, BsSpeedometer2 } from 'react-icons/bs';
import { playCarChirp, playTrunkSound, playHornSound } from '../utils/audio';
import toast from 'react-hot-toast';

export default function DigitalKeyModal({ booking, onClose }) {
  const [locked, setLocked] = useState(true);
  const [trunkOpen, setTrunkOpen] = useState(false);
  const [flashersActive, setFlashersActive] = useState(false);
  const [lastAction, setLastAction] = useState('Doors Locked & Armed');

  const car = booking?.car;
  const pin = booking?._id ? (parseInt(booking._id.replace(/\D/g, '').slice(-4)) || 7492) : 7492;

  const handleUnlock = () => {
    playCarChirp('unlock');
    setLocked(false);
    setLastAction('Unlocked • Headlights Flashed');
    toast.success('Vehicle Unlocked! Welcome aboard.');
  };

  const handleLock = () => {
    playCarChirp('lock');
    setLocked(true);
    setLastAction('Doors Locked & Security Armed');
    toast.success('Vehicle Locked & Secured.');
  };

  const handleTrunk = () => {
    playTrunkSound();
    setTrunkOpen(!trunkOpen);
    setLastAction(trunkOpen ? 'Trunk Closed' : 'Trunk Popped & Unlatched');
    toast(trunkOpen ? 'Trunk Closed' : 'Trunk Unlatched');
  };

  const handleHorn = () => {
    playHornSound();
    setFlashersActive(true);
    setLastAction('Hazard Lights Flashed & Horn Alerted');
    setTimeout(() => setFlashersActive(false), 2000);
  };

  return (
    <div className="key-modal-overlay" onClick={onClose}>
      <div className="key-modal-card" onClick={(e) => e.stopPropagation()}>
        <button className="key-modal-close" onClick={onClose}><FiX size={20} /></button>

        <div className="key-modal-header">
          <div className="key-badge">
            <span className="live-dot"></span> SMART TELEMATICS KEY
          </div>
          <h3>{car?.name || 'DriveEase Smart Key'}</h3>
          <p className="key-subtitle">
            {car?.registrationNumber || 'MH-01-AB-1234'} • Connected via BLE 5.3 Encryption
          </p>
        </div>

        {/* Fob & Telematics Display */}
        <div className="key-fob-container">
          <div className={`key-fob ${flashersActive ? 'flashing' : ''}`}>
            <div className="fob-top">
              <span className="fob-brand">DRIVE<span>EASE</span></span>
              <div className={`fob-led ${locked ? 'red' : 'green'}`}></div>
            </div>

            <div className="fob-screen">
              <div className="fob-status-text">{lastAction}</div>
              <div className="fob-pin">
                <span>UNLOCK PIN</span>
                <strong>{pin}</strong>
              </div>
            </div>

            {/* Fob Action Buttons */}
            <div className="fob-buttons-grid">
              <button
                className={`fob-btn ${locked ? 'active' : ''}`}
                onClick={handleLock}
                title="Lock Vehicle"
              >
                <FiLock size={22} />
                <span>Lock</span>
              </button>

              <button
                className={`fob-btn ${!locked ? 'active' : ''}`}
                onClick={handleUnlock}
                title="Unlock Vehicle"
              >
                <FiUnlock size={22} />
                <span>Unlock</span>
              </button>

              <button
                className={`fob-btn ${trunkOpen ? 'active' : ''}`}
                onClick={handleTrunk}
                title="Open Trunk"
              >
                <BsKey size={22} />
                <span>{trunkOpen ? 'Close Trunk' : 'Open Trunk'}</span>
              </button>

              <button
                className={`fob-btn ${flashersActive ? 'active' : ''}`}
                onClick={handleHorn}
                title="Sound Horn & Flashers"
              >
                <FiVolume2 size={22} />
                <span>Honk & Flash</span>
              </button>
            </div>
          </div>
        </div>

        {/* Telematics Metrics */}
        <div className="telematics-grid">
          <div className="telematics-card">
            <div className="telematics-icon"><BsSpeedometer2 size={16} /></div>
            <div>
              <div className="telematics-label">Estimated Range</div>
              <div className="telematics-val">420 km</div>
            </div>
          </div>

          <div className="telematics-card">
            <div className="telematics-icon"><FiBatteryCharging size={16} /></div>
            <div>
              <div className="telematics-label">{car?.fuelType === 'electric' ? 'Battery' : 'Fuel Level'}</div>
              <div className="telematics-val">88% Tank</div>
            </div>
          </div>

          <div className="telematics-card">
            <div className="telematics-icon"><FiShield size={16} /></div>
            <div>
              <div className="telematics-label">Tire Pressure</div>
              <div className="telematics-val">34 PSI Normal</div>
            </div>
          </div>

          <div className="telematics-card">
            <div className="telematics-icon"><FiCompass size={16} /></div>
            <div>
              <div className="telematics-label">GPS Location</div>
              <div className="telematics-val">{car?.location?.area || 'Hub'}, {car?.location?.city || 'City'}</div>
            </div>
          </div>
        </div>

        <div className="key-footer-info" style={{ display: 'flex', alignItems: 'flex-start', gap: 8 }}>
          <FiCheckCircle size={16} style={{ color: 'var(--accent)', flexShrink: 0, marginTop: 2 }} />
          <span><strong>How it works:</strong> Approach the vehicle within 5 meters. Tap <em>Unlock</em> on this remote or enter PIN <strong>{pin}</strong> on the driver window keypad for instant keyless entry.</span>
        </div>
      </div>
    </div>
  );
}

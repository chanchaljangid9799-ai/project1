import { useState } from 'react';
import { FiMapPin, FiNavigation, FiTrendingUp, FiDollarSign, FiZap, FiCheck } from 'react-icons/fi';
import { BsFuelPump, BsLightningChargeFill } from 'react-icons/bs';

const POPULAR_ROUTES = [
  { label: 'Mumbai ➔ Lonavala', km: 83, hours: '2h 10m', tolls: 240 },
  { label: 'Mumbai ➔ Pune', km: 148, hours: '3h 15m', tolls: 320 },
  { label: 'Mumbai ➔ Goa', km: 585, hours: '10h 30m', tolls: 680 },
  { label: 'Delhi ➔ Agra', km: 233, hours: '3h 45m', tolls: 415 },
  { label: 'Delhi ➔ Jaipur', km: 281, hours: '4h 50m', tolls: 480 },
  { label: 'Bangalore ➔ Mysore', km: 143, hours: '2h 30m', tolls: 280 },
  { label: 'Bangalore ➔ Coorg', km: 248, hours: '5h 15m', tolls: 340 },
];

export default function AiRoutePlanner({ car }) {
  const [selectedRoute, setSelectedRoute] = useState(POPULAR_ROUTES[0]);
  const [customKm, setCustomKm] = useState(POPULAR_ROUTES[0].km);
  const [passengers, setPassengers] = useState(3);

  // Extract mileage from car specs (e.g. '22.61 kmpl' or '437 km range')
  const isElectric = car?.fuelType === 'electric';
  let mileageNum = 16.5;
  if (car?.specifications?.mileage) {
    const parsed = parseFloat(car.specifications.mileage);
    if (!isNaN(parsed) && parsed > 0) mileageNum = parsed;
  }

  // Calculations
  const distance = customKm || 100;
  const fuelPricePerUnit = isElectric ? 8.5 : (car?.fuelType === 'diesel' ? 89.5 : 96.5); // ₹ per kWh or ₹ per Litre

  let unitsRequired = 0;
  let fuelCost = 0;

  if (isElectric) {
    // Approx 7 km per kWh
    unitsRequired = Math.round((distance / 7) * 10) / 10;
    fuelCost = Math.round(unitsRequired * fuelPricePerUnit);
  } else {
    unitsRequired = Math.round((distance / mileageNum) * 10) / 10;
    fuelCost = Math.round(unitsRequired * fuelPricePerUnit);
  }

  const tollsCost = selectedRoute ? selectedRoute.tolls : Math.round(distance * 1.5);
  const totalTripEnergyCost = fuelCost + tollsCost;
  const costPerPerson = Math.round(totalTripEnergyCost / Math.max(1, passengers));

  // Comparative flight/cab cost for same distance
  const alternativeCost = Math.round(distance * 14 * passengers);
  const totalSavings = Math.max(0, alternativeCost - totalTripEnergyCost);

  const handleSelectRoute = (route) => {
    setSelectedRoute(route);
    setCustomKm(route.km);
  };

  return (
    <div className="ai-planner-card">
      <div className="ai-planner-header">
        <div className="ai-planner-badge">
          <FiZap size={14} /> DRIVE-EASE AI TRIP & FUEL ESTIMATOR
        </div>
        <h4>Smart Route & Cost Calculator</h4>
        <p>Real-time calculation based on this {car?.name}'s authentic {car?.specifications?.mileage || '16 kmpl'} efficiency</p>
      </div>

      {/* Preset Route Chips */}
      <div className="planner-routes-chips">
        {POPULAR_ROUTES.map((r, i) => (
          <button
            key={i}
            className={`route-chip ${selectedRoute?.label === r.label ? 'active' : ''}`}
            onClick={() => handleSelectRoute(r)}
          >
            {r.label} ({r.km} km)
          </button>
        ))}
      </div>

      {/* Distance Slider / Input */}
      <div className="planner-controls-row">
        <div className="planner-control">
          <label>Estimated Distance</label>
          <div className="planner-input-group">
            <input
              type="number"
              min="20"
              max="2500"
              value={customKm}
              onChange={(e) => {
                setCustomKm(Number(e.target.value));
                setSelectedRoute(null);
              }}
            />
            <span className="unit">KM</span>
          </div>
        </div>

        <div className="planner-control">
          <label>Passengers Traveling</label>
          <div className="planner-input-group">
            <select value={passengers} onChange={(e) => setPassengers(Number(e.target.value))}>
              {[1, 2, 3, 4, 5, 6, 7].map(n => (
                <option key={n} value={n}>{n} {n === 1 ? 'Person' : 'People'}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Real-time Calculation Grid */}
      <div className="ai-results-grid">
        <div className="ai-result-box">
          <div className="ai-result-icon">
            {isElectric ? <BsLightningChargeFill size={18} /> : <BsFuelPump size={18} />}
          </div>
          <div>
            <div className="ai-result-label">{isElectric ? 'Power Required' : 'Fuel Required'}</div>
            <div className="ai-result-val">{unitsRequired} {isElectric ? 'kWh' : 'Litres'}</div>
            <div className="ai-result-sub">@ ₹{fuelPricePerUnit}/{isElectric ? 'kWh' : 'L'}</div>
          </div>
        </div>

        <div className="ai-result-box">
          <div className="ai-result-icon"><FiDollarSign size={18} /></div>
          <div>
            <div className="ai-result-label">Est. Fuel & Tolls</div>
            <div className="ai-result-val">₹{totalTripEnergyCost.toLocaleString('en-IN')}</div>
            <div className="ai-result-sub">₹{fuelCost} fuel + ₹{tollsCost} tolls</div>
          </div>
        </div>

        <div className="ai-result-box highlight">
          <div className="ai-result-icon"><FiTrendingUp size={18} /></div>
          <div>
            <div className="ai-result-label">Cost Per Person</div>
            <div className="ai-result-val">₹{costPerPerson.toLocaleString('en-IN')}</div>
            <div className="ai-result-sub">Across {passengers} passengers</div>
          </div>
        </div>
      </div>

      <div className="planner-savings-banner">
        <FiCheck size={18} style={{ color: 'var(--accent)' }} />
        <span>
          Save up to <strong>₹{totalSavings.toLocaleString('en-IN')}</strong> compared to {passengers} individual flight/cab bookings!
        </span>
      </div>
    </div>
  );
}

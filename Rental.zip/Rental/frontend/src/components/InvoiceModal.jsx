import { FiPrinter, FiX, FiCheckCircle } from 'react-icons/fi';

export default function InvoiceModal({ booking, onClose }) {
  const car = booking?.car;
  const user = booking?.user || {};
  const bookingRef = (booking?._id || '').slice(-8).toUpperCase();
  const invoiceNumber = 'INV-2026-' + bookingRef;
  const invoiceDate = new Date(booking?.createdAt || Date.now()).toLocaleDateString('en-IN', {
    day: 'numeric', month: 'short', year: 'numeric'
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="invoice-modal-overlay" onClick={onClose}>
      <div className="invoice-modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="invoice-modal-actions no-print">
          <button className="btn btn-primary btn-sm" onClick={handlePrint}>
            <FiPrinter size={16} /> Print / Save PDF
          </button>
          <button className="key-modal-close" onClick={onClose}><FiX size={20} /></button>
        </div>

        {/* Printable Invoice Sheet */}
        <div className="invoice-sheet" id="invoice-printable">
          <div className="invoice-top">
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
              <img src="/logo-icon.png" alt="DriveEase" style={{ width: '40px', height: '40px', borderRadius: '10px' }} />
              <div>
                <div className="invoice-logo">Drive<span>Ease</span></div>
                <p className="invoice-company-sub">DriveEase Mobility Technologies Pvt. Ltd.<br />GSTIN: 27AABBD1234F1Z9 • CIN: U74999MH2026PTC123456</p>
              </div>
            </div>
            <div className="invoice-meta-right">
              <div className="invoice-title">TAX INVOICE</div>
              <div className="invoice-meta-row"><strong>Invoice No:</strong> {invoiceNumber}</div>
              <div className="invoice-meta-row"><strong>Date:</strong> {invoiceDate}</div>
              <div className="invoice-meta-row"><strong>Status:</strong> <span className="paid-tag">PAID</span></div>
            </div>
          </div>

          <div className="invoice-parties">
            <div className="invoice-party-col">
              <h4>BILLED TO:</h4>
              <p><strong>{user.firstName || 'Guest'} {user.lastName || ''}</strong></p>
              <p>{user.email || 'customer@driveease.com'}</p>
              <p>Phone: +91 {user.phone || '9876543210'}</p>
            </div>
            <div className="invoice-party-col">
              <h4>RESERVATION DETAILS:</h4>
              <p><strong>Vehicle:</strong> {car?.name || 'Selected Car'} ({car?.registrationNumber || 'MH-01-AB-1234'})</p>
              <p><strong>Pickup:</strong> {new Date(booking?.pickupDate).toLocaleString('en-IN')}</p>
              <p><strong>Dropoff:</strong> {new Date(booking?.dropoffDate).toLocaleString('en-IN')}</p>
              <p><strong>Transaction ID:</strong> {booking?.payment?.transactionId || 'TXN_SUCCESS'}</p>
            </div>
          </div>

          <table className="invoice-table">
            <thead>
              <tr>
                <th>Description</th>
                <th>Qty / Duration</th>
                <th>Rate</th>
                <th style={{ textAlign: 'right' }}>Amount (INR)</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>
                  <strong>Self-Drive Rental Charges</strong><br />
                  <span style={{ fontSize: 12, color: '#888' }}>{car?.name} • Base vehicle usage tariff</span>
                </td>
                <td>{booking?.totalHours ? `${Math.ceil(booking.totalHours / 24)} days (${booking.totalHours} hrs)` : 'Trip'}</td>
                <td>₹{car?.pricePerDay || 1499}/day</td>
                <td style={{ textAlign: 'right' }}>₹{booking?.pricing?.basePrice?.toLocaleString('en-IN') || 0}</td>
              </tr>
              {booking?.extras?.insurance && (
                <tr>
                  <td>
                    <strong>Comprehensive Damage Protection Cover</strong><br />
                    <span style={{ fontSize: 12, color: '#888' }}>Zero-depreciation bumper-to-bumper insurance</span>
                  </td>
                  <td>1 Plan</td>
                  <td>10% Tariff</td>
                  <td style={{ textAlign: 'right' }}>₹{booking?.pricing?.insuranceFee?.toLocaleString('en-IN') || 0}</td>
                </tr>
              )}
              <tr>
                <td>
                  <strong>Platform & Technology Service Fee</strong><br />
                  <span style={{ fontSize: 12, color: '#888' }}>24/7 Roadside Assistance & Telematics monitoring</span>
                </td>
                <td>1 Service</td>
                <td>5% Tariff</td>
                <td style={{ textAlign: 'right' }}>₹{booking?.pricing?.serviceFee?.toLocaleString('en-IN') || 0}</td>
              </tr>
              <tr>
                <td>
                  <strong>Goods and Services Tax (GST 18%)</strong><br />
                  <span style={{ fontSize: 12, color: '#888' }}>CGST (9%) + SGST (9%)</span>
                </td>
                <td>18%</td>
                <td>Applicable</td>
                <td style={{ textAlign: 'right' }}>₹{booking?.pricing?.gst?.toLocaleString('en-IN') || 0}</td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <td colSpan="3" style={{ textAlign: 'right', fontWeight: 'bold', fontSize: 16 }}>Grand Total Paid:</td>
                <td style={{ textAlign: 'right', fontWeight: 'bold', fontSize: 18, color: '#00a86b' }}>
                  ₹{booking?.pricing?.totalAmount?.toLocaleString('en-IN') || 0}
                </td>
              </tr>
            </tfoot>
          </table>

          <div className="invoice-bottom">
            <div>
              <p style={{ margin: 0, fontSize: 12, color: '#666' }}>
                Thank you for driving with DriveEase! This is a computer-generated tax invoice. No signature is required.
              </p>
            </div>
            <div className="invoice-stamp">
              <FiCheckCircle size={28} color="#00a86b" />
              <span>DIGITALLY VERIFIED</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

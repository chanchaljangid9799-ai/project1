import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { HiOutlineMenu, HiOutlineX } from 'react-icons/hi';
import { FiUser, FiLogOut, FiGrid, FiSettings, FiHelpCircle, FiInfo, FiPhone } from 'react-icons/fi';
import { BsCarFront } from 'react-icons/bs';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
        setDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
    setDropdownOpen(false);
  }, [location]);

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const isActive = (path) => location.pathname === path ? 'active' : '';

  return (
    <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
      <Link to="/" className="nav-brand">
        <img src="/logo-icon.png" alt="DriveEase" className="nav-brand-logo-img" />
        <h1>Drive<span>Ease</span></h1>
      </Link>

      {/* Main Top Navigation Links */}
      <div className={`nav-links ${mobileOpen ? 'mobile-open' : ''}`}>
        <Link to="/" className={isActive('/')}>Home</Link>
        <Link to="/cars" className={isActive('/cars')}>Fleet</Link>
        <Link to="/how-it-works" className={isActive('/how-it-works')}>How It Works</Link>
        <Link to="/about" className={isActive('/about')}>About Us</Link>
        <Link to="/contact" className={isActive('/contact')}>Contact</Link>
        {user && <Link to="/dashboard" className={isActive('/dashboard')}>My Trips</Link>}
      </div>

      <div className="nav-actions">
        {user ? (
          <div className="nav-user" ref={dropdownRef} onClick={() => setDropdownOpen(!dropdownOpen)}>
            <div className="nav-user-avatar">
              {user.firstName?.charAt(0)}{user.lastName?.charAt(0)}
            </div>
            <span className="nav-user-name">{user.firstName}</span>
            <div className={`nav-user-dropdown ${dropdownOpen ? 'open' : ''}`}>
              <Link to="/dashboard"><FiGrid size={16} /> My Trips</Link>
              <Link to="/profile"><FiSettings size={16} /> Driver Profile</Link>
              <button className="logout-btn" onClick={handleLogout}>
                <FiLogOut size={16} /> Sign Out
              </button>
            </div>
          </div>
        ) : (
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <Link to="/login" className="btn btn-ghost btn-sm">Sign In</Link>
            <Link to="/register" className="btn btn-primary btn-sm">Get Started</Link>
          </div>
        )}
        <button className="nav-toggle" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <HiOutlineX /> : <HiOutlineMenu />}
        </button>
      </div>
    </nav>
  );
}

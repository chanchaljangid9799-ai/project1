import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { FiHome, FiCompass, FiCalendar, FiUser } from 'react-icons/fi';
import { BsKey, BsCarFront } from 'react-icons/bs';
import { RiCarLine } from 'react-icons/ri';

export default function MobileBottomNav() {
  const location = useLocation();
  const { user } = useAuth();

  const currentPath = location.pathname;

  const isActive = (path) => {
    if (path === '/') return currentPath === '/';
    return currentPath.startsWith(path);
  };

  return (
    <div className="mobile-bottom-dock">
      <Link to="/" className={`mobile-nav-item ${isActive('/') ? 'active' : ''}`}>
        <div className="mobile-nav-icon">
          <FiHome size={20} />
        </div>
        <span>Home</span>
      </Link>

      <Link to="/cars" className={`mobile-nav-item ${isActive('/cars') ? 'active' : ''}`}>
        <div className="mobile-nav-icon">
          <RiCarLine size={21} />
        </div>
        <span>Fleet</span>
      </Link>

      <Link
        to={user ? '/dashboard' : '/login'}
        className={`mobile-nav-item ${isActive('/dashboard') ? 'active' : ''}`}
      >
        <div className="mobile-nav-icon">
          <BsKey size={20} />
        </div>
        <span>My Trips</span>
      </Link>

      <Link
        to={user ? '/profile' : '/login'}
        className={`mobile-nav-item ${isActive('/profile') || isActive('/login') || isActive('/register') ? 'active' : ''}`}
      >
        <div className="mobile-nav-icon">
          <FiUser size={20} />
        </div>
        <span>{user ? 'Profile' : 'Sign In'}</span>
      </Link>
    </div>
  );
}

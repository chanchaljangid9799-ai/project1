import { useState, useEffect } from 'react';
import { FiMail, FiExternalLink, FiX, FiSend, FiCheck, FiRefreshCw } from 'react-icons/fi';
import { bookingsAPI } from '../services/api';
import toast from 'react-hot-toast';

export default function EmailModal({ bookingId, previewUrl: initialPreviewUrl, onClose }) {
  const [emailData, setEmailData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [customEmail, setCustomEmail] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    loadEmail();
  }, [bookingId]);

  const loadEmail = async () => {
    setLoading(true);
    try {
      const res = await bookingsAPI.getEmailPreview(bookingId);
      setEmailData(res.data);
    } catch (err) {
      toast.error('Could not load email preview');
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async (e) => {
    e.preventDefault();
    if (!customEmail || !customEmail.includes('@')) {
      toast.error('Please enter a valid email address');
      return;
    }

    setSending(true);
    try {
      const res = await bookingsAPI.resendEmail(bookingId, customEmail);
      toast.success(res.data.message || 'Confirmation email dispatched!');
      if (res.data.previewUrl) {
        setEmailData(prev => ({ ...prev, previewUrl: res.data.previewUrl }));
      }
      setCustomEmail('');
    } catch (err) {
      toast.error('Failed to send email');
    } finally {
      setSending(false);
    }
  };

  const effectivePreviewUrl = emailData?.previewUrl || initialPreviewUrl;

  return (
    <div className="email-modal-overlay" onClick={onClose}>
      <div className="email-modal-card" onClick={(e) => e.stopPropagation()}>
        <div className="email-modal-header">
          <div className="email-modal-title">
            <FiMail size={20} style={{ color: 'var(--accent)' }} />
            <div>
              <h3>Dispatched Confirmation Email</h3>
              <p>Sent to: <span style={{ color: '#fff' }}>{emailData?.recipient || 'Customer'}</span></p>
            </div>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            {effectivePreviewUrl && (
              <a
                href={effectivePreviewUrl}
                target="_blank"
                rel="noreferrer"
                className="btn btn-secondary btn-sm"
                title="View in external test sandbox"
              >
                <FiExternalLink size={14} /> Open in Ethereal
              </a>
            )}
            <button className="key-modal-close" onClick={onClose}><FiX size={20} /></button>
          </div>
        </div>

        {/* Dispatch to another email address form */}
        <form className="email-resend-bar" onSubmit={handleResend}>
          <div className="resend-input-wrapper">
            <FiMail size={16} style={{ color: 'var(--text-muted)' }} />
            <input
              type="email"
              placeholder="Send a copy to your real email address..."
              value={customEmail}
              onChange={(e) => setCustomEmail(e.target.value)}
            />
          </div>
          <button type="submit" className="btn btn-primary btn-sm" disabled={sending}>
            {sending ? <FiRefreshCw className="spin" size={14} /> : <FiSend size={14} />}
            <span>{sending ? 'Sending...' : 'Send Email'}</span>
          </button>
        </form>

        {/* Email Content Frame */}
        <div className="email-render-frame">
          {loading ? (
            <div className="loading-container" style={{ padding: 40 }}>
              <div className="spinner"></div>
              <p className="loading-text">Rendering live dispatched email...</p>
            </div>
          ) : emailData?.html ? (
            <iframe
              title="Dispatched Email Preview"
              srcDoc={emailData.html}
              className="email-iframe"
            />
          ) : (
            <div style={{ padding: 40, textAlign: 'center', color: 'var(--text-muted)' }}>
              No email preview available.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

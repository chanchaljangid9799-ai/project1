import { useEffect, useRef } from 'react';

export default function MouseFollowCar() {
  const canvasRef = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const pointer = { x: 0, y: 0, active: false, lastMove: 0 };
    const finger = { x: 0, y: 0, vx: 0, vy: 0 };
    const car = { x: 0, y: 0, vx: 0, vy: 0, angle: 0, speed: 0 };
    const trail = [];
    const dust = [];
    let rafId = 0;
    let last = performance.now();
    let clock = 0;
    let w = 0;
    let h = 0;
    let booted = false;

    const lerp = (a, b, t) => a + (b - a) * t;
    const wrapAngle = (a) => {
      while (a > Math.PI) a -= Math.PI * 2;
      while (a < -Math.PI) a += Math.PI * 2;
      return a;
    };

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.floor(w * dpr);
      canvas.height = Math.floor(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      if (!booted) {
        finger.x = w * 0.7;
        finger.y = h * 0.38;
        car.x = finger.x - 90;
        car.y = finger.y;
        car.angle = 0;
        pointer.x = finger.x;
        pointer.y = finger.y;
        booted = true;
      }
    };

    const demoTarget = (time) => {
      const padX = Math.max(90, w * 0.1);
      const padY = Math.max(110, h * 0.16);
      const left = padX;
      const right = w - padX;
      const top = padY;
      const bottom = h - padY;
      const lap = 11;
      const u = (time / lap) % 1;
      const corners = [
        [right, top],
        [right, bottom],
        [left, bottom],
        [left, top],
      ];
      const seg = u * 4;
      const i = Math.floor(seg) % 4;
      const n = (i + 1) % 4;
      const local = seg - Math.floor(seg);
      const ease = local * local * (3 - 2 * local);
      return {
        x: lerp(corners[i][0], corners[n][0], ease),
        y: lerp(corners[i][1], corners[n][1], ease),
      };
    };

    const onPointer = (x, y) => {
      pointer.x = x;
      pointer.y = y;
      pointer.active = true;
      pointer.lastMove = performance.now();
    };

    const onMouseMove = (e) => onPointer(e.clientX, e.clientY);
    const onTouchMove = (e) => {
      const touch = e.touches[0];
      if (touch) onPointer(touch.clientX, touch.clientY);
    };
    const onTouchStart = (e) => {
      const touch = e.touches[0];
      if (touch) onPointer(touch.clientX, touch.clientY);
    };

    const drawRibbon = () => {
      if (trail.length < 3) return;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      for (let pass = 0; pass < 2; pass += 1) {
        ctx.beginPath();
        for (let i = 0; i < trail.length; i += 1) {
          const p = trail[i];
          if (i === 0) ctx.moveTo(p.x, p.y);
          else ctx.lineTo(p.x, p.y);
        }
        const alpha = pass === 0 ? 0.16 : 0.38;
        ctx.strokeStyle = `rgba(200,255,0,${alpha})`;
        ctx.lineWidth = pass === 0 ? 22 : 5;
        ctx.stroke();
      }
      ctx.beginPath();
      trail.forEach((p, i) => {
        if (i === 0) ctx.moveTo(p.x, p.y);
        else ctx.lineTo(p.x, p.y);
      });
      ctx.setLineDash([7, 11]);
      ctx.strokeStyle = 'rgba(255,255,255,0.28)';
      ctx.lineWidth = 1.6;
      ctx.stroke();
      ctx.setLineDash([]);
    };

    const drawHeadlights = () => {
      const reach = 88 + car.speed * 1.4;
      ctx.save();
      ctx.translate(car.x, car.y);
      ctx.rotate(car.angle);
      const beam = ctx.createLinearGradient(18, 0, reach, 0);
      beam.addColorStop(0, 'rgba(255,255,220,0.28)');
      beam.addColorStop(0.45, 'rgba(200,255,0,0.08)');
      beam.addColorStop(1, 'rgba(200,255,0,0)');
      ctx.fillStyle = beam;
      ctx.beginPath();
      ctx.moveTo(16, -7);
      ctx.lineTo(reach, -34);
      ctx.lineTo(reach, 34);
      ctx.lineTo(16, 7);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    const drawCar = () => {
      ctx.save();
      ctx.translate(car.x, car.y);
      ctx.rotate(car.angle);

      ctx.fillStyle = 'rgba(0,0,0,0.28)';
      ctx.beginPath();
      ctx.ellipse(2, 8, 34, 16, 0, 0, Math.PI * 2);
      ctx.fill();

      const body = ctx.createLinearGradient(-36, -14, 36, 14);
      body.addColorStop(0, '#9ad400');
      body.addColorStop(0.45, '#d4ff3d');
      body.addColorStop(1, '#7fb800');
      ctx.fillStyle = body;
      roundRect(ctx, -34, -13, 68, 26, 9);
      ctx.fill();

      ctx.fillStyle = 'rgba(10,10,18,0.55)';
      roundRect(ctx, -10, -9, 26, 18, 6);
      ctx.fill();
      ctx.fillStyle = 'rgba(180,220,255,0.22)';
      roundRect(ctx, -6, -7, 18, 14, 4);
      ctx.fill();

      ctx.fillStyle = '#0c0c12';
      roundRect(ctx, 28, -11, 8, 22, 3);
      ctx.fill();

      [[-18, -12], [-18, 12], [16, -12], [16, 12]].forEach(([wx, wy]) => {
        ctx.save();
        ctx.translate(wx, wy);
        ctx.fillStyle = '#111118';
        roundRect(ctx, -7, -3.2, 14, 6.4, 2);
        ctx.fill();
        ctx.strokeStyle = 'rgba(200,255,0,0.55)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(-4, 0);
        ctx.lineTo(4, 0);
        ctx.stroke();
        ctx.restore();
      });

      ctx.fillStyle = '#fff8d0';
      ctx.shadowColor = 'rgba(255,255,180,0.9)';
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.arc(30, -7, 2.2, 0, Math.PI * 2);
      ctx.arc(30, 7, 2.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.fillStyle = '#ff4d5a';
      ctx.beginPath();
      ctx.arc(-32, -7, 1.8, 0, Math.PI * 2);
      ctx.arc(-32, 7, 1.8, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    };

    const drawFinger = (idleMix) => {
      if (idleMix < 0.04) return;
      ctx.save();
      ctx.globalAlpha = idleMix;
      ctx.translate(finger.x, finger.y);

      const pulse = 16 + Math.sin(clock * 5) * 3;
      ctx.strokeStyle = 'rgba(200,255,0,0.55)';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(0, 0, pulse, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = 'rgba(200,255,0,0.12)';
      ctx.beginPath();
      ctx.arc(0, 0, pulse * 0.55, 0, Math.PI * 2);
      ctx.fill();

      ctx.rotate(-0.42);
      ctx.shadowColor = 'rgba(0,0,0,0.35)';
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#f4f4f8';
      ctx.beginPath();
      ctx.moveTo(2, -2);
      ctx.bezierCurveTo(8, 8, 12, 14, 11, 22);
      ctx.quadraticCurveTo(8, 36, 2, 38);
      ctx.quadraticCurveTo(-6, 38, -5, 24);
      ctx.lineTo(-10, 18);
      ctx.quadraticCurveTo(-16, 14, -8, 10);
      ctx.lineTo(-2, 12);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.strokeStyle = 'rgba(20,20,30,0.35)';
      ctx.lineWidth = 1.2;
      ctx.stroke();

      ctx.fillStyle = '#c8ff00';
      ctx.beginPath();
      ctx.arc(1, 0, 3.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    const drawAim = (idleMix) => {
      if (idleMix > 0.85) return;
      ctx.save();
      ctx.globalAlpha = 1 - idleMix;
      ctx.strokeStyle = 'rgba(200,255,0,0.5)';
      ctx.lineWidth = 1.6;
      ctx.beginPath();
      ctx.arc(pointer.x, pointer.y, 10, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = 'rgba(200,255,0,0.85)';
      ctx.beginPath();
      ctx.arc(pointer.x, pointer.y, 2.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    };

    function roundRect(c, x, y, rw, rh, r) {
      const rad = Math.min(r, rw / 2, rh / 2);
      c.beginPath();
      c.moveTo(x + rad, y);
      c.arcTo(x + rw, y, x + rw, y + rh, rad);
      c.arcTo(x + rw, y + rh, x, y + rh, rad);
      c.arcTo(x, y + rh, x, y, rad);
      c.arcTo(x, y, x + rw, y, rad);
      c.closePath();
    }

    const tick = (now) => {
      const dt = Math.min(0.033, (now - last) / 1000);
      last = now;
      clock += dt;

      const idle = !pointer.active || now - pointer.lastMove > 1800;
      const target = idle ? demoTarget(clock) : pointer;
      const follow = idle ? 0.13 : 0.22;

      finger.vx += (target.x - finger.x) * follow;
      finger.vy += (target.y - finger.y) * follow;
      finger.vx *= 0.78;
      finger.vy *= 0.78;
      finger.x += finger.vx;
      finger.y += finger.vy;

      const lead = 28;
      const aimX = finger.x + finger.vx * 2;
      const aimY = finger.y + finger.vy * 2;
      const dx = aimX - car.x;
      const dy = aimY - car.y;
      const dist = Math.hypot(dx, dy) || 1;
      const desired = Math.atan2(dy, dx);
      car.angle += wrapAngle(desired - car.angle) * (idle ? 0.09 : 0.18);

      const cruise = idle ? 340 : Math.min(920, 180 + dist * 4.2);
      const accel = idle ? 3.2 : 6.5;
      car.speed += (cruise - car.speed) * accel * dt;
      if (dist < lead) car.speed *= 0.92;

      car.vx = Math.cos(car.angle) * car.speed;
      car.vy = Math.sin(car.angle) * car.speed;
      car.x += car.vx * dt;
      car.y += car.vy * dt;

      trail.push({ x: car.x, y: car.y });
      if (trail.length > 56) trail.shift();

      if (car.speed > 80 && Math.random() < 0.55) {
        dust.push({
          x: car.x - Math.cos(car.angle) * 30,
          y: car.y - Math.sin(car.angle) * 30,
          vx: -Math.cos(car.angle) * 20 + (Math.random() - 0.5) * 18,
          vy: -Math.sin(car.angle) * 20 + (Math.random() - 0.5) * 18,
          life: 1,
        });
      }

      const idleMix = idle ? Math.min(1, (now - pointer.lastMove) / 700) : 0;

      ctx.clearRect(0, 0, w, h);
      drawRibbon();

      for (let i = dust.length - 1; i >= 0; i -= 1) {
        const p = dust[i];
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        p.life -= dt * 1.8;
        if (p.life <= 0) {
          dust.splice(i, 1);
          continue;
        }
        ctx.fillStyle = `rgba(200,255,0,${p.life * 0.45})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 2.6 * p.life, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.save();
      ctx.setLineDash([5, 8]);
      ctx.strokeStyle = `rgba(200,255,0,${0.18 + idleMix * 0.2})`;
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      ctx.moveTo(car.x, car.y);
      ctx.lineTo(finger.x, finger.y);
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.restore();

      drawHeadlights();
      drawCar();
      drawAim(idleMix);
      drawFinger(idleMix);

      rafId = requestAnimationFrame(tick);
    };

    resize();
    window.addEventListener('resize', resize);
    window.addEventListener('mousemove', onMouseMove, { passive: true });
    window.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    rafId = requestAnimationFrame(tick);

    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchmove', onTouchMove);
      cancelAnimationFrame(rafId);
    };
  }, []);

  return <canvas ref={canvasRef} className="mouse-car-layer" aria-hidden="true" />;
}

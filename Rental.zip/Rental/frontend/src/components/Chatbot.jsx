import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiMessageCircle, FiSend, FiX, FiMinimize2 } from 'react-icons/fi';
import { BsStars } from 'react-icons/bs';

const SUGGESTIONS = [
  'How do I book a car?',
  'Demo login',
  'Digital car key',
  'Pricing & GST',
  'What documents do I need?'
];

function replyFor(raw) {
  const q = (raw || '').toLowerCase().trim();

  if (!q) {
    return 'Ask me anything about DriveEase — booking, digital keys, invoices, or demo login.';
  }

  if (/(hello|hi|hey|namaste)/.test(q)) {
    return 'Hey! I am EaseBot, your DriveEase concierge. I can help you book a self-drive car, explain keyless unlock, demo login, invoices, and OTP. What do you need?';
  }

  if (/(login|demo|password|admin|sign in|signin)/.test(q)) {
    return 'Quick demo accounts (also on the Sign In page):\n\n• User: ankul@demo.com / demo1234\n• Admin: admin@driveease.com / admin123\n\nOTP shortcut for judges: 123456. Use Sign In → 1-click demo buttons for the fastest walkthrough.';
  }

  if (/(otp|verify|email|gmail)/.test(q)) {
    return 'OTP works without Gmail setup. The code is printed in the terminal as 🔑 Verification Code. Shortcut code 123456 always works. If SMTP is set in backend/.env, real mail is sent too.';
  }

  if (/(book|reserve|rent|how (do|to) book|start)/.test(q)) {
    return 'Booking in 4 steps:\n1. Open Fleet and pick a car\n2. Choose city, dates, extras\n3. Pay with Card / UPI / NetBanking (demo gateway)\n4. Open My Trips → Digital Key to unlock\n\nWant me to take you to the fleet? Tap “Browse cars” below.';
  }

  if (/(key|unlock|fob|telematic|bluetooth|ble)/.test(q)) {
    return 'Every paid trip gets a BLE 5.3 digital key. Go to My Trips → Digital Key. You get a 4-digit PIN plus lock / unlock / horn / start on the virtual fob. No physical handover at a counter.';
  }

  if (/(price|pricing|cost|gst|invoice|cheap|₹|rs)/.test(q)) {
    return 'Tariffs start at ₹69/hr depending on the car. Checkout shows a full GST breakdown. After payment, download / print the tax invoice from My Trips. No hidden counter deposits in the demo flow.';
  }

  if (/(document|license|dl|aadhaar|id proof)/.test(q)) {
    return 'You need a valid Indian Driving Licence (or IDP) and a photo ID (Aadhaar / Passport). Upload is on the driver profile. For this hackathon demo, the booking flow still works with the demo user.';
  }

  if (/(fuel|petrol|diesel|ev|charge|mileage)/.test(q)) {
    return 'Fuel is not bundled in the base fare. Use the AI Route Planner on Home or the car page to estimate highway fuel / EV range before you pay.';
  }

  if (/(city|where|airport|hub|mumbai|delhi|bangalore|goa)/.test(q)) {
    return 'DriveEase is live across 25+ Indian cities and airport hubs — Mumbai, Delhi NCR, Bangalore, Goa, Pune and more. Search a city on Home, then filter the fleet.';
  }

  if (/(cancel|refund|extend)/.test(q)) {
    return 'Open My Trips to cancel a pending/upcoming booking or extend an active trip (subject to availability). Refunds in this demo are simulated in the dashboard status.';
  }

  if (/(admin|fleet manage|approve)/.test(q)) {
    return 'Sign in as admin@driveease.com / admin123 to see fleet and booking management. Judges can switch between user and admin in seconds from the login page.';
  }

  if (/(contact|support|help|phone|roadside)/.test(q)) {
    return '24/7 helpline: 1800-DRIVE-EASE · support@driveease.com. Roadside assistance is included on confirmed trips. You can also use the Contact page for hub details.';
  }

  if (/(hackathon|win|feature|what can|about)/.test(q)) {
    return 'DriveEase is a full-stack mobility demo: keyless telematics, GST invoices, OTP auth, UPI/card checkout, AI fuel planner, admin fleet view, and this concierge bot — all runnable with one start script.';
  }

  return 'I can help with booking, digital keys, demo login, pricing, OTP, documents, and invoices. Try: “How do I book a car?” or “Demo login”.';
}

export default function Chatbot() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [typing, setTyping] = useState(false);
  const [messages, setMessages] = useState([
    {
      role: 'bot',
      text: 'Hi, I am EaseBot. Ask me how to book, unlock with the digital key, or use the demo login. Built for a clean judge walkthrough.'
    }
  ]);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, typing, open]);

  const pushBot = (text) => {
    setTyping(true);
    window.setTimeout(() => {
      setMessages((prev) => [...prev, { role: 'bot', text }]);
      setTyping(false);
    }, 420);
  };

  const send = (text) => {
    const value = (text ?? input).trim();
    if (!value || typing) return;
    setMessages((prev) => [...prev, { role: 'user', text: value }]);
    setInput('');
    pushBot(replyFor(value));
  };

  return (
    <div className="easebot">
      {open && (
        <div className="easebot-panel" role="dialog" aria-label="DriveEase chatbot">
          <div className="easebot-head">
            <div className="easebot-head-left">
              <div className="easebot-avatar">
                <BsStars size={16} />
              </div>
              <div>
                <strong>EaseBot</strong>
                <span>DriveEase concierge · online</span>
              </div>
            </div>
            <div className="easebot-head-actions">
              <button type="button" onClick={() => setOpen(false)} aria-label="Minimize chat">
                <FiMinimize2 size={16} />
              </button>
              <button type="button" onClick={() => setOpen(false)} aria-label="Close chat">
                <FiX size={16} />
              </button>
            </div>
          </div>

          <div className="easebot-body">
            {messages.map((m, i) => (
              <div key={i} className={`easebot-msg ${m.role}`}>
                {m.text.split('\n').map((line, j) => (
                  <p key={j}>{line || '\u00a0'}</p>
                ))}
              </div>
            ))}
            {typing && (
              <div className="easebot-msg bot typing">
                <span />
                <span />
                <span />
              </div>
            )}
            <div ref={endRef} />
          </div>

          <div className="easebot-chips">
            {SUGGESTIONS.map((s) => (
              <button key={s} type="button" onClick={() => send(s)}>
                {s}
              </button>
            ))}
            <button type="button" className="accent" onClick={() => { setOpen(false); navigate('/cars'); }}>
              Browse cars
            </button>
          </div>

          <form
            className="easebot-input"
            onSubmit={(e) => {
              e.preventDefault();
              send();
            }}
          >
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about booking, keys, login…"
              aria-label="Chat message"
            />
            <button type="submit" aria-label="Send">
              <FiSend size={16} />
            </button>
          </form>
        </div>
      )}

      <button
        type="button"
        className={`easebot-fab ${open ? 'open' : ''}`}
        onClick={() => setOpen((v) => !v)}
        aria-label={open ? 'Close chatbot' : 'Open chatbot'}
      >
        {open ? <FiX size={22} /> : <FiMessageCircle size={22} />}
        {!open && <span className="easebot-fab-label">Ask EaseBot</span>}
      </button>
    </div>
  );
}

import { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiSearch, FiCreditCard, FiKey, FiMapPin, FiChevronDown, FiChevronUp, FiArrowRight, FiCheckCircle } from 'react-icons/fi';
import { BsLightningChargeFill } from 'react-icons/bs';

const steps = [
  {
    num: '01',
    title: 'Choose Your Ride',
    desc: 'Browse 500+ premium verified sedans, SUVs, luxury cars, and EVs across 25+ cities. Filter by price, transmission, or fuel type.',
    icon: <FiSearch size={28} />,
    color: '#c8ff00'
  },
  {
    num: '02',
    title: 'Instant Book & Demo Pay',
    desc: 'Select your pickup & drop-off dates. Confirm your reservation instantly with our demo payment gateway (Card, UPI QR, or Netbanking).',
    icon: <FiCreditCard size={28} />,
    color: '#00f0ff'
  },
  {
    num: '03',
    title: 'Unlock with Digital Key',
    desc: 'Receive your confirmation email with 4-digit security PIN. Use the in-app Smart Telematics Remote Fob to unlock doors keylessly.',
    icon: <FiKey size={28} />,
    color: '#ffb547'
  },
  {
    num: '04',
    title: 'Drive & Easy Return',
    desc: 'Enjoy unlimited freedom on open highways. At trip end, park at the designated DriveEase hub or schedule doorstep vehicle pickup.',
    icon: <FiMapPin size={28} />,
    color: '#00d68f'
  }
];

const faqs = [
  {
    q: 'What documents are required to book a car?',
    a: 'You only need a valid Indian Driving License (or International Driving Permit for foreign nationals) and Government Photo ID (Aadhaar / Passport). Upload takes under 60 seconds.'
  },
  {
    q: 'Is fuel included in the rental price?',
    a: 'We offer flexible fuel plans: either pick up with a full tank and return with full tank, or use our Smart AI Trip & Fuel Estimator to budget exact fuel expenses.'
  },
  {
    q: 'What if my flight is delayed or I need to extend my trip?',
    a: 'You can extend your active trip directly through the DriveEase dashboard with 1 click, subject to vehicle availability.'
  },
  {
    q: 'How does the Digital Car Key work?',
    a: 'Every vehicle is fitted with encrypted Bluetooth 5.3 telematics hardware. Once your booking is confirmed, your mobile acts as an authentic remote key fob to unlock, lock, and start the car.'
  }
];

export default function HowItWorks() {
  const [openFaq, setOpenFaq] = useState(0);

  return (
    <div className="how-it-works-page" style={{ paddingTop: 90, paddingBottom: 80 }}>
      {/* Hero */}
      <section style={{ textAlign: 'center', padding: '60px 20px 40px', maxWidth: 860, margin: '0 auto' }}>
        <div className="section-tag" style={{ margin: '0 auto 12px' }}>KEYLESS MOBILITY EXPLAINED</div>
        <h1 style={{ fontSize: 44, letterSpacing: '-1.5px', marginBottom: 16 }}>
          How <span style={{ color: 'var(--accent)' }}>DriveEase</span> Works
        </h1>
        <p style={{ fontSize: 17, color: 'var(--text-secondary)', lineHeight: 1.7 }}>
          Experience a completely frictionless car rental journey in 4 simple steps. No paper forms, no waiting in line.
        </p>
      </section>

      {/* 4 Steps Grid */}
      <section style={{ maxWidth: 1100, margin: '0 auto 70px', padding: '0 20px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: 20 }}>
          {steps.map((s, idx) => (
            <div
              key={idx}
              className="category-card"
              style={{
                textAlign: 'left',
                padding: '32px 24px',
                position: 'relative',
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'space-between'
              }}
            >
              <div>
                <div style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: 20
                }}>
                  <div style={{
                    width: 54,
                    height: 54,
                    borderRadius: 'var(--radius-md)',
                    background: 'rgba(255,255,255,0.04)',
                    border: `1px solid ${s.color}`,
                    color: s.color,
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center'
                  }}>
                    {s.icon}
                  </div>
                  <span style={{
                    fontFamily: 'Space Grotesk',
                    fontSize: 32,
                    fontWeight: 800,
                    color: 'rgba(255,255,255,0.1)'
                  }}>
                    {s.num}
                  </span>
                </div>
                <h3 style={{ fontSize: 18, marginBottom: 10 }}>{s.title}</h3>
                <p style={{ fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Interactive FAQ Section */}
      <section style={{ maxWidth: 860, margin: '0 auto 80px', padding: '0 20px' }}>
        <div className="section-header" style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{ margin: '0 auto' }}>
            <div className="section-tag">FREQUENTLY ASKED QUESTIONS</div>
            <h2>Got Questions? We Have Answers.</h2>
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {faqs.map((faq, i) => (
            <div
              key={i}
              onClick={() => setOpenFaq(openFaq === i ? -1 : i)}
              style={{
                background: 'var(--bg-tertiary)',
                border: '1px solid var(--border-color)',
                borderRadius: 'var(--radius-md)',
                padding: '20px 24px',
                cursor: 'pointer',
                transition: 'var(--transition)'
              }}
            >
              <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                fontWeight: 600,
                fontSize: 16
              }}>
                <span>{faq.q}</span>
                {openFaq === i ? <FiChevronUp color="var(--accent)" /> : <FiChevronDown />}
              </div>
              {openFaq === i && (
                <div style={{
                  marginTop: 14,
                  fontSize: 14,
                  color: 'var(--text-secondary)',
                  lineHeight: 1.6,
                  borderTop: '1px solid rgba(255,255,255,0.06)',
                  paddingTop: 12
                }}>
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section style={{ maxWidth: 900, margin: '0 auto', padding: '0 20px', textAlign: 'center' }}>
        <div style={{
          background: 'linear-gradient(135deg, rgba(200,255,0,0.12) 0%, rgba(0,240,255,0.08) 100%)',
          border: '1px solid rgba(200,255,0,0.3)',
          borderRadius: 'var(--radius-xl)',
          padding: '48px 30px'
        }}>
          <h2 style={{ fontSize: 32, marginBottom: 12 }}>Ready for Your Next Road Trip?</h2>
          <p style={{ fontSize: 15, color: 'var(--text-secondary)', marginBottom: 24, maxWidth: 500, margin: '0 auto 24px' }}>
            Join 50,000+ drivers who enjoy the convenience of keyless, sanitized self-drive rentals.
          </p>
          <Link to="/cars" className="btn btn-primary btn-lg">
            Browse All Cars <FiArrowRight />
          </Link>
        </div>
      </section>
    </div>
  );
}

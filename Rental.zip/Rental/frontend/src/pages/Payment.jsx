import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { bookingsAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { FiCreditCard, FiSmartphone, FiCheck, FiLock, FiShield, FiMail, FiPrinter, FiKey, FiCheckCircle, FiRefreshCw, FiZap, FiAlertCircle, FiXCircle } from 'react-icons/fi';
import { BsBank, BsWallet2, BsKey } from 'react-icons/bs';
import EmailModal from '../components/EmailModal';
import DigitalKeyModal from '../components/DigitalKeyModal';
import InvoiceModal from '../components/InvoiceModal';

export default function Payment() {
  const { bookingId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();

  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState(1);
  const [showSuccess, setShowSuccess] = useState(false);
  const [transactionId, setTransactionId] = useState('');
  const [emailPreviewUrl, setEmailPreviewUrl] = useState('');

  // OTP Verification States
  const [otpCode, setOtpCode] = useState('');
  const [otpVerified, setOtpVerified] = useState(false);
  const [serverOtp, setServerOtp] = useState('');
  const [sendingOtp, setSendingOtp] = useState(false);
  const [otpTimer, setOtpTimer] = useState(60);

  // Modals
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [showInvoiceModal, setShowInvoiceModal] = useState(false);

  // Payment Form States
  const [paymentMethod, setPaymentMethod] = useState('card');
  const [cardData, setCardData] = useState({
    cardNumber: '4242 4242 4242 4242',
    cardName: 'ANKUL SHARMA',
    expiry: '12/28',
    cvv: '888',
  });
  const [upiId, setUpiId] = useState('ankul@okaxis');
  const [selectedBank, setSelectedBank] = useState('HDFC');
  const [selectedWallet, setSelectedWallet] = useState('paytm');
  const [upiCountdown, setUpiCountdown] = useState(300);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    loadBooking();
  }, [bookingId]);

  // UPI Timer
  useEffect(() => {
    if (paymentMethod !== 'upi') return;
    const timer = setInterval(() => {
      setUpiCountdown((prev) => (prev > 0 ? prev - 1 : 300));
    }, 1000);
    return () => clearInterval(timer);
  }, [paymentMethod]);

  // OTP countdown timer
  useEffect(() => {
    if (otpTimer <= 0) return;
    const interval = setInterval(() => setOtpTimer(prev => prev - 1), 1000);
    return () => clearInterval(interval);
  }, [otpTimer]);

  const loadBooking = async () => {
    try {
      const res = await bookingsAPI.getById(bookingId);
      const bkg = res.data.booking;
      if (bkg.payment?.status === 'completed') {
        toast.success('This booking is already paid!');
        navigate('/dashboard');
        return;
      }
      setBooking(bkg);
      if (user?.firstName) {
        setCardData(prev => ({ ...prev, cardName: `${user.firstName} ${user.lastName || ''}`.toUpperCase() }));
      }

      // Automatically dispatch initial OTP to phone & email
      requestOtp();
    } catch (err) {
      toast.error('Booking not found');
      navigate('/dashboard');
    } finally {
      setLoading(false);
    }
  };

  const requestOtp = async () => {
    setSendingOtp(true);
    try {
      const res = await bookingsAPI.sendOtp(bookingId);
      setServerOtp(res.data.demoOtp || '849201');
      setOtpTimer(60);
      toast.success(`OTP sent to +91-${user?.phone || '9876543210'} & email!`, {
        duration: 4500
      });
    } catch (err) {
      console.warn('OTP dispatch notice:', err.message);
    } finally {
      setSendingOtp(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (!otpCode || otpCode.length < 6) {
      toast.error('Please enter the 6-digit OTP');
      return;
    }
    try {
      await bookingsAPI.verifyOtp(bookingId, otpCode);
      setOtpVerified(true);
      toast.success('✓ Identity & Phone Number Verified!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid OTP code');
    }
  };

  const formatCardNumber = (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 16);
    return digits.replace(/(\d{4})(?=\d)/g, '$1 ');
  };

  const formatExpiry = (value) => {
    const digits = value.replace(/\D/g, '').slice(0, 4);
    if (digits.length >= 3) return digits.slice(0, 2) + '/' + digits.slice(2);
    return digits;
  };

  const fillDemoCard = (shouldFail = false) => {
    if (shouldFail) {
      setCardData({
        cardNumber: '4242 4242 4242 0000',
        cardName: 'DECLINE TEST',
        expiry: '10/26',
        cvv: '000'
      });
      toast.error('Filled test card configured to simulate bank decline');
    } else {
      setCardData({
        cardNumber: '4242 4242 4242 4242',
        cardName: (user ? `${user.firstName} ${user.lastName}` : 'ANKUL SHARMA').toUpperCase(),
        expiry: '12/28',
        cvv: '888'
      });
      toast.success('Filled valid demo card');
    }
  };

  const handlePayment = async () => {
    // Check OTP verification
    if (!otpVerified) {
      if (!otpCode || otpCode.length < 6) {
        toast.error('Please enter and verify the 6-digit OTP sent to your phone/email first');
        return;
      }
      try {
        await bookingsAPI.verifyOtp(bookingId, otpCode);
        setOtpVerified(true);
      } catch (err) {
        toast.error('Invalid OTP code. Please check your SMS/email.');
        return;
      }
    }

    if (paymentMethod === 'card') {
      const rawCard = cardData.cardNumber.replace(/\s/g, '');
      if (rawCard.length < 16) { toast.error('Enter valid 16-digit card number'); return; }
      if (!cardData.cardName) { toast.error('Enter cardholder name'); return; }
      if (cardData.expiry.length < 5) { toast.error('Enter valid expiry (MM/YY)'); return; }
      if (cardData.cvv.length < 3) { toast.error('Enter valid CVV'); return; }
    } else if (paymentMethod === 'upi') {
      if (!upiId || !upiId.includes('@')) { toast.error('Enter a valid UPI ID (e.g., name@okaxis)'); return; }
    }

    setProcessing(true);
    setProcessingStep(1);

    setTimeout(() => setProcessingStep(2), 700);
    setTimeout(() => setProcessingStep(3), 1400);

    try {
      const payload = {
        method: paymentMethod,
        cardNumber: cardData.cardNumber.replace(/\s/g, ''),
        cardName: cardData.cardName,
        expiry: cardData.expiry,
        cvv: cardData.cvv,
        upiId,
        bank: selectedBank,
        wallet: selectedWallet
      };

      await new Promise(r => setTimeout(r, 1800));

      const res = await bookingsAPI.processPayment(bookingId, payload);
      setTransactionId(res.data.transactionId);
      setEmailPreviewUrl(res.data.emailPreviewUrl || '');
      setShowSuccess(true);
      toast.success('Payment verified! Confirmation email dispatched.');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Payment failed. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-container" style={{ minHeight: '80vh' }}>
        <div className="spinner"></div>
        <p className="loading-text">Loading secure payment gateway...</p>
      </div>
    );
  }

  if (!booking) return null;

  const car = booking.car;
  const isCard = paymentMethod === 'card';
  const cardBrand = cardData.cardNumber.startsWith('4') ? 'VISA' : (cardData.cardNumber.startsWith('5') ? 'MASTERCARD' : 'RUPAY');

  const formatTimer = (secs) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="payment-page">
      {/* Modals */}
      {showEmailModal && (
        <EmailModal
          bookingId={bookingId}
          previewUrl={emailPreviewUrl}
          onClose={() => setShowEmailModal(false)}
        />
      )}

      {showKeyModal && (
        <DigitalKeyModal
          booking={booking}
          onClose={() => setShowKeyModal(false)}
        />
      )}

      {showInvoiceModal && (
        <InvoiceModal
          booking={booking}
          onClose={() => setShowInvoiceModal(false)}
        />
      )}

      {/* Payment Processing Overlay */}
      {processing && (
        <div className="gateway-processing-overlay">
          <div className="gateway-processing-card">
            <div className="gateway-spinner"></div>
            <h3>Processing Secure Transaction</h3>
            <div className="gateway-steps">
              <div className={`step-item ${processingStep >= 1 ? 'active' : ''}`}>
                <FiLock size={14} /> 1. Initializing 256-bit SSL Banking Handshake
              </div>
              <div className={`step-item ${processingStep >= 2 ? 'active' : ''}`}>
                <FiShield size={14} /> 2. Authorizing ₹{booking.pricing?.totalAmount?.toLocaleString('en-IN')} with Issuer
              </div>
              <div className={`step-item ${processingStep >= 3 ? 'active' : ''}`}>
                <FiCheck size={14} /> 3. Dispatching Confirmation Email & Digital Key
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccess && (
        <div className="payment-success-modal">
          <div className="payment-success-card">
            <div className="success-icon">
              <FiCheck size={40} />
            </div>
            <h3>Reservation Confirmed!</h3>
            <p>Your booking for <strong>{car?.name}</strong> has been secured and paid in full.</p>

            <div className="transaction-id">
              <span>TRANSACTION ID</span>
              <strong>{transactionId}</strong>
            </div>

            {/* Email Dispatch Notice */}
            <div className="email-dispatched-box">
              <div className="email-dispatched-icon"><FiMail size={20} /></div>
              <div>
                <div className="email-dispatched-title">Confirmation Email Dispatched</div>
                <div className="email-dispatched-sub">Official itinerary and digital PIN sent to <strong>{user?.email}</strong></div>
              </div>
            </div>

            {/* Feature Action Buttons */}
            <div className="success-actions-grid">
              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setShowEmailModal(true)}
              >
                <FiMail size={16} /> View Dispatched Email
              </button>

              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setShowKeyModal(true)}
              >
                <BsKey size={16} /> Open Digital Key
              </button>

              <button
                className="btn btn-secondary btn-sm"
                onClick={() => setShowInvoiceModal(true)}
              >
                <FiPrinter size={16} /> Print Tax Invoice
              </button>
            </div>

            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', marginTop: 24 }}>
              <button className="btn btn-primary" onClick={() => navigate('/dashboard')}>
                Go to My Trips
              </button>
              <button className="btn btn-ghost" onClick={() => navigate('/cars')}>
                Browse More Cars
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="payment-page-header">
        <h2>Complete Secure Checkout</h2>
        <p>Instant reservation & digital key issuance for your {car?.name}</p>
      </div>

      <div className="payment-grid">
        {/* Left: Payment Options & Interactive Forms */}
        <div className="payment-left-col">

          {/* OTP Security Verification Step */}
          <div style={{
            background: 'var(--bg-tertiary)',
            border: otpVerified ? '1px solid rgba(0,214,143,0.3)' : '1px solid rgba(200,255,0,0.25)',
            borderRadius: 'var(--radius-lg)',
            padding: '20px 24px',
            marginBottom: 24
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <FiShield size={18} style={{ color: otpVerified ? 'var(--success)' : 'var(--accent)' }} />
                <strong style={{ fontSize: 14 }}>Security OTP Verification</strong>
              </div>
              <span style={{
                fontSize: 11,
                fontWeight: 700,
                textTransform: 'uppercase',
                padding: '4px 10px',
                borderRadius: 20,
                background: otpVerified ? 'rgba(0,214,143,0.15)' : 'rgba(200,255,0,0.15)',
                color: otpVerified ? 'var(--success)' : 'var(--accent)'
              }}>
                {otpVerified ? '✓ Verified' : 'Step 1 of 2'}
              </span>
            </div>

            <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 14 }}>
              We sent a 6-digit OTP code to <strong>+91-{user?.phone || '9876543210'}</strong> and <strong>{user?.email}</strong>.
            </p>

            <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
              <input
                type="text"
                placeholder="Enter 6-digit OTP"
                maxLength={6}
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                disabled={otpVerified}
                style={{
                  width: 180,
                  padding: '10px 14px',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-sm)',
                  color: '#fff',
                  fontFamily: 'Space Grotesk, monospace',
                  fontSize: 16,
                  letterSpacing: 3,
                  textAlign: 'center'
                }}
              />

              {!otpVerified ? (
                <>
                  <button
                    type="button"
                    className="btn btn-secondary btn-sm"
                    onClick={() => {
                      const code = serverOtp || '849201';
                      setOtpCode(code);
                      setOtpVerified(true);
                      toast.success(`Auto-filled & verified OTP ${code}!`);
                    }}
                    style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                  >
                    <FiZap size={14} /> Auto-fill OTP ({serverOtp || '849201'})
                  </button>

                  <button
                    type="button"
                    className="btn btn-primary btn-sm"
                    onClick={handleVerifyOtp}
                    disabled={otpCode.length < 6}
                  >
                    Verify OTP
                  </button>
                </>
              ) : (
                <span style={{ fontSize: 13, color: 'var(--success)', display: 'flex', alignItems: 'center', gap: 4, fontWeight: 600 }}>
                  <FiCheckCircle /> Verified Successfully
                </span>
              )}

              <button
                type="button"
                className="btn btn-ghost btn-sm"
                onClick={requestOtp}
                disabled={sendingOtp || otpTimer > 0}
                style={{ fontSize: 12, marginLeft: 'auto' }}
              >
                {sendingOtp ? <FiRefreshCw className="spin" /> : null}
                {otpTimer > 0 ? `Resend in ${otpTimer}s` : 'Resend OTP'}
              </button>
            </div>
          </div>

          <div className="payment-methods-tabs">
            {[
              { id: 'card', icon: <FiCreditCard size={18} />, label: 'Card Payment' },
              { id: 'upi', icon: <FiSmartphone size={18} />, label: 'UPI / QR Code' },
              { id: 'netbanking', icon: <BsBank size={18} />, label: 'Net Banking' },
              { id: 'wallet', icon: <BsWallet2 size={18} />, label: 'Digital Wallets' },
            ].map(tab => (
              <button
                key={tab.id}
                className={`method-tab-btn ${paymentMethod === tab.id ? 'active' : ''}`}
                onClick={() => setPaymentMethod(tab.id)}
              >
                {tab.icon}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* CARD PAYMENT WITH VIRTUAL 3D CARD */}
          {paymentMethod === 'card' && (
            <div>
              {/* Virtual Credit Card Display */}
              <div className="virtual-card">
                <div className="card-gloss"></div>
                <div className="card-header-row">
                  <div className="card-chip"></div>
                  <div className="card-brand-badge">{cardBrand}</div>
                </div>

                <div className="card-number-display">
                  {cardData.cardNumber || '•••• •••• •••• ••••'}
                </div>

                <div className="card-footer-row">
                  <div>
                    <div className="card-label">CARDHOLDER</div>
                    <div className="card-val">{cardData.cardName || 'YOUR NAME'}</div>
                  </div>
                  <div>
                    <div className="card-label">EXPIRES</div>
                    <div className="card-val">{cardData.expiry || 'MM/YY'}</div>
                  </div>
                </div>
              </div>

              {/* Quick autofill chips */}
              <div className="demo-card-autofill-row">
                <button
                  type="button"
                  className="quick-chip success"
                  onClick={() => fillDemoCard(false)}
                  style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                >
                  <FiZap size={13} /> Use Demo Card (Success)
                </button>
                <button
                  type="button"
                  className="quick-chip danger"
                  onClick={() => fillDemoCard(true)}
                  style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                >
                  <FiXCircle size={13} /> Use Test Card (Decline Test)
                </button>
              </div>

              {/* Card Form */}
              <div className="card-form-body">
                <div className="form-group">
                  <label>Card Number</label>
                  <input
                    type="text"
                    placeholder="4242 4242 4242 4242"
                    value={cardData.cardNumber}
                    onChange={(e) => setCardData({ ...cardData, cardNumber: formatCardNumber(e.target.value) })}
                    maxLength={19}
                  />
                </div>

                <div className="form-group">
                  <label>Cardholder Name</label>
                  <input
                    type="text"
                    placeholder="ANKUL SHARMA"
                    value={cardData.cardName}
                    onChange={(e) => setCardData({ ...cardData, cardName: e.target.value.toUpperCase() })}
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Expiry Date</label>
                    <input
                      type="text"
                      placeholder="MM/YY"
                      value={cardData.expiry}
                      onChange={(e) => setCardData({ ...cardData, expiry: formatExpiry(e.target.value) })}
                      maxLength={5}
                    />
                  </div>
                  <div className="form-group">
                    <label>CVV / CVC</label>
                    <input
                      type="password"
                      placeholder="•••"
                      value={cardData.cvv}
                      onChange={(e) => setCardData({ ...cardData, cvv: e.target.value.replace(/\D/g, '').slice(0, 4) })}
                      maxLength={4}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* UPI PAYMENT WITH DYNAMIC QR CODE */}
          {paymentMethod === 'upi' && (
            <div className="upi-payment-container">
              <div className="upi-qr-card">
                <div className="qr-badge">SCAN TO PAY WITH ANY UPI APP</div>
                <div className="qr-box">
                  <svg viewBox="0 0 160 160" width="160" height="160" className="qr-svg">
                    <rect width="160" height="160" fill="#ffffff" rx="8" />
                    <rect x="12" y="12" width="40" height="40" fill="#0c0d14" rx="4" />
                    <rect x="20" y="20" width="24" height="24" fill="#ffffff" />
                    <rect x="26" y="26" width="12" height="12" fill="#0c0d14" />

                    <rect x="108" y="12" width="40" height="40" fill="#0c0d14" rx="4" />
                    <rect x="116" y="20" width="24" height="24" fill="#ffffff" />
                    <rect x="122" y="26" width="12" height="12" fill="#0c0d14" />

                    <rect x="12" y="108" width="40" height="40" fill="#0c0d14" rx="4" />
                    <rect x="20" y="116" width="24" height="24" fill="#ffffff" />
                    <rect x="26" y="122" width="12" height="12" fill="#0c0d14" />

                    <rect x="60" y="20" width="12" height="12" fill="#0c0d14" />
                    <rect x="80" y="24" width="16" height="12" fill="#0c0d14" />
                    <rect x="64" y="44" width="28" height="12" fill="#0c0d14" />
                    <rect x="16" y="64" width="20" height="16" fill="#0c0d14" />
                    <rect x="44" y="68" width="16" height="16" fill="#0c0d14" />
                    <rect x="68" y="68" width="24" height="24" fill="#c8ff00" rx="4" />
                    <rect x="100" y="64" width="20" height="20" fill="#0c0d14" />
                    <rect x="128" y="68" width="20" height="16" fill="#0c0d14" />
                    <rect x="60" y="104" width="24" height="12" fill="#0c0d14" />
                    <rect x="92" y="108" width="16" height="24" fill="#0c0d14" />
                    <rect x="116" y="116" width="32" height="16" fill="#0c0d14" />
                    <rect x="124" y="140" width="20" height="12" fill="#0c0d14" />
                    <rect x="64" y="128" width="20" height="20" fill="#0c0d14" />
                  </svg>
                </div>
                <div className="qr-timer">
                  QR Expires in: <strong>{formatTimer(upiCountdown)}</strong>
                </div>
                <div className="upi-apps-icons">
                  <span>Google Pay</span> • <span>PhonePe</span> • <span>Paytm</span> • <span>CRED</span>
                </div>
              </div>

              <div className="form-group" style={{ marginTop: 20 }}>
                <label>Or enter UPI ID / VPA</label>
                <input
                  type="text"
                  placeholder="yourname@okhdfcbank"
                  value={upiId}
                  onChange={(e) => setUpiId(e.target.value)}
                />
              </div>

              <button
                type="button"
                className="btn btn-secondary btn-block"
                style={{ marginTop: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}
                onClick={() => {
                  toast.success('Simulated UPI notification sent to phone');
                  handlePayment();
                }}
              >
                <FiZap size={16} /> Simulate Instant UPI Mobile Approval
              </button>
            </div>
          )}

          {/* NET BANKING */}
          {paymentMethod === 'netbanking' && (
            <div className="bank-grid">
              {[
                { id: 'HDFC', name: 'HDFC Bank', code: 'hdfc' },
                { id: 'ICICI', name: 'ICICI Bank', code: 'icici' },
                { id: 'SBI', name: 'State Bank of India', code: 'sbi' },
                { id: 'AXIS', name: 'Axis Bank', code: 'axis' },
                { id: 'KOTAK', name: 'Kotak Mahindra', code: 'kotak' },
                { id: 'PNB', name: 'Punjab National Bank', code: 'pnb' },
              ].map(bank => (
                <div
                  key={bank.id}
                  className={`bank-item ${selectedBank === bank.id ? 'selected' : ''}`}
                  onClick={() => setSelectedBank(bank.id)}
                >
                  <div className="bank-radio"></div>
                  <div className="bank-name">{bank.name}</div>
                </div>
              ))}
            </div>
          )}

          {/* WALLETS */}
          {paymentMethod === 'wallet' && (
            <div className="wallet-options">
              {[
                { id: 'paytm', name: 'Paytm Wallet & Postpaid' },
                { id: 'amazon', name: 'Amazon Pay Balance' },
                { id: 'phonepe', name: 'PhonePe Wallet' },
              ].map(wallet => (
                <div
                  key={wallet.id}
                  className={`payment-method-option ${selectedWallet === wallet.id ? 'selected' : ''}`}
                  onClick={() => setSelectedWallet(wallet.id)}
                >
                  <div className="payment-method-radio"></div>
                  <div className="payment-method-name">{wallet.name}</div>
                </div>
              ))}
            </div>
          )}

          {/* Pay Button */}
          <button
            className="btn btn-primary btn-block btn-lg"
            style={{ marginTop: 24 }}
            onClick={handlePayment}
            disabled={processing}
          >
            Pay ₹{booking.pricing?.totalAmount?.toLocaleString('en-IN')} & Confirm Ride
          </button>
        </div>

        {/* Right: Booking Summary Order Card */}
        <div className="payment-right-col">
          <div className="order-summary-card">
            <h3 className="summary-title">Booking Summary</h3>

            <div className="summary-car-card">
              {car?.images && car.images[0] && (
                <img src={car.images[0]} alt={car.name} className="summary-car-img" />
              )}
              <div className="summary-car-info">
                <h4>{car?.name}</h4>
                <p>{car?.brand} • {car?.category} • {car?.transmission}</p>
                <div className="summary-plate">{car?.registrationNumber || 'MH-01-AB-1234'}</div>
              </div>
            </div>

            <div className="summary-dates-box">
              <div className="summary-date-col">
                <span className="date-label">PICKUP</span>
                <strong>{new Date(booking.pickupDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</strong>
                <span>{new Date(booking.pickupDate).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <div className="summary-date-arrow">➔</div>
              <div className="summary-date-col">
                <span className="date-label">DROPOFF</span>
                <strong>{new Date(booking.dropoffDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}</strong>
                <span>{new Date(booking.dropoffDate).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
            </div>

            <div className="summary-line-items">
              <div className="line-item">
                <span>Rental Duration</span>
                <span>{Math.ceil(booking.totalHours / 24)} Days ({booking.totalHours} hrs)</span>
              </div>
              <div className="line-item">
                <span>Base Fare</span>
                <span>₹{booking.pricing?.basePrice?.toLocaleString('en-IN')}</span>
              </div>
              {booking.extras?.insurance && (
                <div className="line-item">
                  <span>Damage Protection</span>
                  <span>₹{booking.pricing?.insuranceFee?.toLocaleString('en-IN')}</span>
                </div>
              )}
              <div className="line-item">
                <span>Platform Fee (5%)</span>
                <span>₹{booking.pricing?.serviceFee?.toLocaleString('en-IN')}</span>
              </div>
              <div className="line-item">
                <span>GST (18%)</span>
                <span>₹{booking.pricing?.gst?.toLocaleString('en-IN')}</span>
              </div>

              <div className="line-item total">
                <span>Total Payable</span>
                <span className="total-amount">₹{booking.pricing?.totalAmount?.toLocaleString('en-IN')}</span>
              </div>
            </div>

            <div className="security-badge-box">
              <FiShield size={16} style={{ color: 'var(--accent)' }} />
              <div>
                <strong>Guaranteed Booking</strong>
                <p>Full refund available up to 6 hours before pickup time</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

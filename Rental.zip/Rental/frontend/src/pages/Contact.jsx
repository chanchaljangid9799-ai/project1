import { useState } from 'react';
import { FiPhone, FiMail, FiMapPin, FiClock, FiSend, FiCheckCircle } from 'react-icons/fi';
import toast from 'react-hot-toast';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', subject: 'booking', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error('Please fill in all required fields');
      return;
    }
    setSubmitted(true);
    toast.success('Your message has been received! Our 24/7 concierge will reply shortly.');
    setForm({ name: '', email: '', subject: 'booking', message: '' });
  };

  return (
    <div className="contact-page" style={{ paddingTop: 90, paddingBottom: 80 }}>
      {/* Hero */}
      <section style={{ textAlign: 'center', padding: '60px 20px 40px', maxWidth: 860, margin: '0 auto' }}>
        <div className="section-tag" style={{ margin: '0 auto 12px' }}>WE'RE HERE 24/7</div>
        <h1 style={{ fontSize: 44, letterSpacing: '-1.5px', marginBottom: 16 }}>
          Get in Touch with <span style={{ color: 'var(--accent)' }}>DriveEase</span>
        </h1>
        <p style={{ fontSize: 17, color: 'var(--text-secondary)', lineHeight: 1.7 }}>
          Have questions about your rental, corporate fleet bookings, or roadside emergency? Reach out directly.
        </p>
      </section>

      <div style={{
        maxWidth: 1100,
        margin: '0 auto',
        padding: '0 20px',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
        gap: 40
      }}>
        {/* Left: Contact Info & Hubs */}
        <div>
          <h2 style={{ fontSize: 24, marginBottom: 20 }}>Direct Support Channels</h2>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 36 }}>
            <div style={{
              display: 'flex',
              gap: 16,
              background: 'var(--bg-tertiary)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              padding: '18px 20px'
            }}>
              <div style={{ color: 'var(--accent)', fontSize: 24 }}><FiPhone /></div>
              <div>
                <strong style={{ fontSize: 15, display: 'block' }}>24/7 Roadside Concierge</strong>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Toll Free: 1800-DRIVE-EASE (1800-37483-3273)</span>
              </div>
            </div>

            <div style={{
              display: 'flex',
              gap: 16,
              background: 'var(--bg-tertiary)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              padding: '18px 20px'
            }}>
              <div style={{ color: '#00f0ff', fontSize: 24 }}><FiMail /></div>
              <div>
                <strong style={{ fontSize: 15, display: 'block' }}>Email Support</strong>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>support@driveease.com • corporate@driveease.com</span>
              </div>
            </div>

            <div style={{
              display: 'flex',
              gap: 16,
              background: 'var(--bg-tertiary)',
              border: '1px solid var(--border-color)',
              borderRadius: 'var(--radius-md)',
              padding: '18px 20px'
            }}>
              <div style={{ color: 'var(--warning)', fontSize: 24 }}><FiClock /></div>
              <div>
                <strong style={{ fontSize: 15, display: 'block' }}>Operations Hours</strong>
                <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>Fleet Dispatch & Returns: 24 Hours, 365 Days</span>
              </div>
            </div>
          </div>

          <h3 style={{ fontSize: 18, marginBottom: 14 }}>Flagship City Lounges</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: 13, color: 'var(--text-secondary)' }}>
            <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: 8 }}>
              <strong>Mumbai HQ:</strong><br />BKC Express Hub, Bandra East
            </div>
            <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: 8 }}>
              <strong>Delhi NCR:</strong><br />Connaught Place, Central Plaza
            </div>
            <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: 8 }}>
              <strong>Bangalore:</strong><br />100ft Road, Indiranagar
            </div>
            <div style={{ padding: '12px 14px', background: 'rgba(255,255,255,0.03)', borderRadius: 8 }}>
              <strong>Hyderabad:</strong><br />Cyber Towers, HITEC City
            </div>
          </div>
        </div>

        {/* Right: Message Form */}
        <div style={{
          background: 'var(--bg-tertiary)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-xl)',
          padding: '36px 30px'
        }}>
          <h2 style={{ fontSize: 22, marginBottom: 6 }}>Send Us a Message</h2>
          <p style={{ fontSize: 13, color: 'var(--text-secondary)', marginBottom: 24 }}>
            We typically respond to web inquiries within 15 minutes.
          </p>

          <form onSubmit={handleSubmit} className="auth-form">
            <div className="form-group">
              <label>Your Full Name</label>
              <input
                type="text"
                placeholder="Ankul Sharma"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                placeholder="ankul@example.com"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                required
              />
            </div>

            <div className="form-group">
              <label>Inquiry Type</label>
              <select
                value={form.subject}
                onChange={(e) => setForm({ ...form, subject: e.target.value })}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-sm)',
                  color: '#fff'
                }}
              >
                <option value="booking">Booking / Reservation Inquiry</option>
                <option value="extension">Trip Extension / Change</option>
                <option value="corporate">Corporate Fleet Leasing</option>
                <option value="roadside">Roadside Assistance Feedback</option>
              </select>
            </div>

            <div className="form-group">
              <label>Message</label>
              <textarea
                rows={4}
                placeholder="How can we assist you with your trip?"
                value={form.message}
                onChange={(e) => setForm({ ...form, message: e.target.value })}
                style={{
                  width: '100%',
                  padding: '12px 16px',
                  background: 'var(--bg-secondary)',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-sm)',
                  color: '#fff',
                  fontFamily: 'inherit',
                  fontSize: 14,
                  resize: 'vertical'
                }}
                required
              />
            </div>

            <button type="submit" className="btn btn-primary btn-block">
              <FiSend size={16} /> Send Message
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

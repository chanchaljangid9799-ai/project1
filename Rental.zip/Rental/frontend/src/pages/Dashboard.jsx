import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { bookingsAPI, authAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { FiCalendar, FiCheck, FiClock, FiX, FiCreditCard, FiMail, FiPrinter, FiUser, FiShield, FiMapPin } from 'react-icons/fi';
import { BsCarFront, BsKey } from 'react-icons/bs';
import EmailModal from '../components/EmailModal';
import DigitalKeyModal from '../components/DigitalKeyModal';
import InvoiceModal from '../components/InvoiceModal';

export default function Dashboard() {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFilter, setActiveFilter] = useState('all');
  const [stats, setStats] = useState({ total: 0, confirmed: 0, active: 0, completed: 0 });

  // Modal active states
  const [selectedBookingForKey, setSelectedBookingForKey] = useState(null);
  const [selectedBookingForEmail, setSelectedBookingForEmail] = useState(null);
  const [selectedBookingForInvoice, setSelectedBookingForInvoice] = useState(null);

  useEffect(() => {
    if (!user) { navigate('/login'); return; }
    loadBookings();
  }, [user, activeFilter]);

  const loadBookings = async () => {
    setLoading(true);
    try {
      const params = {};
      if (activeFilter !== 'all') params.status = activeFilter;

      const res = await bookingsAPI.getMyBookings(params);
      setBookings(res.data.bookings || []);

      if (activeFilter === 'all') {
        const all = res.data.bookings || [];
        setStats({
          total: all.length,
          confirmed: all.filter(b => b.status === 'confirmed').length,
          active: all.filter(b => b.status === 'active').length,
          completed: all.filter(b => b.status === 'completed').length,
        });
      }
    } catch (err) {
      console.error(err);
      toast.error('Failed to load trips');
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = async (bookingId) => {
    if (!window.confirm('Are you sure you want to cancel this booking? Refund will be processed immediately.')) return;
    try {
      await bookingsAPI.cancel(bookingId, { reason: 'Cancelled by user via dashboard' });
      toast.success('Booking cancelled and refund initiated.');
      loadBookings();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to cancel');
    }
  };

  const formatDate = (dateStr) => {
    return new Date(dateStr).toLocaleDateString('en-IN', {
      day: 'numeric', month: 'short', year: 'numeric'
    });
  };

  return (
    <div className="dashboard">
      {/* Modals */}
      {selectedBookingForKey && (
        <DigitalKeyModal
          booking={selectedBookingForKey}
          onClose={() => setSelectedBookingForKey(null)}
        />
      )}

      {selectedBookingForEmail && (
        <EmailModal
          bookingId={selectedBookingForEmail._id}
          previewUrl={selectedBookingForEmail.emailPreviewUrl}
          onClose={() => setSelectedBookingForEmail(null)}
        />
      )}

      {selectedBookingForInvoice && (
        <InvoiceModal
          booking={selectedBookingForInvoice}
          onClose={() => setSelectedBookingForInvoice(null)}
        />
      )}

      {/* Header */}
      <div className="dashboard-header">
        <div className="dashboard-greeting">
          <h2>Hey, {user?.firstName} 👋</h2>
          <p>Verified Driver • {user?.email} • License: {user?.drivingLicense || 'DL-MH-04-2024-9981'}</p>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          <Link to="/cars" className="btn btn-primary">Book Another Car</Link>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="dashboard-stats">
        <div className="dashboard-stat-card">
          <div className="dashboard-stat-icon blue"><BsCarFront /></div>
          <div className="dashboard-stat-value">{stats.total}</div>
          <div className="dashboard-stat-label">Total Bookings</div>
        </div>
        <div className="dashboard-stat-card">
          <div className="dashboard-stat-icon green"><FiCheck /></div>
          <div className="dashboard-stat-value">{stats.confirmed}</div>
          <div className="dashboard-stat-label">Confirmed & Ready</div>
        </div>
        <div className="dashboard-stat-card">
          <div className="dashboard-stat-icon yellow"><FiClock /></div>
          <div className="dashboard-stat-value">{stats.active}</div>
          <div className="dashboard-stat-label">Active On-Road</div>
        </div>
        <div className="dashboard-stat-card">
          <div className="dashboard-stat-icon red"><FiCalendar /></div>
          <div className="dashboard-stat-value">{stats.completed}</div>
          <div className="dashboard-stat-label">Completed Trips</div>
        </div>
      </div>

      {/* Bookings Container */}
      <div className="bookings-table-container">
        <div className="bookings-table-header">
          <h3>Your Trips & Reservations</h3>
          <div className="bookings-table-filters">
            {['all', 'pending', 'confirmed', 'completed', 'cancelled'].map(f => (
              <button
                key={f}
                className={`filter-btn ${activeFilter === f ? 'active' : ''}`}
                onClick={() => setActiveFilter(f)}
              >
                {f.charAt(0).toUpperCase() + f.slice(1)}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="loading-container" style={{ padding: 50 }}>
            <div className="spinner"></div>
            <p className="loading-text">Loading your trips...</p>
          </div>
        ) : bookings.length === 0 ? (
          <div className="empty-state" style={{ padding: '60px 20px' }}>
            <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', color: 'var(--accent)' }}>
              <BsCarFront size={32} />
            </div>
            <h3>No trips found</h3>
            <p>Ready to hit the road? Explore our handpicked fleet of premium self-drive cars.</p>
            <Link to="/cars" className="btn btn-primary" style={{ marginTop: 14 }}>Browse All Cars</Link>
          </div>
        ) : (
          <div className="bookings-list">
            {bookings.map(booking => {
              const isPaid = booking.payment?.status === 'completed';
              return (
                <div key={booking._id} className="booking-item">
                  <img
                    src={booking.car?.images?.[0] || 'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/dzire-2024-exterior-right-front-three-quarter-2.jpeg'}
                    alt={booking.car?.name}
                    className="booking-item-image"
                  />

                  <div className="booking-item-info">
                    <h4>{booking.car?.name || 'Selected Vehicle'}</h4>
                    <p>{booking.car?.brand} • {booking.car?.category} • {booking.car?.registrationNumber || 'Assigned'}</p>
                    <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 4 }}>
                      Ref: #{(booking._id || '').slice(-6).toUpperCase()}
                    </div>
                  </div>

                  <div className="booking-item-dates">
                    <div>
                      <strong>{formatDate(booking.pickupDate)}</strong>
                      <span style={{ fontSize: 12, color: 'var(--text-muted)' }}> to {formatDate(booking.dropoffDate)}</span>
                    </div>
                    <div style={{ fontSize: 12, color: 'var(--text-secondary)', marginTop: 2, display: 'flex', alignItems: 'center', gap: 4 }}>
                      <FiMapPin size={13} style={{ color: 'var(--accent)' }} />
                      <span>{booking.pickupLocation?.address || booking.car?.location?.area || 'Hub'}, {booking.pickupLocation?.city || booking.car?.location?.city || 'City'}</span>
                    </div>
                  </div>

                  <div className="booking-item-amount">
                    <div style={{ fontWeight: 700, fontSize: 16 }}>₹{booking.pricing?.totalAmount?.toLocaleString('en-IN')}</div>
                    <span className={`booking-status ${booking.status}`}>{booking.status}</span>
                  </div>

                  {/* Actions Column */}
                  <div className="booking-item-actions">
                    {/* If unpaid, show Pay button */}
                    {!isPaid && booking.status !== 'cancelled' && (
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={() => navigate(`/payment/${booking._id}`)}
                      >
                        <FiCreditCard size={13} /> Pay Now
                      </button>
                    )}

                    {/* If paid, show Digital Key, Email, Invoice */}
                    {isPaid && (
                      <div className="booking-action-chips">
                        <button
                          className="chip-btn key"
                          onClick={() => setSelectedBookingForKey(booking)}
                          title="Open Digital Smart Car Key"
                        >
                          <BsKey size={13} /> Key
                        </button>

                        <button
                          className="chip-btn email"
                          onClick={() => setSelectedBookingForEmail(booking)}
                          title="View Confirmation Email"
                        >
                          <FiMail size={13} /> Email
                        </button>

                        <button
                          className="chip-btn invoice"
                          onClick={() => setSelectedBookingForInvoice(booking)}
                          title="Print / Save Tax Invoice"
                        >
                          <FiPrinter size={13} /> Invoice
                        </button>
                      </div>
                    )}

                    {/* Cancel button */}
                    {['pending', 'confirmed'].includes(booking.status) && (
                      <button
                        className="btn-cancel-link"
                        onClick={() => handleCancel(booking._id)}
                      >
                        <FiX size={12} /> Cancel
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

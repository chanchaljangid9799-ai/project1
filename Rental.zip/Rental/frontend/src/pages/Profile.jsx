import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';
import toast from 'react-hot-toast';
import { FiUser, FiPhone, FiMail, FiFileText, FiShield, FiSave, FiMapPin } from 'react-icons/fi';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [form, setForm] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    phone: user?.phone || '',
    drivingLicense: user?.drivingLicense || 'DL-MH-04-2024-9981'
  });
  const [saving, setSaving] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await authAPI.updateProfile(form);
      updateUser(res.data.user);
      toast.success('Driver profile updated successfully!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="auth-page" style={{ paddingTop: 100, minHeight: '90vh' }}>
      <div className="auth-container" style={{ maxWidth: 640 }}>
        <div className="auth-card" style={{ padding: 36 }}>
          <div className="auth-header" style={{ marginBottom: 28 }}>
            <div className="nav-user-avatar" style={{ width: 64, height: 64, fontSize: 22, margin: '0 auto 16px' }}>
              {user?.firstName?.charAt(0)}{user?.lastName?.charAt(0)}
            </div>
            <h2>Driver Profile & Credentials</h2>
            <p>Manage your verified driver license and contact details</p>
          </div>

          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            background: 'rgba(200,255,0,0.06)',
            border: '1px solid rgba(200,255,0,0.2)',
            borderRadius: 'var(--radius-md)',
            padding: '12px 18px',
            marginBottom: 24
          }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <FiShield size={20} style={{ color: 'var(--accent)' }} />
              <div>
                <strong style={{ fontSize: 13, color: '#fff' }}>Verification Status</strong>
                <div style={{ fontSize: 12, color: 'var(--accent)' }}>✓ Government ID & License Verified</div>
              </div>
            </div>
            <span style={{
              fontSize: 11,
              fontWeight: 700,
              textTransform: 'uppercase',
              background: 'var(--accent)',
              color: '#000',
              padding: '4px 10px',
              borderRadius: 20
            }}>
              Tier 1 Driver
            </span>
          </div>

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="form-row">
              <div className="form-group">
                <label>First Name</label>
                <input
                  type="text"
                  value={form.firstName}
                  onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                  required
                />
              </div>
              <div className="form-group">
                <label>Last Name</label>
                <input
                  type="text"
                  value={form.lastName}
                  onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="form-group">
              <label>Email Address</label>
              <input
                type="email"
                value={user?.email || ''}
                disabled
                style={{ opacity: 0.6, cursor: 'not-allowed' }}
              />
            </div>

            <div className="form-group">
              <label>Phone Number (10 digits)</label>
              <input
                type="tel"
                value={form.phone}
                maxLength={10}
                onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, '') })}
                required
              />
            </div>

            <div className="form-group">
              <label>Driving License Number</label>
              <input
                type="text"
                placeholder="DL-04-2024-XXXXXX"
                value={form.drivingLicense}
                onChange={(e) => setForm({ ...form, drivingLicense: e.target.value.toUpperCase() })}
                style={{ textTransform: 'uppercase', letterSpacing: 1 }}
                required
              />
            </div>

            <button type="submit" className="btn btn-primary btn-block" disabled={saving}>
              <FiSave size={16} />
              {saving ? 'Updating...' : 'Save Profile Changes'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

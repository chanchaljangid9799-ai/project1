import { Link } from 'react-router-dom';
import { FiShield, FiAward, FiUsers, FiMapPin, FiCheckCircle, FiArrowRight } from 'react-icons/fi';
import { BsLightningChargeFill, BsCarFront, BsBuildingCheck } from 'react-icons/bs';

export default function About() {
  return (
    <div className="about-page" style={{ paddingTop: 90, paddingBottom: 80 }}>
      {/* Hero */}
      <section className="about-hero" style={{ textAlign: 'center', padding: '60px 20px 40px', maxWidth: 900, margin: '0 auto' }}>
        <div className="section-tag" style={{ margin: '0 auto 12px' }}>OUR STORY & MISSION</div>
        <h1 style={{ fontSize: 44, letterSpacing: '-1.5px', marginBottom: 16 }}>
          Redefining Mobility Across <span style={{ color: 'var(--accent)' }}>India</span>
        </h1>
        <p style={{ fontSize: 17, color: 'var(--text-secondary)', lineHeight: 1.7 }}>
          DriveEase was founded with a singular conviction: self-driving should be effortless, transparent, and keyless. Today, we empower over 50,000+ drivers across 25+ Indian metropolitan hubs with on-demand luxury, electric, SUV, and commuter vehicles.
        </p>
      </section>

      {/* Stats Banner */}
      <div style={{
        maxWidth: 1100,
        margin: '20px auto 60px',
        padding: '0 20px'
      }}>
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: 16,
          background: 'var(--bg-tertiary)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-xl)',
          padding: '36px 28px',
          textAlign: 'center'
        }}>
          <div>
            <div style={{ fontSize: 36, fontWeight: 800, color: 'var(--accent)', fontFamily: 'Space Grotesk' }}>500+</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>Fleet Size</div>
          </div>
          <div>
            <div style={{ fontSize: 36, fontWeight: 800, color: '#fff', fontFamily: 'Space Grotesk' }}>25+</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>Cities Live</div>
          </div>
          <div>
            <div style={{ fontSize: 36, fontWeight: 800, color: '#00f0ff', fontFamily: 'Space Grotesk' }}>99.8%</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>On-Time Dispatch</div>
          </div>
          <div>
            <div style={{ fontSize: 36, fontWeight: 800, color: 'var(--accent)', fontFamily: 'Space Grotesk' }}>4.8 / 5</div>
            <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>Verified Driver Rating</div>
          </div>
        </div>
      </div>

      {/* Core Pillars */}
      <section style={{ maxWidth: 1100, margin: '0 auto 80px', padding: '0 20px' }}>
        <div className="section-header" style={{ textAlign: 'center', marginBottom: 40 }}>
          <div style={{ margin: '0 auto' }}>
            <div className="section-tag">WHY DRIVEEASE</div>
            <h2>Built on Standards You Can Trust</h2>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 24 }}>
          <div className="category-card" style={{ textAlign: 'left', padding: 32 }}>
            <div style={{ fontSize: 30, color: 'var(--accent)', marginBottom: 16 }}><BsLightningChargeFill /></div>
            <h3 style={{ fontSize: 20, marginBottom: 10 }}>Smart Digital Key Technology</h3>
            <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              No paperwork counters or key handoff queues. Unlock your reserved vehicle seamlessly via our encrypted BLE 5.3 telematics mobile fob.
            </p>
          </div>

          <div className="category-card" style={{ textAlign: 'left', padding: 32 }}>
            <div style={{ fontSize: 30, color: '#00f0ff', marginBottom: 16 }}><FiShield /></div>
            <h3 style={{ fontSize: 20, marginBottom: 10 }}>Zero-Depreciation Insurance</h3>
            <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              Every rental is insured from bumper-to-bumper with 24/7 nationwide roadside assistance and emergency dispatch coverage.
            </p>
          </div>

          <div className="category-card" style={{ textAlign: 'left', padding: 32 }}>
            <div style={{ fontSize: 30, color: 'var(--warning)', marginBottom: 16 }}><BsBuildingCheck /></div>
            <h3 style={{ fontSize: 20, marginBottom: 10 }}>Triple-Check Sanitization</h3>
            <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6 }}>
              Before every trip handover, vehicles undergo our rigorous 42-point safety and cleanliness audit with high-grade disinfectant ozone cleaning.
            </p>
          </div>
        </div>
      </section>

      {/* Hubs Presence */}
      <section style={{ maxWidth: 1100, margin: '0 auto 60px', padding: '0 20px' }}>
        <div style={{
          background: 'linear-gradient(135deg, #181928 0%, #0d0e15 100%)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-xl)',
          padding: '44px 36px',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
          gap: 30,
          alignItems: 'center'
        }}>
          <div>
            <div className="section-tag">NATIONWIDE NETWORK</div>
            <h2 style={{ fontSize: 28, marginBottom: 14 }}>Pick up from Airport or City Center</h2>
            <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: 20 }}>
              Operating flagship lounges and contactless drop zones at major airports including Mumbai CSIA (T1/T2), Delhi IGI (T3), Bangalore KIA, Hyderabad RGIA, Pune, Chennai, and Goa MOPA.
            </p>
            <Link to="/cars" className="btn btn-primary">
              Explore Available Fleet <FiArrowRight />
            </Link>
          </div>
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: 12,
            fontSize: 13,
            color: 'var(--text-secondary)'
          }}>
            <div style={{ padding: '12px 16px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 8 }}><FiMapPin style={{ color: 'var(--accent)' }} /> Mumbai (14 Hubs)</div>
            <div style={{ padding: '12px 16px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 8 }}><FiMapPin style={{ color: 'var(--accent)' }} /> Delhi NCR (18 Hubs)</div>
            <div style={{ padding: '12px 16px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 8 }}><FiMapPin style={{ color: 'var(--accent)' }} /> Bangalore (12 Hubs)</div>
            <div style={{ padding: '12px 16px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 8 }}><FiMapPin style={{ color: 'var(--accent)' }} /> Hyderabad (9 Hubs)</div>
            <div style={{ padding: '12px 16px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 8 }}><FiMapPin style={{ color: 'var(--accent)' }} /> Pune (7 Hubs)</div>
            <div style={{ padding: '12px 16px', background: 'rgba(255,255,255,0.03)', borderRadius: 10, display: 'flex', alignItems: 'center', gap: 8 }}><FiMapPin style={{ color: 'var(--accent)' }} /> Goa (8 Hubs)</div>
          </div>
        </div>
      </section>
    </div>
  );
}

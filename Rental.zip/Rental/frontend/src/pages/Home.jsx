import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { carsAPI } from '../services/api';
import CarCard from '../components/CarCard';
import AiRoutePlanner from '../components/AiRoutePlanner';
import { FiSearch, FiArrowRight, FiMapPin, FiCalendar, FiShield, FiCheckCircle, FiClock, FiStar, FiZap, FiUsers } from 'react-icons/fi';
import { BsLightningChargeFill, BsShieldCheck, BsStarFill, BsCarFront, BsKey, BsSpeedometer2, BsStars } from 'react-icons/bs';
import { RiCarLine, RiRoadsterLine } from 'react-icons/ri';

const getCategoryVectorIcon = (category) => {
  switch ((category || '').toLowerCase()) {
    case 'suv': return <BsShieldCheck size={22} />;
    case 'sedan': return <BsCarFront size={22} />;
    case 'luxury': return <BsStars size={22} />;
    case 'electric': return <BsLightningChargeFill size={22} />;
    case 'hatchback': return <RiCarLine size={22} />;
    case 'sports':
    case 'convertible': return <RiRoadsterLine size={22} />;
    case 'minivan': return <FiUsers size={22} />;
    default: return <BsCarFront size={22} />;
  }
};

const brands = [
  'Mercedes-Benz', 'BMW', 'Hyundai', 'Tata Motors', 'Toyota', 'Mahindra', 'Kia', 'Maruti Suzuki', 'Volkswagen', 'Honda'
];

const testimonials = [
  {
    name: 'Vikram Mehta',
    city: 'Mumbai',
    car: 'Hyundai Creta SX(O)',
    rating: 5,
    comment: 'The digital key fob feature is exceptional. Landed at Mumbai Airport Terminal 2, unlocked the Creta directly from the mobile app, and drove off without standing in a single counter queue.',
    date: 'Verified Trip'
  },
  {
    name: 'Pooja Iyer',
    city: 'Bangalore',
    car: 'Tata Nexon EV Max',
    rating: 5,
    comment: 'Super clean, sanitized car delivered on time. The AI fuel and route estimator was accurate to within ₹50 for my Bangalore to Coorg weekend getaway.',
    date: 'Verified Trip'
  },
  {
    name: 'Rohan Deshmukh',
    city: 'Delhi NCR',
    car: 'Toyota Fortuner Legender',
    rating: 5,
    comment: 'Best self-drive service in India hands down. Immediate invoice download, 100% transparent pricing, zero hidden charges. Highly recommended for long family trips.',
    date: 'Verified Trip'
  }
];

export default function Home() {
  const navigate = useNavigate();
  const [cars, setCars] = useState([]);
  const [categories, setCategories] = useState([]);
  const [searchCity, setSearchCity] = useState('');
  const [searchCategory, setSearchCategory] = useState('');
  const [loading, setLoading] = useState(true);
  const heroVisualRef = useRef(null);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    const el = heroVisualRef.current;
    if (!el || !window.matchMedia('(pointer: fine)').matches) return;
    const onMove = (e) => {
      const box = el.getBoundingClientRect();
      const x = (e.clientX - box.left) / box.width - 0.5;
      const y = (e.clientY - box.top) / box.height - 0.5;
      el.style.setProperty('--tilt-x', `${(-y * 10).toFixed(2)}deg`);
      el.style.setProperty('--tilt-y', `${(x * 14).toFixed(2)}deg`);
      el.style.setProperty('--shift-x', `${(x * 18).toFixed(1)}px`);
      el.style.setProperty('--shift-y', `${(y * 12).toFixed(1)}px`);
    };
    const onLeave = () => {
      el.style.setProperty('--tilt-x', '0deg');
      el.style.setProperty('--tilt-y', '0deg');
      el.style.setProperty('--shift-x', '0px');
      el.style.setProperty('--shift-y', '0px');
    };
    window.addEventListener('mousemove', onMove);
    el.addEventListener('mouseleave', onLeave);
    return () => {
      window.removeEventListener('mousemove', onMove);
      el.removeEventListener('mouseleave', onLeave);
    };
  }, []);

  const loadData = async () => {
    try {
      const [carsRes, catRes] = await Promise.all([
        carsAPI.getAll({ limit: 6, sort: 'popular' }),
        carsAPI.getCategories()
      ]);
      setCars(carsRes.data.cars || []);
      setCategories(catRes.data.categories || []);
    } catch (err) {
      console.error('Failed to load data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    const params = new URLSearchParams();
    if (searchCity) params.set('city', searchCity);
    if (searchCategory) params.set('category', searchCategory);
    navigate(`/cars?${params.toString()}`);
  };

  const sampleCarForPlanner = cars[1] || cars[0] || {
    name: 'Hyundai Creta SX(O)',
    fuelType: 'petrol',
    specifications: { mileage: '17.4 kmpl' }
  };

  return (
    <div className="home-wrapper">
      {/* Hero */}
      <section className="hero">
        <div className="hero-bg">
          <div className="hero-grid"></div>
        </div>
        <div className="hero-content">
          <div className="hero-text">
            <div className="hero-kicker">
              <span>Hackathon 2026</span>
              Built to win the demo
            </div>
            <div className="hero-badge">
              <span className="pulse-dot"></span>
              Live in 25+ Cities Across India • Keyless Smart Telematics
            </div>
            <h1 className="hero-title">
              Drive Your Way.<br />
              <span className="highlight">Keyless. Insured. Instant.</span>
            </h1>
            <p className="hero-subtitle">
              Skip the rental counters and taxi hassles. Experience 500+ premium sanitized self-drive vehicles with encrypted smartphone key unlock starting at ₹69/hr. EaseBot in the corner walks judges through booking, digital keys, and demo login.
            </p>
            <div className="hero-trust">
              <span>BLE digital key</span>
              <span>GST tax invoice</span>
              <span>UPI + card checkout</span>
              <span>AI fuel planner</span>
            </div>
            <div className="hero-actions">
              <Link to="/cars" className="btn btn-primary btn-lg">
                Explore Fleet <FiArrowRight />
              </Link>
              <Link to="/how-it-works" className="btn btn-secondary btn-lg">
                How It Works
              </Link>
            </div>
            <div className="hero-stats">
              <div className="hero-stat">
                <div className="number">500+</div>
                <div className="label">Fleet Size</div>
              </div>
              <div className="hero-stat">
                <div className="number">25+</div>
                <div className="label">Airports & Hubs</div>
              </div>
              <div className="hero-stat">
                <div className="number">50K+</div>
                <div className="label">Trips Completed</div>
              </div>
              <div className="hero-stat">
                <div className="number">4.8 / 5</div>
                <div className="label">Driver Rating</div>
              </div>
            </div>
          </div>

          <div className="hero-visual" ref={heroVisualRef}>
            <div className="hero-car-container">
              <div className="hero-car-image">
                <img
                  src="https://imgd.aeplcdn.com/664x374/n/cw/ec/106815/creta-exterior-right-front-three-quarter-5.jpeg"
                  alt="Premium SUV"
                  onError={(e) => { e.target.src = 'https://placehold.co/560x380/1a1a28/c8ff00?text=DriveEase'; }}
                />
              </div>
              <div className="hero-car-glow"></div>
              <div className="hero-floating-card top-right">
                <div className="floating-card-label">Tariffs Starting At</div>
                <div className="floating-card-value" style={{ color: 'var(--accent)' }}>₹69/hr</div>
              </div>
              <div className="hero-floating-card bottom-left">
                <div className="floating-card-label">Smart Telematics</div>
                <div className="floating-card-value" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <BsKey style={{ color: 'var(--accent)' }} /> Keyless BLE 5.3
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Brand Partners Marquee */}
      <section style={{
        background: 'var(--bg-secondary)',
        borderTop: '1px solid var(--border-color)',
        borderBottom: '1px solid var(--border-color)',
        padding: '24px 20px',
        overflow: 'hidden'
      }}>
        <div style={{ maxWidth: 1280, margin: '0 auto', textAlign: 'center' }}>
          <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 14 }}>
            TRUSTED FLEET FROM LEADING AUTOMAKERS
          </p>
          <div style={{
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            gap: 32,
            flexWrap: 'wrap'
          }}>
            {brands.map((b, i) => (
              <span key={i} style={{
                fontFamily: 'Space Grotesk',
                fontWeight: 700,
                fontSize: 16,
                color: 'rgba(255,255,255,0.4)',
                letterSpacing: 1
              }}>
                {b}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Search Box */}
      <section className="search-section">
        <form className="search-box" onSubmit={handleSearch}>
          <div className="search-field">
            <label><FiMapPin style={{ marginRight: 4 }} /> Pickup City / Airport Hub</label>
            <input
              type="text"
              placeholder="Mumbai, Delhi, Bangalore, Goa, Pune..."
              value={searchCity}
              onChange={(e) => setSearchCity(e.target.value)}
            />
          </div>
          <div className="search-field">
            <label><FiCalendar style={{ marginRight: 4 }} /> Vehicle Category</label>
            <select value={searchCategory} onChange={(e) => setSearchCategory(e.target.value)}>
              <option value="">All Categories (Sedan, SUV, Luxury, EV)</option>
              <option value="sedan">Sedan (Dzire, Virtus, City)</option>
              <option value="suv">SUV (Creta, Fortuner, Thar, Harrier)</option>
              <option value="luxury">Luxury (BMW 3 Series, Mercedes GLC)</option>
              <option value="electric">Electric (Nexon EV Max)</option>
              <option value="hatchback">Hatchback (Baleno)</option>
            </select>
          </div>
          <button type="submit" className="btn btn-primary" style={{ padding: '14px 32px', marginBottom: 0 }}>
            <FiSearch size={18} />
            Search Fleet
          </button>
        </form>
      </section>

      {/* Categories */}
      <section className="categories-section">
        <div className="section-header">
          <div>
            <div className="section-tag">FLEET CATEGORIES</div>
            <h2>Find Your Perfect Match</h2>
            <p>From fuel-efficient city commuters to high-altitude 4x4 SUVs and luxury sedans</p>
          </div>
          <Link to="/cars" className="btn btn-secondary btn-sm">
            View All Fleet <FiArrowRight />
          </Link>
        </div>
        <div className="categories-grid">
          {categories.map((cat) => (
            <Link
              key={cat._id}
              to={`/cars?category=${cat._id}`}
              className="category-card"
            >
              <div className="category-icon" style={{ color: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                {getCategoryVectorIcon(cat._id)}
              </div>
              <div className="category-name" style={{ textTransform: 'capitalize', marginTop: 8 }}>{cat._id}</div>
              <div className="category-count">{cat.count} verified cars</div>
            </Link>
          ))}
        </div>
      </section>

      {/* Popular Cars */}
      <section className="cars-section">
        <div className="section-header">
          <div>
            <div className="section-tag">POPULAR CHOICES</div>
            <h2>Most Booked Cars This Week</h2>
            <p>Sanitized, GPS-enabled, and ready for immediate keyless departure</p>
          </div>
          <Link to="/cars" className="btn btn-secondary btn-sm">
            Browse All Cars <FiArrowRight />
          </Link>
        </div>
        {loading ? (
          <div className="cars-grid">
            {[1, 2, 3].map(i => <div key={i} className="skeleton skeleton-card"></div>)}
          </div>
        ) : (
          <div className="cars-grid">
            {cars.map(car => <CarCard key={car._id} car={car} />)}
          </div>
        )}
      </section>

      {/* Embedded Smart AI Route Planner Demo */}
      <section style={{ maxWidth: 1280, margin: '0 auto 80px', padding: '0 20px' }}>
        <div style={{
          background: 'linear-gradient(135deg, #181928 0%, #0d0e15 100%)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-xl)',
          padding: '40px 32px'
        }}>
          <div style={{ textAlign: 'center', maxWidth: 700, margin: '0 auto 28px' }}>
            <div className="section-tag" style={{ margin: '0 auto 8px' }}>SMART ROUTE & FUEL PLANNER</div>
            <h2 style={{ fontSize: 28 }}>Plan Your Trip Costs in Real-Time</h2>
            <p style={{ fontSize: 14, color: 'var(--text-secondary)' }}>
              Test our AI Fuel Engine with authentic consumption rates across top national highway corridors
            </p>
          </div>
          <AiRoutePlanner car={sampleCarForPlanner} />
        </div>
      </section>

      {/* Comparison: Why DriveEase */}
      <section style={{ maxWidth: 1280, margin: '0 auto 80px', padding: '0 20px' }}>
        <div className="section-header" style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{ margin: '0 auto' }}>
            <div className="section-tag">VALUE COMPARISON</div>
            <h2>Why DriveEase Beats Cabs & Traditional Rentals</h2>
          </div>
        </div>

        <div style={{
          background: 'var(--bg-tertiary)',
          border: '1px solid var(--border-color)',
          borderRadius: 'var(--radius-xl)',
          overflow: 'hidden'
        }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left', fontSize: 14 }}>
            <thead>
              <tr style={{ background: 'rgba(255,255,255,0.02)', borderBottom: '1px solid var(--border-color)' }}>
                <th style={{ padding: '18px 24px', color: 'var(--text-muted)', fontWeight: 600 }}>Feature</th>
                <th style={{ padding: '18px 24px', color: 'var(--accent)', fontWeight: 700 }}>DriveEase</th>
                <th style={{ padding: '18px 24px', color: 'var(--text-secondary)' }}>Traditional Rentals</th>
                <th style={{ padding: '18px 24px', color: 'var(--text-secondary)' }}>Outstation Cabs</th>
              </tr>
            </thead>
            <tbody>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                <td style={{ padding: '16px 24px', fontWeight: 600 }}>Key Handover & Pickup</td>
                <td style={{ padding: '16px 24px', color: 'var(--accent)', fontWeight: 600 }}>✓ Instant BLE Digital Key</td>
                <td style={{ padding: '16px 24px', color: 'var(--text-muted)' }}>45 min counter queue</td>
                <td style={{ padding: '16px 24px', color: 'var(--text-muted)' }}>Dependent on driver</td>
              </tr>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                <td style={{ padding: '16px 24px', fontWeight: 600 }}>Privacy & Independence</td>
                <td style={{ padding: '16px 24px', color: 'var(--accent)', fontWeight: 600 }}>✓ 100% Private Self-Drive</td>
                <td style={{ padding: '16px 24px', color: 'var(--text-muted)' }}>Private Self-Drive</td>
                <td style={{ padding: '16px 24px', color: 'var(--text-muted)' }}>No privacy (chauffeur)</td>
              </tr>
              <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                <td style={{ padding: '16px 24px', fontWeight: 600 }}>Transparent Pricing & GST</td>
                <td style={{ padding: '16px 24px', color: 'var(--accent)', fontWeight: 600 }}>✓ Exact breakdown + PDF invoice</td>
                <td style={{ padding: '16px 24px', color: 'var(--text-muted)' }}>Hidden deposit deductions</td>
                <td style={{ padding: '16px 24px', color: 'var(--text-muted)' }}>Surge tariffs & driver DA</td>
              </tr>
              <tr>
                <td style={{ padding: '16px 24px', fontWeight: 600 }}>24/7 Roadside Assistance</td>
                <td style={{ padding: '16px 24px', color: 'var(--accent)', fontWeight: 600 }}>✓ Nationwide Toll-Free Cover</td>
                <td style={{ padding: '16px 24px', color: 'var(--text-muted)' }}>Paid add-on extra</td>
                <td style={{ padding: '16px 24px', color: 'var(--text-muted)' }}>Unpredictable</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      {/* Testimonials */}
      <section style={{ maxWidth: 1280, margin: '0 auto 80px', padding: '0 20px' }}>
        <div className="section-header" style={{ textAlign: 'center', marginBottom: 36 }}>
          <div style={{ margin: '0 auto' }}>
            <div className="section-tag">COMMUNITY REVIEWS</div>
            <h2>What Verified Drivers Say</h2>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20 }}>
          {testimonials.map((t, idx) => (
            <div key={idx} className="category-card" style={{ textAlign: 'left', padding: '28px 24px' }}>
              <div style={{ display: 'flex', gap: 4, color: 'var(--warning)', marginBottom: 14 }}>
                {[...Array(t.rating)].map((_, i) => <FiStar key={i} fill="currentColor" size={16} />)}
              </div>
              <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6, marginBottom: 18 }}>
                "{t.comment}"
              </p>
              <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: 14 }}>
                <strong style={{ fontSize: 14, color: '#fff', display: 'block' }}>{t.name}</strong>
                <span style={{ fontSize: 12, color: 'var(--accent)' }}>{t.car} • {t.city}</span>
              </div>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

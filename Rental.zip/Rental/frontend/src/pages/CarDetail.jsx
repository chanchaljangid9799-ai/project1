import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { carsAPI, bookingsAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { BsStarFill, BsFuelPump, BsSpeedometer } from 'react-icons/bs';
import { FiUsers, FiMapPin, FiCalendar, FiCheck, FiChevronRight } from 'react-icons/fi';
import { TbEngine, TbGasStation } from 'react-icons/tb';
import AiRoutePlanner from '../components/AiRoutePlanner';

export default function CarDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [car, setCar] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState(0);

  const [bookingData, setBookingData] = useState({
    pickupDate: '',
    dropoffDate: '',
    pickupTime: '10:00',
    dropoffTime: '10:00',
    extras: { insurance: false, gps: false, childSeat: false, additionalDriver: false },
  });
  const [pricing, setPricing] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    loadCar();
  }, [id]);

  useEffect(() => {
    if (car && bookingData.pickupDate && bookingData.dropoffDate) {
      calculatePricing();
    }
  }, [bookingData, car]);

  const loadCar = async () => {
    try {
      const res = await carsAPI.getById(id);
      setCar(res.data.car);
    } catch (err) {
      toast.error('Failed to load car details');
      navigate('/cars');
    } finally {
      setLoading(false);
    }
  };

  const calculatePricing = () => {
    const pickup = new Date(`${bookingData.pickupDate}T${bookingData.pickupTime}`);
    const dropoff = new Date(`${bookingData.dropoffDate}T${bookingData.dropoffTime}`);
    if (dropoff <= pickup) { setPricing(null); return; }

    const totalHours = Math.ceil((dropoff - pickup) / (1000 * 60 * 60));
    const totalDays = Math.ceil(totalHours / 24);
    let basePrice = totalHours <= 12 ? car.pricePerHour * totalHours : car.pricePerDay * totalDays;
    const serviceFee = Math.round(basePrice * 0.05);
    const insuranceFee = bookingData.extras.insurance ? Math.round(basePrice * 0.1) : 0;
    const subtotal = basePrice + serviceFee + insuranceFee;
    const gst = Math.round(subtotal * 0.18);
    const totalAmount = subtotal + gst;

    setPricing({ basePrice, serviceFee, insuranceFee, gst, totalAmount, totalHours, totalDays });
  };

  const handleBooking = async () => {
    if (!user) { navigate('/login'); return; }
    if (!bookingData.pickupDate || !bookingData.dropoffDate) {
      toast.error('Please select pickup and drop-off dates'); return;
    }
    if (!pricing) { toast.error('Invalid date selection'); return; }

    setSubmitting(true);
    try {
      const pickup = new Date(`${bookingData.pickupDate}T${bookingData.pickupTime}`);
      const dropoff = new Date(`${bookingData.dropoffDate}T${bookingData.dropoffTime}`);

      const res = await bookingsAPI.create({
        carId: car._id,
        pickupDate: pickup.toISOString(),
        dropoffDate: dropoff.toISOString(),
        extras: bookingData.extras,
      });

      toast.success('Booking created! Proceeding to payment...');
      navigate(`/payment/${res.data.booking._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Booking failed');
    } finally {
      setSubmitting(false);
    }
  };

  const toggleExtra = (key) => {
    setBookingData(prev => ({
      ...prev,
      extras: { ...prev.extras, [key]: !prev.extras[key] }
    }));
  };

  // Set min dates
  const today = new Date().toISOString().split('T')[0];

  if (loading) {
    return (
      <div className="loading-container" style={{ minHeight: '80vh' }}>
        <div className="spinner"></div>
        <p className="loading-text">Loading car details...</p>
      </div>
    );
  }

  if (!car) return null;

  const fallbackImg = `https://placehold.co/700x440/1a1a28/c8ff00?text=${encodeURIComponent(car.name)}`;

  return (
    <div className="car-detail">
      {/* Breadcrumb */}
      <div className="car-detail-breadcrumb">
        <Link to="/">Home</Link>
        <FiChevronRight size={12} />
        <Link to="/cars">Cars</Link>
        <FiChevronRight size={12} />
        <span style={{ color: 'var(--text-primary)' }}>{car.name}</span>
      </div>

      <div className="car-detail-grid">
        {/* Left: Gallery */}
        <div>
          <div className="car-detail-gallery">
            <img
              src={car.images?.[activeImage] || fallbackImg}
              alt={car.name}
              onError={(e) => { e.target.src = fallbackImg; }}
            />
          </div>
          {car.images?.length > 1 && (
            <div className="car-detail-gallery-nav">
              {car.images.map((img, idx) => (
                <img
                  key={idx}
                  src={img}
                  alt={`${car.name} ${idx + 1}`}
                  className={idx === activeImage ? 'active' : ''}
                  onClick={() => setActiveImage(idx)}
                  onError={(e) => { e.target.src = fallbackImg; }}
                />
              ))}
            </div>
          )}

          {/* Description */}
          {car.description && (
            <div style={{ marginTop: 24 }}>
              <h3 style={{ fontSize: 18, marginBottom: 12 }}>About this car</h3>
              <p style={{ color: 'var(--text-secondary)', fontSize: 14, lineHeight: 1.7 }}>{car.description}</p>
            </div>
          )}

          {/* Features */}
          <div style={{ marginTop: 24 }}>
            <h3 style={{ fontSize: 18, marginBottom: 12 }}>Features</h3>
            <div className="car-detail-features">
              {car.features?.map((feat, i) => (
                <span key={i} className="car-detail-feature-tag">
                  <FiCheck size={12} style={{ marginRight: 4 }} /> {feat}
                </span>
              ))}
            </div>
          </div>

          {/* Specifications */}
          <div style={{ marginTop: 24 }}>
            <h3 style={{ fontSize: 18, marginBottom: 12 }}>Specifications</h3>
            <div className="car-detail-specs-grid">
              {car.specifications?.engine && (
                <div className="spec-item">
                  <div className="spec-item-icon"><TbEngine /></div>
                  <div>
                    <div className="spec-item-label">Engine</div>
                    <div className="spec-item-value">{car.specifications.engine}</div>
                  </div>
                </div>
              )}
              {car.specifications?.mileage && (
                <div className="spec-item">
                  <div className="spec-item-icon"><TbGasStation /></div>
                  <div>
                    <div className="spec-item-label">Mileage</div>
                    <div className="spec-item-value">{car.specifications.mileage}</div>
                  </div>
                </div>
              )}
              {car.specifications?.horsepower && (
                <div className="spec-item">
                  <div className="spec-item-icon"><BsSpeedometer /></div>
                  <div>
                    <div className="spec-item-label">Power</div>
                    <div className="spec-item-value">{car.specifications.horsepower}</div>
                  </div>
                </div>
              )}
              {car.specifications?.topSpeed && (
                <div className="spec-item">
                  <div className="spec-item-icon"><BsSpeedometer /></div>
                  <div>
                    <div className="spec-item-label">Top Speed</div>
                    <div className="spec-item-value">{car.specifications.topSpeed}</div>
                  </div>
                </div>
              )}
              {car.specifications?.acceleration && (
                <div className="spec-item">
                  <div className="spec-item-icon"><BsSpeedometer /></div>
                  <div>
                    <div className="spec-item-label">0-100 km/h</div>
                    <div className="spec-item-value">{car.specifications.acceleration}</div>
                  </div>
                </div>
              )}
              {car.specifications?.bootSpace && (
                <div className="spec-item">
                  <div className="spec-item-icon"><FiPackage /></div>
                  <div>
                    <div className="spec-item-label">Boot Space</div>
                    <div className="spec-item-value">{car.specifications.bootSpace}</div>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Smart AI Trip & Fuel Estimator */}
          <AiRoutePlanner car={car} />
        </div>

        {/* Right: Info + Booking */}
        <div className="car-detail-info">
          <h1 className="car-detail-title">{car.name}</h1>
          <p className="car-detail-subtitle">{car.brand} {car.model} · {car.year} · {car.color}</p>

          <div className="car-detail-rating-row">
            <div className="car-detail-rating">
              <BsStarFill style={{ color: 'var(--warning)' }} />
              <span>{car.rating}</span>
            </div>
            <span className="car-detail-trips">{car.totalTrips} trips completed</span>
            <span style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13, color: 'var(--text-muted)' }}>
              <FiMapPin size={13} /> {car.location?.area}, {car.location?.city}
            </span>
          </div>

          <div className="car-detail-price-box">
            <div className="car-detail-price-row">
              <div className="car-detail-price">
                <span className="main-price">₹{car.pricePerDay?.toLocaleString()}</span>
                <span className="per">/day</span>
                <div className="hourly">₹{car.pricePerHour}/hr for short trips</div>
              </div>
              <div style={{ display: 'flex', gap: 12, fontSize: 13, color: 'var(--text-secondary)' }}>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                  <BsFuelPump /> {car.fuelType}
                </span>
                <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                  <FiUsers /> {car.seats} seats
                </span>
              </div>
            </div>
          </div>

          {/* Booking Form */}
          <div className="booking-form-section">
            <h3>Book This Car</h3>
            <div className="form-row">
              <div className="form-group">
                <label><FiCalendar style={{ marginRight: 4 }} /> Pickup Date</label>
                <input
                  type="date"
                  min={today}
                  value={bookingData.pickupDate}
                  onChange={(e) => setBookingData({ ...bookingData, pickupDate: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Pickup Time</label>
                <input
                  type="time"
                  value={bookingData.pickupTime}
                  onChange={(e) => setBookingData({ ...bookingData, pickupTime: e.target.value })}
                />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label><FiCalendar style={{ marginRight: 4 }} /> Drop-off Date</label>
                <input
                  type="date"
                  min={bookingData.pickupDate || today}
                  value={bookingData.dropoffDate}
                  onChange={(e) => setBookingData({ ...bookingData, dropoffDate: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Drop-off Time</label>
                <input
                  type="time"
                  value={bookingData.dropoffTime}
                  onChange={(e) => setBookingData({ ...bookingData, dropoffTime: e.target.value })}
                />
              </div>
            </div>

            {/* Extras */}
            <h4 style={{ fontSize: 14, fontWeight: 600, marginBottom: 12, marginTop: 8 }}>Add-ons</h4>
            <div className="extras-grid">
              <div className={`extra-option ${bookingData.extras.insurance ? 'selected' : ''}`} onClick={() => toggleExtra('insurance')}>
                <div className="extra-check">{bookingData.extras.insurance && <FiCheck size={14} />}</div>
                <div className="extra-info">
                  <div className="extra-name">Trip Insurance</div>
                  <div className="extra-desc">+10% of base price</div>
                </div>
              </div>
              <div className={`extra-option ${bookingData.extras.gps ? 'selected' : ''}`} onClick={() => toggleExtra('gps')}>
                <div className="extra-check">{bookingData.extras.gps && <FiCheck size={14} />}</div>
                <div className="extra-info">
                  <div className="extra-name">GPS Navigator</div>
                  <div className="extra-desc">Included free</div>
                </div>
              </div>
              <div className={`extra-option ${bookingData.extras.childSeat ? 'selected' : ''}`} onClick={() => toggleExtra('childSeat')}>
                <div className="extra-check">{bookingData.extras.childSeat && <FiCheck size={14} />}</div>
                <div className="extra-info">
                  <div className="extra-name">Child Seat</div>
                  <div className="extra-desc">Included free</div>
                </div>
              </div>
              <div className={`extra-option ${bookingData.extras.additionalDriver ? 'selected' : ''}`} onClick={() => toggleExtra('additionalDriver')}>
                <div className="extra-check">{bookingData.extras.additionalDriver && <FiCheck size={14} />}</div>
                <div className="extra-info">
                  <div className="extra-name">Extra Driver</div>
                  <div className="extra-desc">Included free</div>
                </div>
              </div>
            </div>

            {/* Pricing Summary */}
            {pricing && (
              <div className="pricing-summary">
                <h4>Price Breakdown</h4>
                <div className="pricing-row text-muted">
                  <span>Base ({pricing.totalHours}h / {pricing.totalDays}d)</span>
                  <span>₹{pricing.basePrice.toLocaleString()}</span>
                </div>
                <div className="pricing-row text-muted">
                  <span>Service Fee (5%)</span>
                  <span>₹{pricing.serviceFee.toLocaleString()}</span>
                </div>
                {pricing.insuranceFee > 0 && (
                  <div className="pricing-row text-muted">
                    <span>Insurance (10%)</span>
                    <span>₹{pricing.insuranceFee.toLocaleString()}</span>
                  </div>
                )}
                <div className="pricing-row text-muted">
                  <span>GST (18%)</span>
                  <span>₹{pricing.gst.toLocaleString()}</span>
                </div>
                <div className="pricing-row total">
                  <span>Total</span>
                  <span className="amount">₹{pricing.totalAmount.toLocaleString()}</span>
                </div>
              </div>
            )}

            <button
              className="btn btn-primary btn-block btn-lg"
              style={{ marginTop: 24 }}
              onClick={handleBooking}
              disabled={submitting || !pricing}
            >
              {submitting ? 'Creating Booking...' : !user ? 'Sign In to Book' : 'Proceed to Payment'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

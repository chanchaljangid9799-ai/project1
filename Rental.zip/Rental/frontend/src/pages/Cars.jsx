import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { carsAPI } from '../services/api';
import CarCard from '../components/CarCard';
import { FiSearch, FiFilter, FiX, FiCheck, FiSliders } from 'react-icons/fi';
import { BsShieldCheck, BsCarFront, BsStars, BsLightningChargeFill, BsSliders } from 'react-icons/bs';
import { RiCarLine, RiRoadsterLine } from 'react-icons/ri';
import { FiUsers } from 'react-icons/fi';

const categoriesList = [
  { id: '', label: 'All Fleet', icon: BsCarFront },
  { id: 'suv', label: 'SUV', icon: BsShieldCheck },
  { id: 'sedan', label: 'Sedan', icon: BsCarFront },
  { id: 'luxury', label: 'Luxury', icon: BsStars },
  { id: 'electric', label: 'Electric', icon: BsLightningChargeFill },
  { id: 'hatchback', label: 'Hatchback', icon: RiCarLine },
];

export default function Cars() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [cars, setCars] = useState([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({});
  const [showFilters, setShowFilters] = useState(false);

  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    category: searchParams.get('category') || '',
    city: searchParams.get('city') || '',
    transmission: searchParams.get('transmission') || '',
    fuelType: searchParams.get('fuelType') || '',
    sort: searchParams.get('sort') || '',
    minPrice: searchParams.get('minPrice') || '',
    maxPrice: searchParams.get('maxPrice') || '',
  });

  useEffect(() => {
    loadCars();
  }, [searchParams]);

  const loadCars = async () => {
    setLoading(true);
    try {
      const params = Object.fromEntries(searchParams.entries());
      const res = await carsAPI.getAll(params);
      setCars(res.data.cars);
      setPagination(res.data.pagination);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = (e) => {
    e?.preventDefault();
    const newParams = new URLSearchParams();
    Object.entries(filters).forEach(([key, value]) => {
      if (value) newParams.set(key, value);
    });
    setSearchParams(newParams);
    setShowFilters(false);
  };

  const clearFilters = () => {
    setFilters({
      search: '', category: '', city: '', transmission: '',
      fuelType: '', sort: '', minPrice: '', maxPrice: '',
    });
    setSearchParams({});
  };

  const hasFilters = Object.values(filters).some(v => v);

  const updateFilter = (key, value) => {
    const updated = { ...filters, [key]: value };
    setFilters(updated);
    // Apply immediately for selects
    if (key !== 'search' && key !== 'minPrice' && key !== 'maxPrice') {
      const newParams = new URLSearchParams();
      Object.entries(updated).forEach(([k, v]) => {
        if (v) newParams.set(k, v);
      });
      setSearchParams(newParams);
    }
  };

  return (
    <div style={{ paddingTop: 92 }}>
      <section style={{ padding: '0 40px', maxWidth: 1280, margin: '0 auto' }}>
        {/* Category Horizontal Chips Bar (Zoomcar Style) */}
        <div style={{
          display: 'flex',
          gap: 10,
          overflowX: 'auto',
          paddingBottom: 14,
          marginBottom: 20,
          scrollbarWidth: 'none',
          msOverflowStyle: 'none',
          WebkitOverflowScrolling: 'touch'
        }}>
          {categoriesList.map(cat => {
            const Icon = cat.icon;
            const isSelected = (filters.category || '') === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => updateFilter('category', cat.id)}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  padding: '10px 18px',
                  borderRadius: 'var(--radius-full)',
                  border: isSelected ? '1px solid var(--accent)' : '1px solid var(--border-color)',
                  background: isSelected ? 'var(--accent-dim)' : 'var(--bg-card)',
                  color: isSelected ? 'var(--accent)' : 'var(--text-secondary)',
                  fontWeight: isSelected ? 600 : 500,
                  fontSize: 13,
                  cursor: 'pointer',
                  whiteSpace: 'nowrap',
                  transition: 'all 0.2s ease',
                  boxShadow: isSelected ? '0 0 12px rgba(200,255,0,0.15)' : 'none'
                }}
              >
                <Icon size={16} />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search bar & Filter Trigger */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 20, flexWrap: 'wrap' }}>
          <form onSubmit={applyFilters} style={{ flex: '1 1 260px', display: 'flex', gap: 10 }}>
            <div style={{ flex: 1, position: 'relative' }}>
              <FiSearch style={{ position: 'absolute', left: 16, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
              <input
                type="text"
                placeholder="Search cars, brands, cities..."
                value={filters.search}
                onChange={(e) => setFilters({ ...filters, search: e.target.value })}
                style={{
                  width: '100%',
                  padding: '12px 16px 12px 42px',
                  background: 'var(--bg-card)',
                  border: '1px solid var(--border-color)',
                  borderRadius: 'var(--radius-full)',
                  color: 'var(--text-primary)',
                  fontSize: 14,
                }}
              />
            </div>
            <button type="submit" className="btn btn-primary" style={{ padding: '0 20px', borderRadius: 'var(--radius-full)' }}>
              Search
            </button>
          </form>
          <button
            className="btn btn-secondary"
            onClick={() => setShowFilters(!showFilters)}
            style={{
              position: 'relative',
              borderRadius: 'var(--radius-full)',
              padding: '0 18px',
              display: 'flex',
              alignItems: 'center',
              gap: 8
            }}
          >
            <BsSliders size={15} />
            <span>Filters</span>
            {hasFilters && (
              <span style={{
                position: 'absolute', top: -2, right: -2, width: 9, height: 9,
                background: 'var(--accent)', borderRadius: '50%',
                boxShadow: '0 0 8px var(--accent)'
              }}></span>
            )}
          </button>
        </div>

        {/* Filters panel */}
        {showFilters && (
          <div style={{
            background: 'var(--bg-card)',
            border: '1px solid var(--border-color)',
            borderRadius: 'var(--radius-lg)',
            padding: 20,
            marginBottom: 24,
            boxShadow: '0 12px 32px rgba(0,0,0,0.3)'
          }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
                <BsSliders style={{ color: 'var(--accent)' }} /> Detailed Fleet Filters
              </h3>
              <div style={{ display: 'flex', gap: 8 }}>
                {hasFilters && (
                  <button className="btn btn-ghost btn-sm" onClick={clearFilters}>
                    <FiX size={14} /> Clear All
                  </button>
                )}
              </div>
            </div>
            <div className="form-row" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12 }}>
              <div className="form-group">
                <label>Category</label>
                <select value={filters.category} onChange={(e) => updateFilter('category', e.target.value)}>
                  <option value="">All Categories</option>
                  <option value="suv">SUV</option>
                  <option value="sedan">Sedan</option>
                  <option value="luxury">Luxury</option>
                  <option value="electric">Electric</option>
                  <option value="hatchback">Hatchback</option>
                  <option value="sports">Sports / Roadster</option>
                  <option value="minivan">Minivan</option>
                </select>
              </div>
              <div className="form-group">
                <label>City Hub</label>
                <input
                  type="text"
                  placeholder="e.g. Mumbai, Bangalore..."
                  value={filters.city}
                  onChange={(e) => setFilters({ ...filters, city: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Transmission</label>
                <select value={filters.transmission} onChange={(e) => updateFilter('transmission', e.target.value)}>
                  <option value="">Any Transmission</option>
                  <option value="automatic">Automatic</option>
                  <option value="manual">Manual</option>
                </select>
              </div>
              <div className="form-group">
                <label>Fuel Type</label>
                <select value={filters.fuelType} onChange={(e) => updateFilter('fuelType', e.target.value)}>
                  <option value="">Any Fuel</option>
                  <option value="petrol">Petrol</option>
                  <option value="diesel">Diesel</option>
                  <option value="electric">Electric</option>
                  <option value="hybrid">Hybrid</option>
                </select>
              </div>
            </div>
            <div className="form-row" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 12, marginBottom: 0 }}>
              <div className="form-group">
                <label>Min Price (₹/day)</label>
                <input
                  type="number"
                  placeholder="0"
                  value={filters.minPrice}
                  onChange={(e) => setFilters({ ...filters, minPrice: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Max Price (₹/day)</label>
                <input
                  type="number"
                  placeholder="15000"
                  value={filters.maxPrice}
                  onChange={(e) => setFilters({ ...filters, maxPrice: e.target.value })}
                />
              </div>
              <div className="form-group">
                <label>Sort By</label>
                <select value={filters.sort} onChange={(e) => updateFilter('sort', e.target.value)}>
                  <option value="">Relevance</option>
                  <option value="price_low">Price: Low to High</option>
                  <option value="price_high">Price: High to Low</option>
                  <option value="rating">Highest Rated</option>
                  <option value="popular">Most Popular</option>
                </select>
              </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 14 }}>
              <button className="btn btn-primary btn-sm" onClick={applyFilters}>Apply Filters</button>
            </div>
          </div>
        )}

        {/* Active filter pills */}
        {hasFilters && (
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 20 }}>
            {Object.entries(filters).map(([key, value]) => {
              if (!value || key === 'sort') return null;
              return (
                <span key={key} style={{
                  display: 'inline-flex', alignItems: 'center', gap: 6,
                  padding: '5px 12px', background: 'var(--accent-dim)',
                  border: '1px solid rgba(200,255,0,0.2)',
                  borderRadius: 'var(--radius-full)', fontSize: 12,
                  color: 'var(--accent)', fontWeight: 500,
                }}>
                  {key}: {value}
                  <FiX
                    size={13}
                    style={{ cursor: 'pointer' }}
                    onClick={() => updateFilter(key, '')}
                  />
                </span>
              );
            })}
          </div>
        )}

        {/* Results count */}
        <div style={{ marginBottom: 18, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <p style={{ color: 'var(--text-secondary)', fontSize: 14, fontWeight: 500 }}>
            {pagination.total !== undefined ? `${pagination.total} verified vehicles available` : 'Searching fleet...'}
          </p>
        </div>

        {/* Cars grid */}
        {loading ? (
          <div className="cars-grid" style={{ paddingBottom: 60 }}>
            {[1, 2, 3, 4, 5, 6].map(i => <div key={i} className="skeleton skeleton-card"></div>)}
          </div>
        ) : cars.length === 0 ? (
          <div className="empty-state" style={{ padding: '60px 20px' }}>
            <div style={{ width: 56, height: 56, borderRadius: '50%', background: 'rgba(255,255,255,0.05)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', color: 'var(--text-muted)' }}>
              <FiSearch size={28} />
            </div>
            <h3>No cars match your selection</h3>
            <p>Try resetting filters or searching for another city hub</p>
            <button className="btn btn-primary btn-sm" onClick={clearFilters} style={{ marginTop: 12 }}>Reset Filters</button>
          </div>
        ) : (
          <>
            <div className="cars-grid" style={{ paddingBottom: 40 }}>
              {cars.map(car => <CarCard key={car._id} car={car} />)}
            </div>
            {pagination.pages > 1 && (
              <div style={{ display: 'flex', justifyContent: 'center', gap: 8, paddingBottom: 60 }}>
                {Array.from({ length: pagination.pages }, (_, i) => i + 1).map(page => (
                  <button
                    key={page}
                    className={`btn btn-sm ${page === pagination.page ? 'btn-primary' : 'btn-secondary'}`}
                    onClick={() => {
                      const params = new URLSearchParams(searchParams);
                      params.set('page', page);
                      setSearchParams(params);
                    }}
                  >
                    {page}
                  </button>
                ))}
              </div>
            )}
          </>
        )}
      </section>
    </div>
  );
}

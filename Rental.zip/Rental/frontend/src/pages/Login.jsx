import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { FiEye, FiEyeOff, FiAlertCircle, FiZap, FiShield, FiMail, FiLock, FiKey, FiArrowLeft, FiCheckCircle } from 'react-icons/fi';

export default function Login() {
  const { login, loginWithGoogle, sendLoginOtp, loginWithOtp } = useAuth();
  const navigate = useNavigate();

  // Mode: 'otp' or 'password'
  const [authMode, setAuthMode] = useState('otp');

  // Password login form
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);

  // OTP login state
  const [otpEmail, setOtpEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [otpStep, setOtpStep] = useState('enter_email'); // 'enter_email' | 'enter_code'
  const [demoCodeHint, setDemoCodeHint] = useState('');
  const [previewUrl, setPreviewUrl] = useState(null);
  const [countdown, setCountdown] = useState(0);

  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  // Resend countdown timer
  useEffect(() => {
    let timer;
    if (countdown > 0) {
      timer = setTimeout(() => setCountdown(countdown - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [countdown]);

  // Standard Password Submit
  const handlePasswordSubmit = async (e) => {
    if (e) e.preventDefault();
    setError('');

    if (!form.email || !form.password) {
      setError('Please fill in both email and password');
      return;
    }

    setLoading(true);
    try {
      const userData = await login(form.email, form.password);
      toast.success(`Welcome back, ${userData.firstName}!`);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed. Please check credentials.');
    } finally {
      setLoading(false);
    }
  };

  // OTP: Step 1 - Send OTP to Email
  const handleSendOtp = async (e) => {
    if (e) e.preventDefault();
    setError('');

    if (!otpEmail || !otpEmail.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }

    setLoading(true);
    try {
      const res = await sendLoginOtp(otpEmail);
      toast.success(`OTP dispatched to ${otpEmail}!`, { icon: '✉️' });
      setOtpStep('enter_code');
      setCountdown(60);
      if (res.demoOtp) {
        setDemoCodeHint(res.demoOtp);
      }
      if (res.previewUrl) {
        setPreviewUrl(res.previewUrl);
      }
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to dispatch OTP. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  // OTP: Step 2 - Verify OTP Code
  const handleVerifyOtp = async (e) => {
    if (e) e.preventDefault();
    setError('');

    if (!otpCode || otpCode.trim().length < 4) {
      setError('Please enter the 6-digit OTP code received in your email');
      return;
    }

    setLoading(true);
    try {
      const userData = await loginWithOtp(otpEmail, otpCode.trim());
      toast.success(`Verified! Welcome, ${userData.firstName}!`, { icon: '🎉' });
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Invalid or expired OTP code');
    } finally {
      setLoading(false);
    }
  };

  // Google 1-Click Sign-in
  const handleGoogleSignIn = async () => {
    setLoading(true);
    setError('');
    try {
      const userData = await loginWithGoogle({
        email: 'guest.driver@driveease.com',
        firstName: 'Guest',
        lastName: 'Driver'
      });
      toast.success(`Signed in as ${userData.firstName}!`, { icon: '🇬' });
      navigate('/dashboard');
    } catch (err) {
      setError('Google Sign-In failed');
    } finally {
      setLoading(false);
    }
  };

  // 1-Click Quick Demo Login
  const handleQuickLogin = async (email, password) => {
    setForm({ email, password });
    setLoading(true);
    setError('');
    try {
      const userData = await login(email, password);
      toast.success(`Welcome, ${userData.firstName}!`);
      navigate('/dashboard');
    } catch (err) {
      setError(err.response?.data?.message || 'Quick login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-card">
          {/* Logo & Header */}
          <div className="auth-header">
            <Link to="/" className="auth-logo">
              <img src="/logo-icon.png" alt="DriveEase" className="auth-logo-img" />
              <span>Drive<span style={{ color: 'var(--accent)' }}>Ease</span></span>
            </Link>
            <h2>Welcome to DriveEase</h2>
            <p>Access your fleet bookings, digital keys & invoices</p>
          </div>

          {/* Google Sign-In Button */}
          <button
            type="button"
            className="btn btn-google-auth"
            onClick={handleGoogleSignIn}
            disabled={loading}
          >
            <svg width="20" height="20" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"/>
            </svg>
            <span>Continue with Google</span>
          </button>

          <div className="auth-divider">
            <span>or sign in with</span>
          </div>

          {/* Auth Method Selector Tabs */}
          <div className="auth-tabs" style={{ display: 'flex', gap: '8px', marginBottom: '20px', background: 'rgba(255,255,255,0.03)', padding: '4px', borderRadius: '10px', border: '1px solid rgba(255,255,255,0.06)' }}>
            <button
              type="button"
              className={`auth-tab-btn ${authMode === 'otp' ? 'active' : ''}`}
              onClick={() => { setAuthMode('otp'); setError(''); }}
              style={{
                flex: 1,
                padding: '9px 12px',
                borderRadius: '8px',
                border: 'none',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                background: authMode === 'otp' ? 'var(--accent)' : 'transparent',
                color: authMode === 'otp' ? '#000' : 'var(--text-secondary)',
                transition: 'all 0.2s ease'
              }}
            >
              <FiKey size={14} /> Gmail / Email OTP
            </button>
            <button
              type="button"
              className={`auth-tab-btn ${authMode === 'password' ? 'active' : ''}`}
              onClick={() => { setAuthMode('password'); setError(''); }}
              style={{
                flex: 1,
                padding: '9px 12px',
                borderRadius: '8px',
                border: 'none',
                cursor: 'pointer',
                fontSize: '13px',
                fontWeight: 600,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                gap: '6px',
                background: authMode === 'password' ? 'var(--accent)' : 'transparent',
                color: authMode === 'password' ? '#000' : 'var(--text-secondary)',
                transition: 'all 0.2s ease'
              }}
            >
              <FiLock size={14} /> Password
            </button>
          </div>

          {/* Quick Demo Credentials */}
          <div className="quick-login-box">
            <div className="quick-login-title">
              <FiZap size={14} /> 1-Click Fast Login (Hackathon Demo)
            </div>
            <div className="quick-login-buttons">
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => handleQuickLogin('ankul@demo.com', 'demo1234')}
                disabled={loading}
              >
                👤 Demo User
              </button>
              <button
                type="button"
                className="btn btn-secondary btn-sm"
                onClick={() => handleQuickLogin('admin@driveease.com', 'admin123')}
                disabled={loading}
              >
                <FiShield size={14} /> Demo Admin
              </button>
            </div>
          </div>

          {error && (
            <div className="auth-error">
              <FiAlertCircle size={16} />
              {error}
            </div>
          )}

          {/* TAB 1: OTP SIGN IN */}
          {authMode === 'otp' && (
            <div className="otp-auth-section">
              {otpStep === 'enter_email' ? (
                <form className="auth-form" onSubmit={handleSendOtp}>
                  <div className="form-group">
                    <label>Your Gmail or Email Address</label>
                    <div style={{ position: 'relative' }}>
                      <input
                        type="email"
                        placeholder="e.g. yourname@gmail.com"
                        value={otpEmail}
                        onChange={(e) => setOtpEmail(e.target.value)}
                        autoComplete="email"
                        required
                        style={{ paddingLeft: '38px' }}
                      />
                      <FiMail size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-secondary)' }} />
                    </div>
                    <small style={{ display: 'block', marginTop: '6px', fontSize: '11px', color: 'var(--text-secondary)' }}>
                      We will dispatch a secure 6-digit OTP code directly to your email inbox.
                    </small>
                  </div>

                  <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: '100%', marginTop: '8px' }}>
                    {loading ? 'Dispatching OTP...' : 'Send 6-Digit OTP Code'}
                  </button>
                </form>
              ) : (
                <form className="auth-form" onSubmit={handleVerifyOtp}>
                  <div style={{ background: 'rgba(200, 255, 0, 0.05)', border: '1px solid rgba(200, 255, 0, 0.2)', borderRadius: '10px', padding: '14px', marginBottom: '16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '4px' }}>
                      <span style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>Sent code to:</span>
                      <button
                        type="button"
                        onClick={() => { setOtpStep('enter_email'); setOtpCode(''); }}
                        style={{ background: 'none', border: 'none', color: 'var(--accent)', fontSize: '12px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: '4px' }}
                      >
                        <FiArrowLeft size={12} /> Change
                      </button>
                    </div>
                    <div style={{ fontWeight: 600, color: '#fff', fontSize: '14px' }}>{otpEmail}</div>
                    {demoCodeHint && (
                      <div style={{ marginTop: '8px', fontSize: '11px', color: 'var(--accent)', display: 'flex', alignItems: 'center', gap: '4px' }}>
                        <FiCheckCircle size={12} /> Demo Code: <strong>{demoCodeHint}</strong> (or 123456)
                      </div>
                    )}
                    {previewUrl && (
                      <div style={{ marginTop: '6px' }}>
                        <a href={previewUrl} target="_blank" rel="noreferrer" style={{ fontSize: '11px', color: '#00f0ff', textDecoration: 'underline' }}>
                          Open Ethereal Email Preview ↗
                        </a>
                      </div>
                    )}
                  </div>

                  <div className="form-group">
                    <label>Enter 6-Digit Verification Code</label>
                    <input
                      type="text"
                      maxLength={6}
                      placeholder="••••••"
                      value={otpCode}
                      onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                      autoFocus
                      required
                      style={{
                        textAlign: 'center',
                        fontSize: '24px',
                        letterSpacing: '8px',
                        fontWeight: 700,
                        fontFamily: 'monospace'
                      }}
                    />
                  </div>

                  <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: '100%' }}>
                    {loading ? 'Verifying OTP...' : 'Verify & Sign In'}
                  </button>

                  <div style={{ textAlign: 'center', marginTop: '12px' }}>
                    <button
                      type="button"
                      disabled={countdown > 0 || loading}
                      onClick={handleSendOtp}
                      style={{
                        background: 'none',
                        border: 'none',
                        color: countdown > 0 ? 'var(--text-secondary)' : 'var(--accent)',
                        fontSize: '12px',
                        cursor: countdown > 0 ? 'default' : 'pointer'
                      }}
                    >
                      {countdown > 0 ? `Resend OTP in ${countdown}s` : 'Didn’t receive code? Resend OTP'}
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* TAB 2: PASSWORD SIGN IN */}
          {authMode === 'password' && (
            <form className="auth-form" onSubmit={handlePasswordSubmit}>
              <div className="form-group">
                <label>Email Address</label>
                <input
                  type="email"
                  placeholder="you@example.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  autoComplete="email"
                  required
                />
              </div>
              <div className="form-group">
                <label>Password</label>
                <div className="password-field">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    autoComplete="current-password"
                    required
                  />
                  <button
                    type="button"
                    className="password-toggle"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <FiEyeOff /> : <FiEye />}
                  </button>
                </div>
              </div>

              <button type="submit" className="btn btn-primary" disabled={loading}>
                {loading ? 'Signing in...' : 'Sign In'}
              </button>
            </form>
          )}

          <div className="auth-alt">
            Don't have an account? <Link to="/register">Create one</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

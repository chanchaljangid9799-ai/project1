import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || '/api';

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Attach token to every request
api.interceptors.request.use(function (config) {
  const token = localStorage.getItem('driveease_token');
  if (token) {
    config.headers.Authorization = 'Bearer ' + token;
  }
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  function (response) {
    return response;
  },
  function (error) {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem('driveease_token');
      localStorage.removeItem('driveease_user');
      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }
    return Promise.reject(error);
  }
);

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  sendOtp: (data) => api.post('/auth/send-otp', data),
  verifyOtp: (data) => api.post('/auth/verify-otp', data),
  googleLogin: (data) => api.post('/auth/google', data),
  getMe: () => api.get('/auth/me'),
  updateProfile: (data) => api.put('/auth/profile', data),
};

export const carsAPI = {
  getAll: (params) => api.get('/cars', { params }),
  getById: (id) => api.get('/cars/' + id),
  getCategories: () => api.get('/cars/meta/categories'),
  getCities: () => api.get('/cars/meta/cities'),
};

export const bookingsAPI = {
  create: (data) => api.post('/bookings', data),
  getMyBookings: (params) => api.get('/bookings/my', { params }),
  getById: (id) => api.get('/bookings/' + id),
  sendOtp: (id) => api.post('/bookings/' + id + '/send-otp'),
  verifyOtp: (id, otp) => api.post('/bookings/' + id + '/verify-otp', { otp }),
  processPayment: (id, data) => api.post('/bookings/' + id + '/pay', data),
  cancel: (id, data) => api.put('/bookings/' + id + '/cancel', data),
  getEmailPreview: (id) => api.get('/bookings/' + id + '/email-preview'),
  resendEmail: (id, email) => api.post('/bookings/' + id + '/resend-email', { email }),
};

export default api;

import { createContext, useContext, useState, useEffect } from 'react';
import { authAPI } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('driveease_token');
    const savedUser = localStorage.getItem('driveease_user');
    if (token && savedUser) {
      try {
        setUser(JSON.parse(savedUser));
      } catch {
        localStorage.removeItem('driveease_token');
        localStorage.removeItem('driveease_user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    const res = await authAPI.login({ email, password });
    const { token, user: userData } = res.data;
    localStorage.setItem('driveease_token', token);
    localStorage.setItem('driveease_user', JSON.stringify(userData));
    setUser(userData);
    return userData;
  };

  const loginWithGoogle = async (customProfile = {}) => {
    const defaultGoogleUser = {
      email: customProfile.email || 'guest.driver@driveease.com',
      firstName: customProfile.firstName || 'Alex',
      lastName: customProfile.lastName || 'Driver',
      avatar: customProfile.avatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'
    };
    const res = await authAPI.googleLogin(defaultGoogleUser);
    const { token, user: userData } = res.data;
    localStorage.setItem('driveease_token', token);
    localStorage.setItem('driveease_user', JSON.stringify(userData));
    setUser(userData);
    return userData;
  };

  const sendLoginOtp = async (email) => {
    const res = await authAPI.sendOtp({ email });
    return res.data;
  };

  const loginWithOtp = async (email, otp) => {
    const res = await authAPI.verifyOtp({ email, otp });
    const { token, user: userData } = res.data;
    localStorage.setItem('driveease_token', token);
    localStorage.setItem('driveease_user', JSON.stringify(userData));
    setUser(userData);
    return userData;
  };

  const register = async (formData) => {
    const res = await authAPI.register(formData);
    const { token, user: userData } = res.data;
    localStorage.setItem('driveease_token', token);
    localStorage.setItem('driveease_user', JSON.stringify(userData));
    setUser(userData);
    return userData;
  };

  const logout = () => {
    localStorage.removeItem('driveease_token');
    localStorage.removeItem('driveease_user');
    setUser(null);
  };

  const updateUser = (newData) => {
    const updated = { ...user, ...newData };
    localStorage.setItem('driveease_user', JSON.stringify(updated));
    setUser(updated);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, loginWithGoogle, sendLoginOtp, loginWithOtp, register, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

require('dotenv').config();
const express = require('express');
const path = require('path');
const cors = require('cors');
const { connectDB, isMongoActive } = require('./db/connection');

const authRoutes = require('./routes/auth');
const carRoutes = require('./routes/cars');
const bookingRoutes = require('./routes/bookings');

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/cars', carRoutes);
app.use('/api/bookings', bookingRoutes);

// Health check with DB status
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    mode: isMongoActive() ? 'mongodb' : 'zero-config-in-memory',
    email: process.env.SMTP_USER ? `Gmail (${process.env.SMTP_USER})` : 'Ethereal Test (preview URLs in console)',
    timestamp: new Date().toISOString()
  });
});

// ── Serve Frontend Build ─────────────────────────────────────────
// Serves the Vite-built React app from ../frontend/dist
const FRONTEND_DIST = path.join(__dirname, '..', 'frontend', 'dist');
app.use(express.static(FRONTEND_DIST));

// SPA Fallback — any non-API route serves index.html so React Router works
app.get(/^\/(?!api\/).*/, (req, res) => {
  res.sendFile(path.join(FRONTEND_DIST, 'index.html'));
});

// Error handler
app.use((err, req, res, next) => {
  console.error('Server error:', err);
  res.status(500).json({
    success: false,
    message: err.message || 'Internal server error'
  });
});

// Start server
const PORT = process.env.PORT || 5001;

connectDB().then(() => {
    app.listen(PORT, '0.0.0.0', () => {
    const emailMode = process.env.SMTP_USER
      ? `Gmail SMTP (${process.env.SMTP_USER})`
      : 'Ethereal Test Mail (preview URLs in console)';

    console.log(`\n🚀 ════════════════════════════════════════════════════`);
    console.log(`🚀  DriveEase — Full-Stack Server`);
    console.log(`🚀  URL:   http://localhost:${PORT}`);
    console.log(`🚀  DB:    ${isMongoActive() ? 'Production MongoDB' : 'Zero-Config In-Memory (no MongoDB needed)'}`);
    console.log(`🚀  Email: ${emailMode}`);
    console.log(`🚀  ────────────────────────────────────────────────────`);
    console.log(`🚀  Demo Accounts:`);
    console.log(`     • User:  ankul@demo.com / demo1234`);
    console.log(`     • Admin: admin@driveease.com / admin123`);
    console.log(`🚀  ────────────────────────────────────────────────────`);
    console.log(`🚀  Open http://localhost:${PORT} in your browser!`);
    console.log(`🚀 ════════════════════════════════════════════════════\n`);
  });
}).catch(err => {
  console.error('Failed to start server:', err);
});

module.exports = app;

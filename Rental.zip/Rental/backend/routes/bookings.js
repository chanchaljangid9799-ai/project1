const express = require('express');
const { v4: uuidv4 } = require('uuid');
const Booking = require('../models/Booking');
const Car = require('../models/Car');
const { protect, adminOnly } = require('../middleware/auth');
const { sendBookingConfirmation, sendOtpNotification, getEmailForBooking, generateBookingEmailHtml } = require('../services/emailService');

const router = express.Router();

// Memory store for active booking OTPs
const bookingOtps = new Map();

// Create booking
router.post('/', protect, async (req, res) => {
  try {
    const {
      carId,
      pickupDate,
      dropoffDate,
      pickupLocation,
      dropoffLocation,
      extras,
      paymentMethod
    } = req.body;

    const car = await Car.findById(carId);
    if (!car) {
      return res.status(404).json({ success: false, message: 'Car not found' });
    }

    if (!car.availability) {
      return res.status(400).json({ success: false, message: 'Car is not currently available' });
    }

    // Check for overlapping bookings
    const overlap = await Booking.findOne({
      car: carId,
      status: { $in: ['pending', 'confirmed', 'active'] },
      $or: [
        { pickupDate: { $lte: new Date(dropoffDate) }, dropoffDate: { $gte: new Date(pickupDate) } }
      ]
    });

    if (overlap) {
      return res.status(400).json({
        success: false,
        message: 'This car is already reserved for the selected dates. Please choose different dates.'
      });
    }

    // Calculate pricing
    const pickup = new Date(pickupDate);
    const dropoff = new Date(dropoffDate);
    const totalHours = Math.max(1, Math.ceil((dropoff - pickup) / (1000 * 60 * 60)));
    const totalDays = Math.max(1, Math.ceil(totalHours / 24));

    let basePrice;
    if (totalHours <= 12) {
      basePrice = car.pricePerHour * totalHours;
    } else {
      basePrice = car.pricePerDay * totalDays;
    }

    const serviceFee = Math.round(basePrice * 0.05);
    const insuranceFee = extras?.insurance ? Math.round(basePrice * 0.1) : 0;
    const subtotal = basePrice + serviceFee + insuranceFee;
    const gst = Math.round(subtotal * 0.18);
    const totalAmount = subtotal + gst;

    const booking = await Booking.create({
      user: req.user._id,
      car: carId,
      pickupDate: pickup,
      dropoffDate: dropoff,
      pickupLocation: pickupLocation || {
        address: car.location?.area || 'DriveEase Hub',
        city: car.location?.city || 'Mumbai'
      },
      dropoffLocation: dropoffLocation || pickupLocation || {
        address: car.location?.area || 'DriveEase Hub',
        city: car.location?.city || 'Mumbai'
      },
      totalHours,
      pricing: {
        basePrice,
        serviceFee,
        insuranceFee,
        gst,
        totalAmount
      },
      payment: {
        method: paymentMethod || 'card',
        status: 'pending'
      },
      extras: extras || {},
      status: 'pending'
    });

    await booking.populate('car');

    // Automatically generate and dispatch initial OTP for this booking
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    bookingOtps.set(booking._id.toString(), {
      otp,
      expiresAt: Date.now() + 10 * 60 * 1000,
      verified: false
    });

    res.status(201).json({
      success: true,
      booking,
      otpSent: true,
      demoOtp: otp,
      otpPhone: req.user.phone || '9876543210',
      otpEmail: req.user.email
    });

    // Dispatch OTP notification in background
    sendOtpNotification({
      user: req.user,
      car,
      bookingId: booking._id,
      otpCode: otp
    }).catch(err => console.warn('Background booking OTP notification notice:', err.message));
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Send/Resend OTP for a booking
router.post('/:id/send-otp', protect, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      _id: req.params.id,
      user: req.user._id
    }).populate('car');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    bookingOtps.set(booking._id.toString(), {
      otp,
      expiresAt: Date.now() + 10 * 60 * 1000,
      verified: false
    });

    res.json({
      success: true,
      message: `OTP sent to +91-${req.user.phone || '9876543210'} and ${req.user.email}`,
      demoOtp: otp,
      phone: req.user.phone,
      email: req.user.email
    });

    sendOtpNotification({
      user: req.user,
      car: booking.car,
      bookingId: booking._id,
      otpCode: otp
    }).catch(err => console.warn('Resend booking OTP notice:', err.message));
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Verify OTP
router.post('/:id/verify-otp', protect, async (req, res) => {
  try {
    const { otp } = req.body;
    const stored = bookingOtps.get(req.params.id.toString());

    if (!stored) {
      return res.status(400).json({ success: false, message: 'OTP expired or not requested. Please request a new OTP.' });
    }

    if (Date.now() > stored.expiresAt) {
      bookingOtps.delete(req.params.id.toString());
      return res.status(400).json({ success: false, message: 'OTP has expired. Please click Resend OTP.' });
    }

    if (stored.otp !== (otp || '').trim() && (otp || '').trim() !== '123456') {
      return res.status(400).json({ success: false, message: 'Invalid OTP code. Please check your email or phone SMS.' });
    }

    stored.verified = true;
    bookingOtps.set(req.params.id.toString(), stored);

    res.json({
      success: true,
      message: 'OTP verified successfully! Proceed to payment.'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Process payment (demo gateway)
router.post('/:id/pay', protect, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    if (booking.payment && booking.payment.status === 'completed') {
      return res.status(400).json({ success: false, message: 'Payment already completed for this booking' });
    }

    const { cardNumber, cardName, expiry, cvv, upiId, method } = req.body;

    // Demo: fail if card ends with 0000
    if (method === 'card' && cardNumber && cardNumber.endsWith('0000')) {
      booking.payment.status = 'failed';
      await booking.save();
      return res.status(400).json({
        success: false,
        message: 'Payment was declined by card issuer. Use 4242 4242 4242 4242 for success.'
      });
    }

    // Generate unique transaction ID
    const txnPrefix = method === 'upi' ? 'UPI_' : method === 'netbanking' ? 'NB_' : 'TXN_';
    const txnId = txnPrefix + uuidv4().replace(/-/g, '').substring(0, 14).toUpperCase();

    booking.payment.transactionId = txnId;
    booking.payment.status = 'completed';
    booking.payment.paidAt = new Date();
    booking.payment.method = method || 'card';
    booking.status = 'confirmed';

    await booking.populate('car');

    // Automatically send confirmation email via Nodemailer
    const emailResult = await sendBookingConfirmation({
      booking,
      car: booking.car,
      user: req.user,
      recipientEmail: req.body.email || req.user.email
    });

    booking.emailSent = emailResult.success;
    booking.emailPreviewUrl = emailResult.previewUrl || '';

    await booking.save();

    // Increment trips count for the car
    if (booking.car && booking.car._id) {
      await Car.findByIdAndUpdate(booking.car._id, { $inc: { totalTrips: 1 } });
    }

    res.json({
      success: true,
      booking,
      transactionId: txnId,
      emailSent: emailResult.success,
      emailPreviewUrl: emailResult.previewUrl || null,
      emailHtml: emailResult.html || null
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// View email preview for a booking
router.get('/:id/email-preview', protect, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      _id: req.params.id,
      user: req.user._id
    }).populate('car');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    const emailEntry = getEmailForBooking(booking._id);
    const html = emailEntry ? emailEntry.html : generateBookingEmailHtml({
      booking,
      car: booking.car,
      user: req.user
    });

    res.json({
      success: true,
      previewUrl: emailEntry?.previewUrl || booking.emailPreviewUrl || null,
      html,
      recipient: emailEntry?.to || req.user.email,
      sentAt: emailEntry?.sentAt || booking.createdAt
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Resend email confirmation
router.post('/:id/resend-email', protect, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      _id: req.params.id,
      user: req.user._id
    }).populate('car');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    const targetEmail = req.body.email || req.user.email;
    const result = await sendBookingConfirmation({
      booking,
      car: booking.car,
      user: req.user,
      recipientEmail: targetEmail
    });

    if (result.success) {
      booking.emailSent = true;
      if (result.previewUrl) booking.emailPreviewUrl = result.previewUrl;
      await booking.save();
    }

    res.json({
      success: result.success,
      previewUrl: result.previewUrl,
      recipient: targetEmail,
      message: `Confirmation email dispatched to ${targetEmail}`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get user's bookings
router.get('/my', protect, async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const filter = { user: req.user._id };
    if (status && status !== 'all') filter.status = status;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Booking.countDocuments(filter);
    const bookings = await Booking.find(filter)
      .populate('car')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.json({
      success: true,
      bookings,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Get single booking
router.get('/:id', protect, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      _id: req.params.id,
      user: req.user._id
    }).populate('car');

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    res.json({ success: true, booking });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Cancel booking
router.put('/:id/cancel', protect, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      _id: req.params.id,
      user: req.user._id
    });

    if (!booking) {
      return res.status(404).json({ success: false, message: 'Booking not found' });
    }

    if (['completed', 'cancelled'].includes(booking.status)) {
      return res.status(400).json({
        success: false,
        message: `Cannot cancel a ${booking.status} booking`
      });
    }

    booking.status = 'cancelled';
    booking.cancellationReason = req.body.reason || 'Cancelled by user';

    if (booking.payment && booking.payment.status === 'completed') {
      booking.payment.status = 'refunded';
    }

    await booking.save();
    await booking.populate('car');

    res.json({
      success: true,
      booking,
      message: 'Booking cancelled successfully. Refund initiated.'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Admin: Get all bookings
router.get('/admin/all', protect, adminOnly, async (req, res) => {
  try {
    const { status, page = 1, limit = 20 } = req.query;
    const filter = {};
    if (status) filter.status = status;

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const total = await Booking.countDocuments(filter);
    const bookings = await Booking.find(filter)
      .populate('car')
      .populate('user', 'firstName lastName email phone')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(parseInt(limit));

    res.json({
      success: true,
      bookings,
      pagination: {
        total,
        page: parseInt(page),
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;

const mongoose = require('mongoose');
const { initStore } = require('./store');

let isConnectedToMongo = false;

const connectDB = async () => {
  if (process.env.FORCE_IN_MEMORY === 'true') {
    console.log('⚡ [DriveEase Engine] In-Memory DB Mode active');
    await initStore();
    return false;
  }

  const mongoUri = process.env.MONGODB_URI || 'mongodb://localhost:27017/driveease';
  try {
    await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 2000
    });
    isConnectedToMongo = true;
    console.log('✓ MongoDB connected successfully');
    return true;
  } catch (err) {
    console.warn(`⚠️ [DriveEase Notice] MongoDB not reachable at ${mongoUri}.`);
    console.log('⚡ [DriveEase Engine] Activating Zero-Config Database with Auto-Seed & Persistence!');
    await initStore();
    return false;
  }
};

const isMongoActive = () => isConnectedToMongo && mongoose.connection.readyState === 1;

module.exports = {
  connectDB,
  isMongoActive
};

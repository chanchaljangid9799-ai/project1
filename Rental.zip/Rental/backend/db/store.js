const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const carsData = require('./carsData');

const DATA_DIR = path.join(__dirname, '../data');
const DATA_FILE = path.join(DATA_DIR, 'store.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// In-memory state
const state = {
  users: [],
  cars: [],
  bookings: []
};

// Save to disk
const persist = () => {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(state, null, 2));
  } catch (err) {
    console.error('Failed to persist store:', err.message);
  }
};

// Seed default users and cars if empty
const seedDefaults = async () => {
  // Cars
  if (state.cars.length === 0) {
    state.cars = carsData.map((c, idx) => ({
      ...c,
      _id: 'car_' + (idx + 1).toString().padStart(4, '0'),
      availability: true,
      createdAt: new Date(),
      updatedAt: new Date()
    }));
    console.log(`✓ Seeded ${state.cars.length} cars into store`);
  }

  // Users
  const hasAdmin = state.users.some(u => u.email === 'admin@driveease.com');
  if (!hasAdmin) {
    const adminPass = await bcrypt.hash('admin123', 10);
    state.users.push({
      _id: 'usr_admin_' + uuidv4().substring(0, 8),
      firstName: 'Admin',
      lastName: 'DriveEase',
      email: 'admin@driveease.com',
      phone: '9999999999',
      password: adminPass,
      role: 'admin',
      isVerified: true,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150',
      drivingLicense: 'DL-IND-ADM-001',
      savedAddresses: [
        { label: 'Headquarters', address: 'Bandra Kurla Complex', city: 'Mumbai', state: 'Maharashtra', pincode: '400051' }
      ],
      createdAt: new Date(),
      updatedAt: new Date()
    });
    console.log('✓ Seeded admin user: admin@driveease.com / admin123');
  }

  const hasDemo = state.users.some(u => u.email === 'ankul@demo.com');
  if (!hasDemo) {
    const demoPass = await bcrypt.hash('demo1234', 10);
    state.users.push({
      _id: 'usr_demo_' + uuidv4().substring(0, 8),
      firstName: 'Ankul',
      lastName: 'Sharma',
      email: 'ankul@demo.com',
      phone: '9876543210',
      password: demoPass,
      role: 'user',
      isVerified: true,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      drivingLicense: 'DL-04-2022-998877',
      savedAddresses: [
        { label: 'Home', address: 'Palm Beach Road, Nerul', city: 'Mumbai', state: 'Maharashtra', pincode: '400706' }
      ],
      createdAt: new Date(),
      updatedAt: new Date()
    });
    console.log('✓ Seeded demo user: ankul@demo.com / demo1234');
  }

  persist();
};

// Initialize
const initStore = async () => {
  if (fs.existsSync(DATA_FILE)) {
    try {
      const data = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
      state.users = data.users || [];
      state.cars = data.cars || [];
      state.bookings = data.bookings || [];
    } catch (e) {
      console.warn('Could not read existing store file, creating fresh:', e.message);
    }
  }
  await seedDefaults();
};

// Clone object helper
const clone = (obj) => JSON.parse(JSON.stringify(obj));

// User wrapper with comparePassword
const wrapUser = (u, includePassword = false) => {
  if (!u) return null;
  const userObj = clone(u);
  if (!includePassword) {
    delete userObj.password;
  }
  userObj.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, u.password);
  };
  userObj.save = async function() {
    const idx = state.users.findIndex(x => x._id === u._id);
    if (idx !== -1) {
      state.users[idx] = { ...state.users[idx], ...userObj, updatedAt: new Date() };
      persist();
    }
    return wrapUser(state.users[idx]);
  };
  return userObj;
};

// User Model API
const UserModel = {
  findOne: (query) => {
    let includePassword = false;
    const promise = (async () => {
      const u = state.users.find(x => {
        if (query.email && x.email.toLowerCase() !== query.email.toLowerCase()) return false;
        if (query._id && x._id.toString() !== query._id.toString()) return false;
        return true;
      });
      return wrapUser(u, includePassword);
    })();

    promise.select = function(field) {
      if (field && field.includes('+password')) {
        includePassword = true;
      }
      return promise;
    };
    return promise;
  },

  findById: (id) => {
    let includePassword = false;
    const promise = (async () => {
      const u = state.users.find(x => x._id.toString() === id.toString());
      return wrapUser(u, includePassword);
    })();
    promise.select = function(field) {
      if (field && field.includes('+password')) includePassword = true;
      return promise;
    };
    return promise;
  },

  create: async (userData) => {
    const existing = state.users.find(u => u.email.toLowerCase() === userData.email.toLowerCase());
    if (existing) {
      const err = new Error('Email already in use');
      err.code = 11000;
      throw err;
    }

    let hashedPassword = userData.password;
    if (!hashedPassword.startsWith('$2a$') && !hashedPassword.startsWith('$2b$')) {
      hashedPassword = await bcrypt.hash(userData.password, 10);
    }

    const newUser = {
      _id: 'usr_' + uuidv4().replace(/-/g, '').substring(0, 16),
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email.toLowerCase(),
      phone: userData.phone,
      password: hashedPassword,
      role: userData.role || 'user',
      isVerified: userData.isVerified || false,
      avatar: userData.avatar || '',
      drivingLicense: userData.drivingLicense || '',
      savedAddresses: userData.savedAddresses || [],
      createdAt: new Date(),
      updatedAt: new Date()
    };

    state.users.push(newUser);
    persist();
    return wrapUser(newUser, false);
  },

  findByIdAndUpdate: async (id, update, options) => {
    const idx = state.users.findIndex(x => x._id.toString() === id.toString());
    if (idx === -1) return null;
    state.users[idx] = { ...state.users[idx], ...update, updatedAt: new Date() };
    persist();
    return wrapUser(state.users[idx], false);
  },

  countDocuments: async () => state.users.length,
  deleteMany: async () => { state.users = []; persist(); }
};

// Car Model API
const CarModel = {
  find: (filter = {}) => {
    let results = state.cars.filter(car => {
      if (filter.availability !== undefined && car.availability !== filter.availability) return false;
      if (filter.category && car.category !== filter.category) return false;
      if (filter.transmission && car.transmission !== filter.transmission) return false;
      if (filter.fuelType && car.fuelType !== filter.fuelType) return false;
      if (filter.seats && car.seats !== filter.seats) return false;

      // City regex
      if (filter['location.city']) {
        const cityPattern = filter['location.city'];
        const cityStr = car.location?.city || '';
        if (cityPattern instanceof RegExp) {
          if (!cityPattern.test(cityStr)) return false;
        } else if (typeof cityPattern === 'string') {
          if (!cityStr.toLowerCase().includes(cityPattern.toLowerCase())) return false;
        }
      }

      // Price range
      if (filter.pricePerDay) {
        if (filter.pricePerDay.$gte && car.pricePerDay < filter.pricePerDay.$gte) return false;
        if (filter.pricePerDay.$lte && car.pricePerDay > filter.pricePerDay.$lte) return false;
      }

      // Search query ($or)
      if (filter.$or && Array.isArray(filter.$or)) {
        const matchesAny = filter.$or.some(clause => {
          if (clause.name && clause.name.test && clause.name.test(car.name)) return true;
          if (clause.brand && clause.brand.test && clause.brand.test(car.brand)) return true;
          if (clause.model && clause.model.test && clause.model.test(car.model)) return true;
          return false;
        });
        if (!matchesAny) return false;
      }

      return true;
    });

    let sortFn = null;
    let skipCount = 0;
    let limitCount = results.length;

    const queryPromise = (async () => {
      let list = [...results];
      if (sortFn) list.sort(sortFn);
      if (skipCount > 0) list = list.slice(skipCount);
      if (limitCount > 0) list = list.slice(0, limitCount);
      return list.map(clone);
    })();

    queryPromise.sort = function(sortOptions) {
      sortFn = (a, b) => {
        if (sortOptions.pricePerDay === 1) return a.pricePerDay - b.pricePerDay;
        if (sortOptions.pricePerDay === -1) return b.pricePerDay - a.pricePerDay;
        if (sortOptions.rating === -1) return b.rating - a.rating;
        if (sortOptions.totalTrips === -1) return b.totalTrips - a.totalTrips;
        return new Date(b.createdAt) - new Date(a.createdAt);
      };
      return queryPromise;
    };

    queryPromise.skip = function(n) {
      skipCount = n;
      return queryPromise;
    };

    queryPromise.limit = function(n) {
      limitCount = n;
      return queryPromise;
    };

    return queryPromise;
  },

  findById: async (id) => {
    const car = state.cars.find(c => c._id.toString() === id.toString());
    return car ? clone(car) : null;
  },

  findByIdAndUpdate: async (id, update, options) => {
    const idx = state.cars.findIndex(c => c._id.toString() === id.toString());
    if (idx === -1) return null;
    state.cars[idx] = { ...state.cars[idx], ...update, updatedAt: new Date() };
    persist();
    return clone(state.cars[idx]);
  },

  findByIdAndDelete: async (id) => {
    const idx = state.cars.findIndex(c => c._id.toString() === id.toString());
    if (idx === -1) return null;
    const deleted = state.cars.splice(idx, 1)[0];
    persist();
    return clone(deleted);
  },

  create: async (carData) => {
    const newCar = {
      ...carData,
      _id: 'car_' + uuidv4().replace(/-/g, '').substring(0, 12),
      availability: carData.availability !== undefined ? carData.availability : true,
      rating: carData.rating || 4.8,
      totalTrips: carData.totalTrips || 0,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    state.cars.push(newCar);
    persist();
    return clone(newCar);
  },

  insertMany: async (items) => {
    const created = items.map((c, i) => ({
      ...c,
      _id: c._id || 'car_' + uuidv4().replace(/-/g, '').substring(0, 12),
      createdAt: new Date(),
      updatedAt: new Date()
    }));
    state.cars.push(...created);
    persist();
    return created;
  },

  countDocuments: async (filter = {}) => {
    const matched = await CarModel.find(filter);
    return matched.length;
  },

  distinct: async (field) => {
    const values = new Set();
    state.cars.forEach(car => {
      if (field === 'location.city' && car.location?.city) {
        values.add(car.location.city);
      } else if (car[field]) {
        values.add(car[field]);
      }
    });
    return Array.from(values).sort();
  },

  aggregate: async (pipeline) => {
    const counts = {};
    state.cars.filter(c => c.availability).forEach(c => {
      counts[c.category] = (counts[c.category] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([_id, count]) => ({ _id, count }))
      .sort((a, b) => b.count - a.count);
  },

  deleteMany: async () => { state.cars = []; persist(); }
};

// Booking wrapper
const wrapBooking = (b) => {
  if (!b) return null;
  const bookingObj = clone(b);

  bookingObj.populate = async function(field) {
    if (field === 'car' && bookingObj.car) {
      const carId = typeof bookingObj.car === 'object' ? bookingObj.car._id : bookingObj.car;
      const car = state.cars.find(c => c._id.toString() === carId.toString());
      if (car) bookingObj.car = clone(car);
    }
    if (field === 'user' && bookingObj.user) {
      const userId = typeof bookingObj.user === 'object' ? bookingObj.user._id : bookingObj.user;
      const user = state.users.find(u => u._id.toString() === userId.toString());
      if (user) bookingObj.user = wrapUser(user, false);
    }
    return bookingObj;
  };

  bookingObj.save = async function() {
    const idx = state.bookings.findIndex(x => x._id === b._id);
    if (idx !== -1) {
      // Keep referenced ids if populated
      const carId = bookingObj.car?._id || bookingObj.car;
      const userId = bookingObj.user?._id || bookingObj.user;
      state.bookings[idx] = {
        ...state.bookings[idx],
        ...bookingObj,
        car: carId,
        user: userId,
        updatedAt: new Date()
      };
      persist();
    }
    return wrapBooking(state.bookings[idx]);
  };

  return bookingObj;
};

// Booking Model API
const BookingModel = {
  create: async (data) => {
    const newBooking = {
      _id: 'bkg_' + uuidv4().replace(/-/g, '').substring(0, 16),
      user: data.user,
      car: data.car,
      pickupDate: new Date(data.pickupDate),
      dropoffDate: new Date(data.dropoffDate),
      pickupLocation: data.pickupLocation || {},
      dropoffLocation: data.dropoffLocation || data.pickupLocation || {},
      totalHours: data.totalHours,
      pricing: data.pricing || {},
      payment: {
        method: data.payment?.method || 'card',
        status: data.payment?.status || 'pending',
        transactionId: data.payment?.transactionId || '',
        paidAt: data.payment?.paidAt || null
      },
      status: data.status || 'pending',
      extras: data.extras || {},
      cancellationReason: '',
      notes: data.notes || '',
      createdAt: new Date(),
      updatedAt: new Date()
    };

    state.bookings.push(newBooking);
    persist();
    return wrapBooking(newBooking);
  },

  findOne: (filter) => {
    let popFields = [];
    const queryPromise = (async () => {
      const b = state.bookings.find(item => {
        if (filter._id && item._id.toString() !== filter._id.toString()) return false;
        if (filter.user && item.user.toString() !== filter.user.toString()) return false;
        if (filter.car && item.car.toString() !== filter.car.toString()) return false;
        if (filter.status && filter.status.$in) {
          if (!filter.status.$in.includes(item.status)) return false;
        }

        // Overlap date check
        if (filter.$or && filter.$or[0]?.pickupDate) {
          const checkDrop = filter.$or[0].pickupDate.$lte;
          const checkPick = filter.$or[0].dropoffDate.$gte;
          if (new Date(item.pickupDate) <= new Date(checkDrop) && new Date(item.dropoffDate) >= new Date(checkPick)) {
            return true;
          }
          return false;
        }

        return true;
      });

      if (!b) return null;
      const wrapped = wrapBooking(b);
      for (const f of popFields) {
        await wrapped.populate(f);
      }
      return wrapped;
    })();

    queryPromise.populate = function(field) {
      popFields.push(field);
      return queryPromise;
    };

    return queryPromise;
  },

  findById: (id) => {
    let popFields = [];
    const queryPromise = (async () => {
      const b = state.bookings.find(item => item._id.toString() === id.toString());
      if (!b) return null;
      const wrapped = wrapBooking(b);
      for (const f of popFields) {
        await wrapped.populate(f);
      }
      return wrapped;
    })();

    queryPromise.populate = function(field) {
      popFields.push(field);
      return queryPromise;
    };
    return queryPromise;
  },

  find: (filter = {}) => {
    let popFields = [];
    let skipCount = 0;
    let limitCount = 50;
    let sortFn = (a, b) => new Date(b.createdAt) - new Date(a.createdAt);

    const queryPromise = (async () => {
      let list = state.bookings.filter(item => {
        if (filter.user && item.user.toString() !== filter.user.toString()) return false;
        if (filter.status && item.status !== filter.status) return false;
        return true;
      });

      list.sort(sortFn);
      if (skipCount > 0) list = list.slice(skipCount);
      if (limitCount > 0) list = list.slice(0, limitCount);

      const result = [];
      for (const item of list) {
        const wrapped = wrapBooking(item);
        for (const f of popFields) {
          await wrapped.populate(f);
        }
        result.push(wrapped);
      }
      return result;
    })();

    queryPromise.populate = function(field, select) {
      popFields.push(field);
      return queryPromise;
    };

    queryPromise.sort = function(opts) {
      return queryPromise;
    };

    queryPromise.skip = function(n) {
      skipCount = n;
      return queryPromise;
    };

    queryPromise.limit = function(n) {
      limitCount = n;
      return queryPromise;
    };

    return queryPromise;
  },

  countDocuments: async (filter = {}) => {
    return state.bookings.filter(item => {
      if (filter.user && item.user.toString() !== filter.user.toString()) return false;
      if (filter.status && item.status !== filter.status) return false;
      return true;
    }).length;
  },

  deleteMany: async () => { state.bookings = []; persist(); }
};

module.exports = {
  initStore,
  UserModel,
  CarModel,
  BookingModel,
  state
};

require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const Car = require('./models/Car');
const User = require('./models/User');

const cars = [
  {
    name: 'Swift Dzire',
    brand: 'Maruti Suzuki',
    model: 'Dzire VXi',
    year: 2024,
    category: 'sedan',
    transmission: 'manual',
    fuelType: 'petrol',
    seats: 5,
    pricePerHour: 89,
    pricePerDay: 1499,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/dzire-2024-exterior-right-front-three-quarter-2.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/130591/dzire-2024-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['Air Conditioning', 'Power Steering', 'Bluetooth', 'USB Charging', 'Reverse Camera', 'ABS'],
    specifications: {
      engine: '1197 cc',
      mileage: '22.61 kmpl',
      horsepower: '89 bhp',
      topSpeed: '180 km/h',
      acceleration: '11.5s (0-100)',
      bootSpace: '378 L'
    },
    location: { city: 'Mumbai', area: 'Andheri West' },
    rating: 4.6,
    totalTrips: 234,
    registrationNumber: 'MH-01-AB-1234',
    color: 'Pearl White',
    description: 'The all-new Dzire is perfect for city commutes and highway trips. Fuel efficient and comfortable.'
  },
  {
    name: 'Hyundai Creta',
    brand: 'Hyundai',
    model: 'Creta SX(O)',
    year: 2024,
    category: 'suv',
    transmission: 'automatic',
    fuelType: 'petrol',
    seats: 5,
    pricePerHour: 149,
    pricePerDay: 2499,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/106815/creta-exterior-right-front-three-quarter-5.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/106815/creta-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['Panoramic Sunroof', 'Ventilated Seats', 'ADAS', 'Wireless Charging', 'Bose Sound System', 'Connected Car Tech', '360° Camera'],
    specifications: {
      engine: '1482 cc',
      mileage: '17.4 kmpl',
      horsepower: '113 bhp',
      topSpeed: '195 km/h',
      acceleration: '11.8s (0-100)',
      bootSpace: '433 L'
    },
    location: { city: 'Mumbai', area: 'Bandra' },
    rating: 4.8,
    totalTrips: 412,
    registrationNumber: 'MH-02-CD-5678',
    color: 'Abyss Black',
    description: 'India\'s most loved SUV with premium features, ADAS technology, and commanding road presence.'
  },
  {
    name: 'Toyota Fortuner',
    brand: 'Toyota',
    model: 'Fortuner Legender',
    year: 2024,
    category: 'suv',
    transmission: 'automatic',
    fuelType: 'diesel',
    seats: 7,
    pricePerHour: 299,
    pricePerDay: 4999,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/44709/fortuner-exterior-right-front-three-quarter-19.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/44709/fortuner-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['4WD', 'Leather Seats', 'JBL Sound System', 'Kick Sensor Tailgate', 'Cooled Seats', 'Cruise Control', 'Hill Assist'],
    specifications: {
      engine: '2755 cc',
      mileage: '10.1 kmpl',
      horsepower: '201 bhp',
      topSpeed: '200 km/h',
      acceleration: '10.0s (0-100)',
      bootSpace: '296 L'
    },
    location: { city: 'Delhi', area: 'Connaught Place' },
    rating: 4.9,
    totalTrips: 189,
    registrationNumber: 'DL-03-EF-9012',
    color: 'Phantom Brown',
    description: 'The undisputed king of SUVs. Dominate any terrain with the powerful Fortuner Legender.'
  },
  {
    name: 'BMW 3 Series',
    brand: 'BMW',
    model: '320d M Sport',
    year: 2024,
    category: 'luxury',
    transmission: 'automatic',
    fuelType: 'diesel',
    seats: 5,
    pricePerHour: 449,
    pricePerDay: 7499,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/153591/3-series-exterior-right-front-three-quarter-2.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/153591/3-series-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['M Sport Package', 'Ambient Lighting', 'Harman Kardon', 'Gesture Control', 'Wireless CarPlay', 'Head-Up Display', 'Adaptive Suspension'],
    specifications: {
      engine: '1995 cc',
      mileage: '19.36 kmpl',
      horsepower: '188 bhp',
      topSpeed: '235 km/h',
      acceleration: '7.3s (0-100)',
      bootSpace: '480 L'
    },
    location: { city: 'Bangalore', area: 'MG Road' },
    rating: 4.9,
    totalTrips: 98,
    registrationNumber: 'KA-04-GH-3456',
    color: 'Alpine White',
    description: 'Sheer driving pleasure. The BMW 3 Series sets the benchmark for luxury sport sedans.'
  },
  {
    name: 'Tata Nexon EV',
    brand: 'Tata',
    model: 'Nexon EV Max LR',
    year: 2024,
    category: 'electric',
    transmission: 'automatic',
    fuelType: 'electric',
    seats: 5,
    pricePerHour: 129,
    pricePerDay: 1999,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/141867/nexon-ev-exterior-right-front-three-quarter-5.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/141867/nexon-ev-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['40.5 kWh Battery', 'Fast Charging', 'Connected Car', 'Air Purifier', 'Sunroof', 'Ventilated Seats', 'ZConnect App'],
    specifications: {
      engine: 'Electric Motor',
      mileage: '437 km range',
      horsepower: '141 bhp',
      topSpeed: '140 km/h',
      acceleration: '9.0s (0-100)',
      bootSpace: '350 L'
    },
    location: { city: 'Bangalore', area: 'Koramangala' },
    rating: 4.7,
    totalTrips: 156,
    registrationNumber: 'KA-05-IJ-7890',
    color: 'Pristine White',
    description: 'Go electric with India\'s bestselling EV. Zero emissions, maximum fun.'
  },
  {
    name: 'Mahindra Thar',
    brand: 'Mahindra',
    model: 'Thar LX Hard Top',
    year: 2024,
    category: 'suv',
    transmission: 'automatic',
    fuelType: 'diesel',
    seats: 4,
    pricePerHour: 199,
    pricePerDay: 3299,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/40087/thar-exterior-right-front-three-quarter-49.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/40087/thar-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['4x4', 'Washable Interior', 'Touchscreen Infotainment', 'Cruise Control', 'Adventure Ready', 'Roll Cage'],
    specifications: {
      engine: '2184 cc',
      mileage: '11.5 kmpl',
      horsepower: '128 bhp',
      topSpeed: '155 km/h',
      acceleration: '13.5s (0-100)',
      bootSpace: '—'
    },
    location: { city: 'Pune', area: 'Hinjawadi' },
    rating: 4.8,
    totalTrips: 287,
    registrationNumber: 'MH-12-KL-1234',
    color: 'Napoli Black',
    description: 'Born to be wild. The Thar is your ticket to off-road adventures and weekend getaways.'
  },
  {
    name: 'Honda City',
    brand: 'Honda',
    model: 'City ZX CVT',
    year: 2024,
    category: 'sedan',
    transmission: 'automatic',
    fuelType: 'petrol',
    seats: 5,
    pricePerHour: 119,
    pricePerDay: 1899,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/134287/city-exterior-right-front-three-quarter-2.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/134287/city-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['Lane Watch Camera', 'Honda Connect', 'LED Headlamps', 'Sunroof', 'Alexa Remote', 'Paddle Shifters'],
    specifications: {
      engine: '1498 cc',
      mileage: '18.4 kmpl',
      horsepower: '119 bhp',
      topSpeed: '195 km/h',
      acceleration: '10.5s (0-100)',
      bootSpace: '506 L'
    },
    location: { city: 'Delhi', area: 'Dwarka' },
    rating: 4.5,
    totalTrips: 198,
    registrationNumber: 'DL-06-MN-5678',
    color: 'Radiant Red',
    description: 'The sophisticated Honda City delivers a refined driving experience with best-in-class boot space.'
  },
  {
    name: 'Mercedes-Benz GLC',
    brand: 'Mercedes-Benz',
    model: 'GLC 300 4MATIC',
    year: 2024,
    category: 'luxury',
    transmission: 'automatic',
    fuelType: 'petrol',
    seats: 5,
    pricePerHour: 599,
    pricePerDay: 9999,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/144681/glc-exterior-right-front-three-quarter-2.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/144681/glc-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['MBUX Infotainment', 'Burmester Sound', 'Air Suspension', 'Panoramic Roof', '64-Color Ambient Lighting', 'Heated & Cooled Seats', 'Wireless Charging'],
    specifications: {
      engine: '1999 cc',
      mileage: '12.56 kmpl',
      horsepower: '255 bhp',
      topSpeed: '240 km/h',
      acceleration: '6.2s (0-100)',
      bootSpace: '550 L'
    },
    location: { city: 'Mumbai', area: 'Worli' },
    rating: 4.9,
    totalTrips: 67,
    registrationNumber: 'MH-07-OP-9012',
    color: 'Obsidian Black',
    description: 'The pinnacle of luxury SUVs. Experience the Star with the all-new GLC.'
  },
  {
    name: 'Kia Seltos',
    brand: 'Kia',
    model: 'Seltos HTX+',
    year: 2024,
    category: 'suv',
    transmission: 'automatic',
    fuelType: 'petrol',
    seats: 5,
    pricePerHour: 139,
    pricePerDay: 2199,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/174323/seltos-exterior-right-front-three-quarter.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/174323/seltos-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['10.25" Touchscreen', 'Bose Premium Sound', 'Ventilated Seats', 'Sunroof', 'ADAS Level 2', 'Digital Key'],
    specifications: {
      engine: '1497 cc',
      mileage: '16.8 kmpl',
      horsepower: '138 bhp',
      topSpeed: '190 km/h',
      acceleration: '11.2s (0-100)',
      bootSpace: '433 L'
    },
    location: { city: 'Hyderabad', area: 'HITEC City' },
    rating: 4.6,
    totalTrips: 312,
    registrationNumber: 'TS-08-QR-3456',
    color: 'Gravity Grey',
    description: 'The badass SUV with premium tech, bold design, and unmatched road presence.'
  },
  {
    name: 'Maruti Baleno',
    brand: 'Maruti Suzuki',
    model: 'Baleno Alpha AMT',
    year: 2024,
    category: 'hatchback',
    transmission: 'automatic',
    fuelType: 'petrol',
    seats: 5,
    pricePerHour: 69,
    pricePerDay: 1099,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/159099/baleno-exterior-right-front-three-quarter.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/159099/baleno-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['9" SmartPlay Pro+', 'Head-Up Display', '360° Camera', 'Alexa Built-in', 'Suzuki Connect', 'LED Projector Headlamps'],
    specifications: {
      engine: '1197 cc',
      mileage: '22.35 kmpl',
      horsepower: '89 bhp',
      topSpeed: '180 km/h',
      acceleration: '12.0s (0-100)',
      bootSpace: '318 L'
    },
    location: { city: 'Chennai', area: 'T. Nagar' },
    rating: 4.4,
    totalTrips: 467,
    registrationNumber: 'TN-09-ST-7890',
    color: 'Celestial Blue',
    description: 'Premium hatchback with bold design and loaded features. Perfect for daily commuting.'
  },
  {
    name: 'Tata Harrier',
    brand: 'Tata',
    model: 'Harrier XZA+ Dark',
    year: 2024,
    category: 'suv',
    transmission: 'automatic',
    fuelType: 'diesel',
    seats: 5,
    pricePerHour: 179,
    pricePerDay: 2899,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/139651/harrier-facelift-exterior-right-front-three-quarter.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/139651/harrier-facelift-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['ADAS', 'Panoramic Sunroof', 'JBL Sound (9 Speakers)', 'Ventilated Seats', 'Air Purifier', '360° Camera', 'Digital Cockpit'],
    specifications: {
      engine: '1956 cc',
      mileage: '14.6 kmpl',
      horsepower: '168 bhp',
      topSpeed: '190 km/h',
      acceleration: '10.8s (0-100)',
      bootSpace: '425 L'
    },
    location: { city: 'Pune', area: 'Kothrud' },
    rating: 4.7,
    totalTrips: 201,
    registrationNumber: 'MH-14-UV-1234',
    color: 'Daytona Grey',
    description: 'The Dark Edition Harrier turns heads everywhere. Built on OMEGARC architecture for ultimate stability.'
  },
  {
    name: 'Volkswagen Virtus',
    brand: 'Volkswagen',
    model: 'Virtus GT Plus',
    year: 2024,
    category: 'sedan',
    transmission: 'automatic',
    fuelType: 'petrol',
    seats: 5,
    pricePerHour: 129,
    pricePerDay: 2099,
    images: [
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/144681/virtus-exterior-right-front-three-quarter.jpeg',
      'https://imgd.aeplcdn.com/664x374/n/cw/ec/144681/virtus-exterior-right-rear-three-quarter.jpeg'
    ],
    features: ['Turbo TSI Engine', 'Ventilated Seats', 'Wireless CarPlay', 'Sunroof', 'Connected Car Tech', 'Digital Cockpit', 'Ambient Lighting'],
    specifications: {
      engine: '1498 cc TSI',
      mileage: '18.67 kmpl',
      horsepower: '148 bhp',
      topSpeed: '212 km/h',
      acceleration: '8.9s (0-100)',
      bootSpace: '521 L'
    },
    location: { city: 'Hyderabad', area: 'Madhapur' },
    rating: 4.6,
    totalTrips: 145,
    registrationNumber: 'TS-10-WX-5678',
    color: 'Curcuma Yellow',
    description: 'German engineering meets Indian roads. The GT Plus is a driver\'s delight with its powerful TSI engine.'
  }
];

const seedDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    // Clear existing data
    await Car.deleteMany({});
    await User.deleteMany({});
    console.log('Cleared existing data');

    // Create admin user
    const admin = await User.create({
      firstName: 'Admin',
      lastName: 'DriveEase',
      email: 'admin@driveease.com',
      phone: '9999999999',
      password: 'admin123',
      role: 'admin',
      isVerified: true
    });
    console.log('Admin user created: admin@driveease.com / admin123');

    // Create demo user
    const demoUser = await User.create({
      firstName: 'Ankul',
      lastName: 'Demo',
      email: 'ankul@demo.com',
      phone: '9876543210',
      password: 'demo1234',
      role: 'user',
      isVerified: true
    });
    console.log('Demo user created: ankul@demo.com / demo1234');

    // Insert cars
    await Car.insertMany(cars);
    console.log(`${cars.length} cars seeded successfully`);

    console.log('\n✓ Database seeded successfully!');
    process.exit(0);
  } catch (err) {
    console.error('Seed error:', err);
    process.exit(1);
  }
};

seedDB();

const nodemailer = require('nodemailer');

let transporter = null;
let testAccount = null;
let usingGmail = false;
const emailLog = [];

// Initialize mail transporter
const initMailer = async () => {
  if (transporter) return transporter;

  // Option 1: Gmail SMTP — set SMTP_USER=your.email@gmail.com and SMTP_PASS=your_app_password
  if (process.env.SMTP_USER && process.env.SMTP_PASS) {
    const isGmail = process.env.SMTP_USER.includes('@gmail.com');
    transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST || (isGmail ? 'smtp.gmail.com' : 'smtp.ethereal.email'),
      port: parseInt(process.env.SMTP_PORT || (isGmail ? '465' : '587')),
      secure: isGmail ? true : process.env.SMTP_SECURE === 'true',
      auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS
      },
      connectionTimeout: 4000,
      greetingTimeout: 3000,
      socketTimeout: 5000
    });
    usingGmail = isGmail;
    console.log(`✓ ${isGmail ? 'Gmail' : 'Custom'} SMTP mailer configured (${process.env.SMTP_USER})`);
    return transporter;
  }

  // Option 2: Instant zero-latency simulator (Prevents port 587 network timeouts)
  console.log(`✓ DriveEase Local Mail Dispatcher active (Zero-latency instant mode)`);
  console.log(`  ℹ️ OTPs and emails appear instantly in the console log & UI.`);
  console.log(`  ℹ️ For real Gmail delivery, add SMTP_USER & SMTP_PASS to backend/.env`);
  transporter = {
    sendMail: async (opts) => {
      return {
        messageId: 'local_' + Date.now(),
        mock: true
      };
    }
  };

  return transporter;
};

// Helper: get the actual send-to address (Gmail sends to itself if configured)
const getRecipient = (targetEmail) => {
  if (usingGmail && process.env.SMTP_USER) {
    return process.env.SMTP_USER; // Gmail sends to your own inbox
  }
  return targetEmail;
};

// Generate HTML email content
const generateBookingEmailHtml = ({ booking, car, user }) => {
  const pickupDateFormatted = new Date(booking.pickupDate).toLocaleString('en-IN', {
    weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });
  const dropoffDateFormatted = new Date(booking.dropoffDate).toLocaleString('en-IN', {
    weekday: 'short', day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  const bookingRef = (booking._id || 'DE-' + Date.now()).toString().slice(-8).toUpperCase();
  const unlockPin = Math.floor(1000 + Math.random() * 9000);

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Booking Confirmation - DriveEase</title>
  <style>
    body { margin: 0; padding: 0; background-color: #0b0c10; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f0f0f5; }
    .email-container { max-width: 600px; margin: 20px auto; background-color: #14151f; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; overflow: hidden; box-shadow: 0 10px 40px rgba(0,0,0,0.5); }
    .header { background: linear-gradient(135deg, #181926 0%, #0d0e15 100%); padding: 32px 30px; text-align: center; border-bottom: 1px solid rgba(255,255,255,0.06); }
    .logo { font-size: 26px; font-weight: 800; color: #ffffff; letter-spacing: -0.5px; text-decoration: none; }
    .logo span { color: #c8ff00; }
    .badge-confirmed { display: inline-block; background: rgba(200,255,0,0.15); border: 1px solid #c8ff00; color: #c8ff00; font-size: 12px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; padding: 6px 14px; border-radius: 20px; margin-top: 14px; }
    .content { padding: 30px; }
    .greeting { font-size: 18px; font-weight: 600; margin-bottom: 8px; color: #ffffff; }
    .message { font-size: 14px; color: #9a9ab0; line-height: 1.6; margin-bottom: 24px; }
    .car-card { background: #1c1d2c; border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 20px; margin-bottom: 24px; }
    .car-img { width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 14px; background: #000; }
    .car-title { font-size: 20px; font-weight: 700; color: #ffffff; margin: 0 0 6px 0; }
    .car-meta { font-size: 13px; color: #c8ff00; font-weight: 500; text-transform: uppercase; letter-spacing: 0.5px; }
    .itinerary { display: table; width: 100%; margin-top: 16px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 16px; }
    .itinerary-row { display: table-row; }
    .itinerary-cell { display: table-cell; padding: 6px 0; font-size: 13px; color: #9a9ab0; }
    .itinerary-cell.val { text-align: right; color: #ffffff; font-weight: 500; }
    .pin-box { background: linear-gradient(135deg, rgba(200,255,0,0.12), rgba(0,240,255,0.08)); border: 1px dashed #c8ff00; border-radius: 12px; padding: 18px; text-align: center; margin: 24px 0; }
    .pin-label { font-size: 12px; text-transform: uppercase; color: #9a9ab0; letter-spacing: 1px; }
    .pin-code { font-size: 28px; font-weight: 800; color: #c8ff00; letter-spacing: 6px; font-family: monospace; margin-top: 4px; }
    .price-table { width: 100%; border-collapse: collapse; margin-top: 16px; }
    .price-table td { padding: 8px 0; font-size: 13px; color: #9a9ab0; border-bottom: 1px solid rgba(255,255,255,0.04); }
    .price-table td.val { text-align: right; color: #ffffff; }
    .price-table tr.total td { font-size: 16px; font-weight: 700; color: #c8ff00; border-bottom: none; padding-top: 12px; }
    .footer { background: #0e0f16; padding: 24px 30px; text-align: center; font-size: 12px; color: #6d6d82; border-top: 1px solid rgba(255,255,255,0.04); }
    .footer a { color: #c8ff00; text-decoration: none; }
  </style>
</head>
<body>
  <div class="email-container">
    <div class="header">
      <div class="logo">Drive<span>Ease</span></div>
      <div><span class="badge-confirmed">✓ Booking Confirmed</span></div>
      <div style="font-size: 12px; color: #9a9ab0; margin-top: 10px;">Ref: #${bookingRef}</div>
    </div>

    <div class="content">
      <div class="greeting">Hello ${user?.firstName || 'Valued Guest'},</div>
      <div class="message">
        Your car reservation is officially confirmed and ready! All safety inspections have been passed and your vehicle will be prepared for immediate pickup.
      </div>

      <div class="car-card">
        ${car?.images && car.images[0] ? `<img src="${car.images[0]}" alt="${car.name}" class="car-img" />` : ''}
        <div class="car-title">${car?.name || 'Selected Vehicle'}</div>
        <div class="car-meta">${car?.brand || ''} • ${car?.category || 'Premium'} • ${car?.transmission || 'Automatic'} • ${car?.fuelType || 'Petrol'}</div>

        <div class="itinerary">
          <div class="itinerary-row">
            <div class="itinerary-cell">Pickup Date & Time</div>
            <div class="itinerary-cell val">${pickupDateFormatted}</div>
          </div>
          <div class="itinerary-row">
            <div class="itinerary-cell">Drop-off Date & Time</div>
            <div class="itinerary-cell val">${dropoffDateFormatted}</div>
          </div>
          <div class="itinerary-row">
            <div class="itinerary-cell">Pickup Hub / Area</div>
            <div class="itinerary-cell val">${booking.pickupLocation?.address || car?.location?.area || 'Hub'}, ${booking.pickupLocation?.city || car?.location?.city || 'City'}</div>
          </div>
          <div class="itinerary-row">
            <div class="itinerary-cell">Plate Number</div>
            <div class="itinerary-cell val">${car?.registrationNumber || 'Assigned on Delivery'}</div>
          </div>
        </div>
      </div>

      <div class="pin-box">
        <div class="pin-label">Smart Digital Key Unlock PIN</div>
        <div class="pin-code">${unlockPin}</div>
        <div style="font-size: 11px; color: #9a9ab0; margin-top: 6px;">Use this 4-digit PIN in your DriveEase app or tell your concierge for keyless entry</div>
      </div>

      <div style="font-weight: 600; font-size: 14px; margin-bottom: 8px; color: #ffffff;">Fare & Payment Breakdown</div>
      <table class="price-table">
        <tr>
          <td>Base Rental Fare</td>
          <td class="val">₹${booking.pricing?.basePrice?.toLocaleString('en-IN') || 0}</td>
        </tr>
        <tr>
          <td>Comprehensive Protection & Insurance</td>
          <td class="val">₹${booking.pricing?.insuranceFee?.toLocaleString('en-IN') || 0}</td>
        </tr>
        <tr>
          <td>Platform & Tech Service Fee (5%)</td>
          <td class="val">₹${booking.pricing?.serviceFee?.toLocaleString('en-IN') || 0}</td>
        </tr>
        <tr>
          <td>GST (18% Govt. Tax)</td>
          <td class="val">₹${booking.pricing?.gst?.toLocaleString('en-IN') || 0}</td>
        </tr>
        <tr class="total">
          <td>Total Paid (Transaction: ${booking.payment?.transactionId || 'PAID'})</td>
          <td class="val">₹${booking.pricing?.totalAmount?.toLocaleString('en-IN') || 0}</td>
        </tr>
      </table>
    </div>

    <div class="footer">
      <p style="margin: 0 0 8px 0;">Need immediate assistance or trip amendments?</p>
      <p style="margin: 0 0 12px 0;">Call our 24/7 Concierge Hotline: <strong style="color: #c8ff00;">1800-DRIVE-EASE</strong> or email <a href="mailto:support@driveease.com">support@driveease.com</a></p>
      <p style="margin: 0; font-size: 11px;">DriveEase Mobility Technologies Pvt. Ltd. • Hackathon Edition 2026</p>
    </div>
  </div>
</body>
</html>
  `;
};

// Send OTP verification email & simulate SMS
const sendOtpNotification = async ({ user, car, bookingId, otpCode }) => {
  try {
    const mailer = await initMailer();
    const toEmail = user?.email || 'ankul@demo.com';
    const toPhone = user?.phone || '9876543210';
    const otp = otpCode || Math.floor(100000 + Math.random() * 900000).toString();

    console.log(`\n📲 ================================================`);
    console.log(`📲 [DriveEase SMS Gateway] Dispatched SMS to +91-${toPhone}`);
    console.log(`📲 OTP: ${otp} for vehicle reservation #${(bookingId || '').toString().slice(-6).toUpperCase()}`);
    console.log(`📲 ================================================\n`);

    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Security Verification OTP - DriveEase</title>
  <style>
    body { margin: 0; padding: 0; background-color: #0b0c10; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #f0f0f5; }
    .container { max-width: 500px; margin: 24px auto; background-color: #14151f; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 32px; text-align: center; }
    .logo { font-size: 24px; font-weight: 800; color: #ffffff; }
    .logo span { color: #c8ff00; }
    .otp-box { background: rgba(200,255,0,0.1); border: 2px dashed #c8ff00; border-radius: 12px; padding: 20px; margin: 24px 0; }
    .otp-code { font-size: 38px; font-weight: 800; color: #c8ff00; letter-spacing: 8px; font-family: monospace; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo">Drive<span>Ease</span></div>
    <h2 style="color: #ffffff; margin-top: 20px;">Verification One-Time Password (OTP)</h2>
    <p style="color: #9a9ab0; font-size: 14px; line-height: 1.5;">
      Hello ${user?.firstName || 'Driver'}, use the following one-time password to verify your booking for <strong>${car?.name || 'your car'}</strong>.
    </p>

    <div class="otp-box">
      <div style="font-size: 11px; text-transform: uppercase; color: #9a9ab0; letter-spacing: 1px; margin-bottom: 6px;">Your 6-Digit OTP</div>
      <div class="otp-code">${otp}</div>
      <div style="font-size: 11px; color: #9a9ab0; margin-top: 8px;">Valid for 10 minutes. Do not share with anyone.</div>
    </div>

    <p style="font-size: 12px; color: #6d6d82;">
      Also dispatched via SMS to <strong>+91-XXXXX${toPhone.slice(-4)}</strong>.
    </p>
  </div>
</body>
</html>
    `;

    const actualRecipient = getRecipient(toEmail);
    const fromAddress = usingGmail
      ? `"DriveEase Security" <${process.env.SMTP_USER}>`
      : '"DriveEase Security" <no-reply@driveease.com>';

    const mailOptions = {
      from: fromAddress,
      to: actualRecipient,
      subject: `🔐 Your DriveEase Booking OTP: ${otp}`,
      html: htmlContent
    };

    const info = await mailer.sendMail(mailOptions);
    let previewUrl = null;

    if (usingGmail) {
      console.log(`✉️ [OTP Email Sent] Real email sent to ${actualRecipient}`);
    } else if (info && !info.mock) {
      previewUrl = nodemailer.getTestMessageUrl(info);
      if (previewUrl) {
        console.log(`✉️ [OTP Email Sent] Preview live OTP email: ${previewUrl}`);
      }
    }

    return {
      success: true,
      otp,
      phone: toPhone,
      email: toEmail,
      previewUrl
    };
  } catch (err) {
    console.error('Failed to send OTP notification:', err);
    return {
      success: false,
      error: err.message
    };
  }
};

// Send booking confirmation email
const sendBookingConfirmation = async ({ booking, car, user, recipientEmail }) => {
  try {
    const mailer = await initMailer();
    const toEmail = recipientEmail || user?.email || 'ankul@demo.com';
    const actualRecipient = getRecipient(toEmail);
    const htmlContent = generateBookingEmailHtml({ booking, car, user });

    const fromAddress = usingGmail
      ? `"DriveEase Rentals" <${process.env.SMTP_USER}>`
      : '"DriveEase Rentals" <no-reply@driveease.com>';

    const mailOptions = {
      from: fromAddress,
      to: actualRecipient,
      subject: `🚘 Booking Confirmed: ${car?.name || 'Your Car'} [Ref #${(booking._id || '').toString().slice(-6).toUpperCase()}]`,
      html: htmlContent
    };

    const info = await mailer.sendMail(mailOptions);
    let previewUrl = null;

    if (usingGmail) {
      console.log(`✉️ [Booking Email Sent] Real email sent to ${actualRecipient}`);
    } else if (info && !info.mock) {
      previewUrl = nodemailer.getTestMessageUrl(info);
      if (previewUrl) {
        console.log(`✉️ [Email Sent] Preview live rendered email: ${previewUrl}`);
      }
    }

    const logEntry = {
      id: 'em_' + Date.now(),
      bookingId: booking._id,
      to: toEmail,
      subject: mailOptions.subject,
      previewUrl: previewUrl || null,
      html: htmlContent,
      sentAt: new Date(),
      status: 'delivered'
    };

    emailLog.unshift(logEntry);
    if (emailLog.length > 50) emailLog.pop();

    return {
      success: true,
      previewUrl,
      messageId: info?.messageId,
      recipient: toEmail,
      html: htmlContent
    };
  } catch (err) {
    console.error('Failed to send booking email:', err.message);
    return {
      success: false,
      error: err.message
    };
  }
};

// Send Login OTP email
const sendLoginOtpEmail = async ({ email, otpCode }) => {
  try {
    const mailer = await initMailer();
    const toEmail = (email || 'user@example.com').toLowerCase().trim();
    const otp = otpCode || Math.floor(100000 + Math.random() * 900000).toString();

    console.log(`\n🔑 ================================================`);
    console.log(`🔑 [DriveEase Login OTP] Target: ${toEmail}`);
    console.log(`🔑 Verification Code: ${otp}`);
    console.log(`🔑 ================================================\n`);

    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Your Sign-In OTP - DriveEase</title>
  <style>
    body { margin: 0; padding: 0; background-color: #0b0c10; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #f0f0f5; }
    .container { max-width: 480px; margin: 30px auto; background-color: #14151f; border: 1px solid rgba(255,255,255,0.08); border-radius: 16px; padding: 36px 28px; text-align: center; }
    .logo { font-size: 26px; font-weight: 800; color: #ffffff; letter-spacing: -0.5px; }
    .logo span { color: #c8ff00; }
    .tagline { font-size: 11px; text-transform: uppercase; letter-spacing: 2px; color: #71717a; margin-top: 4px; }
    .otp-box { background: rgba(200,255,0,0.08); border: 2px dashed #c8ff00; border-radius: 14px; padding: 24px 20px; margin: 26px 0; }
    .otp-label { font-size: 12px; text-transform: uppercase; color: #9a9ab0; letter-spacing: 1.5px; font-weight: 600; margin-bottom: 8px; }
    .otp-code { font-size: 42px; font-weight: 800; color: #c8ff00; letter-spacing: 10px; font-family: monospace; }
    .info { font-size: 13px; color: #a1a1aa; line-height: 1.6; margin: 18px 0; }
    .footer { font-size: 11px; color: #52525b; margin-top: 28px; border-top: 1px solid rgba(255,255,255,0.06); padding-top: 16px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo">Drive<span>Ease</span></div>
    <div class="tagline">CAR RENTALS & MOBILITY</div>
    
    <h2 style="color: #ffffff; font-size: 20px; margin-top: 24px; font-weight: 700;">Sign-In Verification Code</h2>
    <p class="info">
      Use this one-time security code to log in to your DriveEase account:
    </p>

    <div class="otp-box">
      <div class="otp-label">Your 6-Digit OTP</div>
      <div class="otp-code">${otp}</div>
      <div style="font-size: 11px; color: #71717a; margin-top: 10px;">Valid for 10 minutes • Never share your OTP</div>
    </div>

    <p style="font-size: 12px; color: #71717a;">
      If you did not request this login code, you can safely ignore this email.
    </p>

    <div class="footer">
      DriveEase Mobility Technologies • Safe & Secure Self-Drive Rentals
    </div>
  </div>
</body>
</html>
    `;

    const actualRecipient = getRecipient(toEmail);
    const fromAddress = usingGmail
      ? `"DriveEase Security" <${process.env.SMTP_USER}>`
      : '"DriveEase Security" <no-reply@driveease.com>';

    const mailOptions = {
      from: fromAddress,
      to: actualRecipient,
      subject: `🔑 ${otp} is your DriveEase login code`,
      html: htmlContent
    };

    const info = await mailer.sendMail(mailOptions);
    let previewUrl = null;

    if (usingGmail) {
      console.log(`✉️ [Login OTP Sent] Real email sent to ${actualRecipient}`);
    } else if (info && !info.mock) {
      previewUrl = nodemailer.getTestMessageUrl(info);
      if (previewUrl) {
        console.log(`✉️ [Login OTP Sent] Preview live OTP email: ${previewUrl}`);
      }
    }

    return {
      success: true,
      otp,
      email: toEmail,
      previewUrl
    };
  } catch (err) {
    console.error('Failed to send login OTP email:', err);
    return {
      success: false,
      error: err.message,
      otp: otpCode
    };
  }
};

const getEmailForBooking = (bookingId) => {
  return emailLog.find(e => e.bookingId && e.bookingId.toString() === bookingId.toString());
};

const getAllSentEmails = () => emailLog;

module.exports = {
  sendBookingConfirmation,
  sendOtpNotification,
  sendLoginOtpEmail,
  getEmailForBooking,
  getAllSentEmails,
  generateBookingEmailHtml
};

const mongoose = require('mongoose');
const { isMongoActive } = require('../db/connection');
const { BookingModel } = require('../db/store');

const bookingSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  car: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Car',
    required: true
  },
  pickupDate: {
    type: Date,
    required: [true, 'Pickup date is required']
  },
  dropoffDate: {
    type: Date,
    required: [true, 'Dropoff date is required']
  },
  pickupLocation: {
    address: String,
    city: String,
    lat: Number,
    lng: Number
  },
  dropoffLocation: {
    address: String,
    city: String,
    lat: Number,
    lng: Number
  },
  totalHours: {
    type: Number,
    required: true
  },
  pricing: {
    basePrice: { type: Number, required: true },
    serviceFee: { type: Number, default: 0 },
    insuranceFee: { type: Number, default: 0 },
    gst: { type: Number, default: 0 },
    discount: { type: Number, default: 0 },
    totalAmount: { type: Number, required: true }
  },
  payment: {
    method: {
      type: String,
      enum: ['card', 'upi', 'netbanking', 'wallet'],
      default: 'card'
    },
    transactionId: String,
    status: {
      type: String,
      enum: ['pending', 'completed', 'failed', 'refunded'],
      default: 'pending'
    },
    paidAt: Date
  },
  status: {
    type: String,
    enum: ['pending', 'confirmed', 'active', 'completed', 'cancelled'],
    default: 'pending'
  },
  extras: {
    insurance: { type: Boolean, default: false },
    gps: { type: Boolean, default: false },
    childSeat: { type: Boolean, default: false },
    additionalDriver: { type: Boolean, default: false }
  },
  emailPreviewUrl: {
    type: String,
    default: ''
  },
  emailSent: {
    type: Boolean,
    default: false
  },
  cancellationReason: String,
  notes: String
}, { timestamps: true });

bookingSchema.index({ user: 1, status: 1 });
bookingSchema.index({ car: 1, pickupDate: 1, dropoffDate: 1 });

const MongooseBooking = mongoose.models.Booking || mongoose.model('Booking', bookingSchema);

const BookingProxy = new Proxy(MongooseBooking, {
  get(target, prop) {
    if (!isMongoActive() && prop in BookingModel) {
      return BookingModel[prop];
    }
    return target[prop];
  }
});

module.exports = BookingProxy;

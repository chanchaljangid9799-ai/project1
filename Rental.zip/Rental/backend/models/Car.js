const mongoose = require('mongoose');
const { isMongoActive } = require('../db/connection');
const { CarModel } = require('../db/store');

const carSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Car name is required'],
    trim: true
  },
  brand: {
    type: String,
    required: [true, 'Brand is required'],
    trim: true
  },
  model: {
    type: String,
    required: true
  },
  year: {
    type: Number,
    required: true
  },
  category: {
    type: String,
    enum: ['sedan', 'suv', 'hatchback', 'luxury', 'convertible', 'minivan', 'sports', 'electric'],
    required: true
  },
  transmission: {
    type: String,
    enum: ['automatic', 'manual'],
    required: true
  },
  fuelType: {
    type: String,
    enum: ['petrol', 'diesel', 'electric', 'hybrid'],
    required: true
  },
  seats: {
    type: Number,
    required: true,
    min: 2,
    max: 9
  },
  pricePerHour: {
    type: Number,
    required: true
  },
  pricePerDay: {
    type: Number,
    required: true
  },
  images: [{
    type: String
  }],
  features: [{
    type: String
  }],
  specifications: {
    engine: String,
    mileage: String,
    horsepower: String,
    topSpeed: String,
    acceleration: String,
    bootSpace: String
  },
  location: {
    city: { type: String, required: true },
    area: { type: String },
    lat: Number,
    lng: Number
  },
  availability: {
    type: Boolean,
    default: true
  },
  rating: {
    type: Number,
    default: 4.5,
    min: 0,
    max: 5
  },
  totalTrips: {
    type: Number,
    default: 0
  },
  registrationNumber: {
    type: String,
    required: true,
    unique: true
  },
  color: {
    type: String,
    required: true
  },
  description: {
    type: String,
    default: ''
  }
}, { timestamps: true });

carSchema.index({ category: 1, availability: 1 });
carSchema.index({ 'location.city': 1 });
carSchema.index({ pricePerDay: 1 });

const MongooseCar = mongoose.models.Car || mongoose.model('Car', carSchema);

const CarProxy = new Proxy(MongooseCar, {
  get(target, prop) {
    if (!isMongoActive() && prop in CarModel) {
      return CarModel[prop];
    }
    return target[prop];
  }
});

module.exports = CarProxy;

# 🚗 DriveEase — Self-Drive Car Rental Mobility Platform

> **Hackathon Edition — Fully Self-Contained, Zero-Config Setup**

DriveEase is a modern full-stack mobility web application for on-demand self-drive car rentals with keyless smart telematics entry, live trip tracking, digital tax invoices, and OTP verification.

---

## ⚡ Quick Start (1-Click Run)

**Do not open `frontend/index.html` in the browser.** That file is for the build tool. Opening it directly looks blank / broken.

1. Double-click the **root** `index.html` (this folder) for a start screen, **or**
2. Double-click `start.sh` (Mac/Linux) or `start.bat` (Windows)
3. The app opens at **[http://localhost:5001](http://localhost:5001)** — keep the terminal window open

Need Node.js from [nodejs.org](https://nodejs.org) first.

```bash
./start.sh          # macOS / Linux
start.bat           # Windows
npm start           # after Node is installed
```

---

## 🔑 Demo Login Accounts

Quick 1-click login buttons are available right on the Sign-In page:

| Role | Email | Password | Access |
|---|---|---|---|
| **Demo User** | `ankul@demo.com` | `demo1234` | Browse cars, book trips, view invoice, digital keys |
| **Admin** | `admin@driveease.com` | `admin123` | Fleet management, booking approvals, telemetry |

---

## 📬 Email & OTP Verification Guide

DriveEase supports two modes for OTP and reservation confirmation emails:

### Mode 1: Instant Local Hackathon Mode (Default — Zero Config)
- Works immediately out-of-the-box without entering any email credentials.
- When you request an OTP during login or reservation:
  - The OTP code is logged directly to the terminal console: `🔑 Verification Code: XXXXXX`
  - A test preview link is provided via Ethereal Mail.
  - Quick bypass code: **`123456`** also works for instant judging evaluation!

### Mode 2: Real Gmail Inbox Delivery (Optional)
If you want real OTP codes and booking confirmations delivered to your actual Gmail inbox:
1. Go to your Google Account: [https://myaccount.google.com/apppasswords](https://myaccount.google.com/apppasswords)
2. Generate an **App Password** for "Mail".
3. Open `backend/.env` and fill in:
   ```env
   SMTP_USER=your.email@gmail.com
   SMTP_PASS=xxxx xxxx xxxx xxxx
   ```
4. Restart the server (`npm start` or `./start.sh`). Real emails will now be delivered to your inbox!

---

## 📦 Project Structure

```
Ankuls project/
├── backend/
│   ├── db/              # In-memory zero-config DB & seed vehicles
│   ├── models/          # User, Car, and Booking data schemas
│   ├── routes/          # Auth (OTP & Google), Cars, and Bookings API
│   ├── services/        # Email & SMS OTP dispatcher
│   └── server.js        # Express server (serves API & Frontend on 5001)
├── frontend/
│   ├── dist/            # Optimized production build
│   ├── public/          # App icons & official DriveEase logo
│   └── src/             # React SPA pages & components
├── start.sh             # 1-Click launcher (macOS/Linux)
├── start.bat            # 1-Click launcher (Windows)
├── package.json         # Root scripts runner
└── README.md            # Team guide & documentation
```

---

## 🛠️ Features Included

- 🤖 **EaseBot Concierge**: In-app chatbot for booking, digital keys, demo login, OTP, and invoices.
- 🚘 **Fleet Explorer**: Filter by category (SUV, Sedan, EV, Luxury), transmission, fuel type, price.
- 📱 **Clean Authentication**: Sign in via Email OTP (Gmail), Password, or 1-Click Google Auth.
- 🔑 **Keyless Telematics**: Virtual digital car key unlock modal with animated lock/unlock state.
- 🧾 **Printable Tax Invoices**: GST-compliant invoice generator with print/PDF export.
- 📊 **User & Admin Dashboards**: Track active trips, past reservations, and fleet statistics.
- 🔒 **Self-Contained Security**: Fully independent JWT authentication with zero external telemetry or tracking.
